/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useEffect, useMemo, useState} from 'react';
import {AppDefinition} from '../types';

interface StartMenuProps {
  isOpen: boolean;
  apps: AppDefinition[];
  pinnedAppIds: string[];
  onAppOpen: (appId: string) => void;
  onExecuteAction: (actionId: string, value?: string) => void;
  onClose: () => void;
}

const AppItem: React.FC<{
  app: AppDefinition;
  onAppOpen: (appId: string) => void;
  onPinToggle: (appId: string) => void;
  isPinned: boolean;
}> = ({ app, onAppOpen, onPinToggle, isPinned }) => (
   <button
      className="start-menu-app-item"
      title={`${app.name}. Right-click to ${isPinned ? 'unpin' : 'pin'}.`}
      onClick={() => onAppOpen(app.id)}
      onContextMenu={(e) => {
          e.preventDefault();
          onPinToggle(app.id);
      }}
    >
    <span className="start-menu-app-icon">{app.icon}</span>
    <span className="start-menu-app-name">{app.name}</span>
     {isPinned && <span className="pin-indicator">📌</span>}
  </button>
);


export const StartMenu: React.FC<StartMenuProps> = ({
  isOpen,
  apps,
  pinnedAppIds,
  onAppOpen,
  onExecuteAction,
  onClose,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const {pinnedApps, suggestedApps, categorizedApps} = useMemo(() => {
    const pinned = pinnedAppIds.map(id => apps.find(app => app.id === id)).filter(Boolean) as AppDefinition[];
    
    // Key apps that are central to the OS experience
    const suggestionIds = ['ai_core_interface_app', 'mission_planner_app', 'evolutionary_vault_app', 'wilson_generator_app'];
    const suggested = suggestionIds.map(id => apps.find(app => app.id === id)).filter(Boolean) as AppDefinition[];

    const filtered = apps.filter((app) =>
      app.name.toLowerCase().includes(searchTerm.toLowerCase()),
    );

    const categorized: Record<string, AppDefinition[]> = {};
    filtered.forEach((app) => {
      const category = app.category || 'Miscellaneous';
      if (!categorized[category]) {
        categorized[category] = [];
      }
      categorized[category].push(app);
    });

    // Sort categories according to a logical grouping
    const categoryOrder = [
      'NeoCor AI System',
      'Science & Exploration',
      'AI Development & Research',
      'Development & Utilities',
      'Satellite & Drone Systems',
      'Finance & Media',
      'Media',
      'Miscellaneous',
    ];

    const sortedCategorized: Record<string, AppDefinition[]> = {};
    categoryOrder.forEach((cat) => {
      if (categorized[cat]) {
        sortedCategorized[cat] = categorized[cat];
      }
    });
    // Add any other categories that might not be in the explicit order
    Object.keys(categorized).forEach((cat) => {
      if (!sortedCategorized[cat]) {
        sortedCategorized[cat] = categorized[cat];
      }
    });

    return {pinnedApps: pinned, suggestedApps: suggested, categorizedApps: sortedCategorized};
  }, [apps, pinnedAppIds, searchTerm]);

  useEffect(() => {
    if (isOpen) {
      setSearchTerm(''); // Clear search on open
    }
  }, [isOpen]);

  if (!isOpen) {
    return null;
  }

  return (
    <div className="start-menu-container" onClick={(e) => e.stopPropagation()} onContextMenu={(e) => e.stopPropagation()}>
      <div className="start-menu-sidebar">
        <h2 className="start-menu-title">Titan's Pulse X</h2>
         <div className="start-menu-section">
            <h3 className="start-menu-category-title">Quick Launch</h3>
            <div className="start-menu-quick-launch">
                {pinnedApps.length > 0 ? pinnedApps.map(app => (
                     <AppItem key={app.id} app={app} onAppOpen={onAppOpen} onPinToggle={(id) => onExecuteAction('action_toggle_pin', id)} isPinned={true} />
                )) : <p className="empty-section-text">Right-click an app to pin it here.</p>}
            </div>
        </div>
        <div className="start-menu-section">
            <h3 className="start-menu-category-title">AI Suggestions</h3>
             <div className="start-menu-quick-launch">
                {suggestedApps.map(app => (
                     <AppItem key={app.id} app={app} onAppOpen={onAppOpen} onPinToggle={(id) => onExecuteAction('action_toggle_pin', id)} isPinned={pinnedAppIds.includes(app.id)} />
                ))}
            </div>
        </div>
        <div className="start-menu-actions">
          <button
            onClick={() => onExecuteAction('action_open_parameters')}
            className="start-menu-action-button">
            <span>⚙️</span>
            <span>Parameters</span>
          </button>
          <button
            onClick={() => onExecuteAction('action_save_state')}
            className="start-menu-action-button">
            <span>💾</span>
            <span>Save State</span>
          </button>
        </div>
      </div>
      <div className="start-menu-main">
        <div className="start-menu-search-bar">
          <input
            type="text"
            placeholder="Search all apps & applets... (Right-click to pin)"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            autoFocus
          />
        </div>
        <div className="start-menu-app-list">
          {Object.entries(categorizedApps).map(
            ([category, appList]) => (
              <div key={category} className="start-menu-category">
                <h3 className="start-menu-category-title">{category}</h3>
                <div className="start-menu-app-grid">
                  {appList.map((app) => (
                    <AppItem key={app.id} app={app} onAppOpen={onAppOpen} onPinToggle={(id) => onExecuteAction('action_toggle_pin', id)} isPinned={pinnedAppIds.includes(app.id)} />
                  ))}
                </div>
              </div>
            ),
          )}
        </div>
      </div>
    </div>
  );
};