/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import React from 'react';
import {AppDefinition} from '../types';

interface IconProps {
  app: AppDefinition;
  onInteract: () => void;
}

export const Icon: React.FC<IconProps> = ({app, onInteract}) => {
  return (
    <div
      className="icon w-28 h-32 flex flex-col items-center justify-start text-center m-2 p-2 cursor-pointer select-none rounded-lg"
      onClick={onInteract}
      onKeyDown={(e) => e.key === 'Enter' && onInteract()}
      onContextMenu={(e) => e.stopPropagation()}
      tabIndex={0}
      role="button"
      aria-label={`Open ${app.name}`}>
      <div className="text-6xl mb-2">{app.icon}</div>{' '}
      <div className="text-sm font-semibold break-words max-w-full leading-tight">
        {app.name}
      </div>
    </div>
  );
};