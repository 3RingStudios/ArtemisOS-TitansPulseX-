/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import {Notification} from '../types';

interface NotificationSidebarProps {
  isOpen: boolean;
  notifications: Notification[];
  onClear: () => void;
  onClose: () => void;
}

export const NotificationSidebar: React.FC<NotificationSidebarProps> = ({
  isOpen,
  notifications,
  onClear,
  onClose,
}) => {
  return (
    <div
      className={`fixed top-10 right-0 h-[calc(100%-2.5rem)] w-80 bg-gray-800/80 backdrop-blur-lg text-white shadow-2xl transition-transform duration-300 ease-in-out z-[150] ${
        isOpen ? 'translate-x-0' : 'translate-x-full'
      }`}>
      <div className="flex justify-between items-center p-4 border-b border-gray-600">
        <h2 className="text-lg font-semibold">Notifications</h2>
        <button
          onClick={onClose}
          className="text-2xl hover:text-red-500 transition-colors">
          &times;
        </button>
      </div>
      <div className="p-4 overflow-y-auto h-[calc(100%-120px)]">
        {notifications.length === 0 ? (
          <p className="text-gray-400 text-center mt-8">
            No new notifications.
          </p>
        ) : (
          <div className="flex flex-col gap-3">
            {notifications.map((notif) => (
              <div
                key={notif.id}
                className="bg-gray-700/50 p-3 rounded-lg flex items-start gap-3 animate-fade-in">
                <span className="text-2xl mt-1">{notif.icon}</span>
                <div>
                  <p className="font-medium text-sm">{notif.message}</p>
                  <p className="text-xs text-gray-400">
                    {new Date(notif.timestamp).toLocaleString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-600">
        <button
          onClick={onClear}
          disabled={notifications.length === 0}
          className="w-full py-2 bg-red-600 hover:bg-red-700 disabled:bg-gray-600 disabled:cursor-not-allowed rounded-lg transition-colors">
          Clear All
        </button>
      </div>
    </div>
  );
};
