/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useEffect, useState } from 'react';

interface BootScreenProps {
  onBootComplete: () => void;
}

const bootMessages = [
  { text: 'ArtemisOS v2.1 Initializing...', time: 1000 },
  { text: 'Quantum Core synchronization...', time: 1500 },
  { text: 'Loading AI Orchestrator...', time: 1200 },
  { text: 'Establishing link to Aetherium Core...', time: 1800 },
  { text: 'Calibrating Neural Net interfaces...', time: 2000 },
  { text: 'Verifying system integrity...', time: 1000 },
  { text: 'Welcome, Operator.', time: 500 },
];

export const BootScreen: React.FC<BootScreenProps> = ({ onBootComplete }) => {
  const [messageIndex, setMessageIndex] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const styleId = 'artemis-boot-theme';
    // On mount, check for a saved boot theme and apply it.
    const savedCss = localStorage.getItem('artemisOS_bootThemeCss');

    if (savedCss) {
        document.body.classList.add('boot-theme-active');
        const style = document.createElement('style');
        style.id = styleId;
        style.innerHTML = savedCss;
        document.head.appendChild(style);
    }

    // The cleanup function will run when the component unmounts.
    return () => {
        const styleElement = document.getElementById(styleId);
        if (styleElement) {
            styleElement.remove();
        }
        document.body.classList.remove('boot-theme-active');
    };
  }, []);


  useEffect(() => {
    if (messageIndex >= bootMessages.length) {
      setTimeout(() => onBootComplete(), 500);
      return;
    }

    const timer = setTimeout(() => {
      setMessageIndex(messageIndex + 1);
    }, bootMessages[messageIndex].time);

    return () => clearTimeout(timer);
  }, [messageIndex, onBootComplete]);
  
  useEffect(() => {
    const totalTime = bootMessages.reduce((sum, msg) => sum + msg.time, 0);
    let elapsedTime = 0;
    
    bootMessages.forEach((msg, index) => {
        if(index < messageIndex) {
            elapsedTime += msg.time;
        }
    });

    setProgress(Math.min(100, (elapsedTime / totalTime) * 100));

  }, [messageIndex]);


  return (
    <div className="boot-container w-full h-screen font-mono flex flex-col items-center justify-center select-none">
      <div className="boot-logo text-8xl mb-8">🔮</div>
      <h1 className="boot-title text-4xl font-bold mb-4">ArtemisOS</h1>
      <div className="boot-progress-bar-container w-1/3 rounded-full h-2.5 mb-8">
        <div className="boot-progress-bar h-2.5 rounded-full" style={{ width: `${progress}%`, transition: 'width 0.5s ease-out' }}></div>
      </div>
      <div className="h-6 text-center">
        {bootMessages.map((msg, index) => (
          <p key={index} className={`boot-message transition-opacity duration-500 ${index === messageIndex ? 'opacity-100' : 'opacity-0 absolute'}`}>
            {msg.text}
          </p>
        ))}
      </div>
    </div>
  );
};
