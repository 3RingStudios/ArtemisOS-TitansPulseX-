/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import React, {useEffect, useRef} from 'react';

interface TaskbarContextMenuProps {
  x: number;
  y: number;
  appId: string;
  onCloseApp: (appId: string) => void;
  onMinimizeApp: (appId: string) => void;
  onCloseMenu: () => void;
}

export const TaskbarContextMenu: React.FC<TaskbarContextMenuProps> = ({
  x,
  y,
  appId,
  onCloseApp,
  onMinimizeApp,
  onCloseMenu,
}) => {
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onCloseMenu();
      }
    };
    // Add event listener on next tick to avoid capturing the click that opened it
    setTimeout(() => {
      document.addEventListener('mousedown', handleClickOutside);
    }, 0);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [onCloseMenu]);

  return (
    <div
      ref={menuRef}
      className="taskbar-context-menu"
      style={{left: x, top: y}}
      // Prevent clicks inside the menu from propagating to the desktop
      onClick={(e) => e.stopPropagation()}
      onContextMenu={(e) => e.stopPropagation()}>
      <button
        className="taskbar-context-menu-button"
        onClick={() => {
          onMinimizeApp(appId);
          onCloseMenu();
        }}>
        <span>&ndash;</span>
        <span>Minimize</span>
      </button>
      <button
        className="taskbar-context-menu-button"
        onClick={() => {
          onCloseApp(appId);
          onCloseMenu();
        }}>
        <span>&times;</span>
        <span>Close</span>
      </button>
    </div>
  );
};