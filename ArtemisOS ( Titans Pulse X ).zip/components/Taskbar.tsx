/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useRef, useState, useEffect} from 'react';
import {AppDefinition, AppInstance, Blueprint} from '../types';
import {TaskbarContextMenu} from './TaskbarContextMenu';
import { TinySystemMonitor } from './widgets/TinySystemMonitor';
import { systemBus } from '../services/systemBus';
import { playSound, SoundType } from '../services/audioService';

interface TaskbarProps {
  runningApps: AppInstance[];
  appDefinitions: AppDefinition[];
  activeAppId: string | null;
  onAppSelect: (appId: string) => void;
  onToggleStartMenu: () => void;
  onToggleAI: () => void;
  onShowDesktop: () => void;
  onCloseApp: (appId: string) => void;
  onMinimizeApp: (appId: string) => void;
  onToggleNotifications: () => void;
  onToggleParameters: () => void;
  isLiveMode: boolean;
  onToggleLiveMode: () => void;
  latestBlueprint: Blueprint | null;
}

const BlueprintWidget: React.FC<{ blueprint: Blueprint | null }> = ({ blueprint }) => {
  const handleSimulate = () => {
    playSound(SoundType.CLICK);
    systemBus.emit('execute_command', {
      command: 'open_app',
      appId: 'flight_dynamics_lab_app',
    });
  };

  return (
    <div className={`taskbar-widget ${blueprint ? 'blueprint-new' : ''}`} onClick={blueprint ? handleSimulate : undefined} title={blueprint?.technologyName}>
      <span className="taskbar-widget-icon">📄</span>
      <span className="taskbar-widget-text truncate">
        {blueprint ? blueprint.technologyName : 'No Blueprint'}
      </span>
    </div>
  );
};

const Clock: React.FC = () => {
    const [time, setTime] = useState(new Date());
    const lastHour = useRef(time.getHours());
    const [shouldAnimate, setShouldAnimate] = useState(false);

    useEffect(() => {
        const timer = setInterval(() => {
            const now = new Date();
            setTime(now);
            if (now.getMinutes() === 0 && now.getSeconds() === 0 && now.getHours() !== lastHour.current) {
                lastHour.current = now.getHours();
                setShouldAnimate(true);
                setTimeout(() => setShouldAnimate(false), 1000); // Animation duration is 1s
            }
        }, 1000);
        return () => clearInterval(timer);
    }, []);
    
    return (
      <span className={`taskbar-clock ${shouldAnimate ? 'clock-flip-animation' : ''}`}>
        {time.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}
      </span>
    );
};

export const Taskbar: React.FC<TaskbarProps> = (props) => {
  const [menuState, setMenuState] = useState<{
    visible: boolean;
    x: number;
    y: number;
    appId: string;
  } | null>(null);

  const getAppDef = (appId: string) =>
    props.appDefinitions.find((def) => def.id === appId);

  const handleAppButtonContextMenu = (event: React.MouseEvent, appId: string) => {
    event.preventDefault();
    const rect = event.currentTarget.getBoundingClientRect();
    setMenuState({
      visible: true,
      x: rect.left,
      y: rect.top,
      appId: appId,
    });
  };
  
  const handleLiveModeClick = () => {
    playSound(SoundType.TRANSITION, 0.8);
    props.onToggleLiveMode();
  };

  return (
    <>
      {menuState?.visible && (
        <TaskbarContextMenu
          x={menuState.x}
          y={menuState.y}
          appId={menuState.appId}
          onCloseApp={props.onCloseApp}
          onMinimizeApp={props.onMinimizeApp}
          onCloseMenu={() => setMenuState(null)}
        />
      )}
      <div className="taskbar-container">
        {/* Left Pod */}
        <div className="taskbar-pod">
          <button
            className="taskbar-system-button"
            onClick={props.onToggleAI}
            aria-label="Toggle AI Companion"
            title="AI Companion"
          >✨</button>
          <button
            onClick={props.onToggleParameters}
            className="taskbar-system-button"
            aria-label="Toggle System Parameters"
            title="System Parameters"
          >⚙️</button>
           <button
            onClick={props.onToggleNotifications}
            className="taskbar-system-button"
            aria-label="Toggle Notifications"
            title="Notifications"
          >🔔</button>
        </div>

        {/* Start Button */}
        <button
          className="start-button"
          onClick={props.onToggleStartMenu}
          aria-label="Open Start Menu"
        >🔮</button>
        
        {/* Right Pod */}
        <div className="taskbar-pod">
            {/* Running Apps */}
            <div className="running-apps-scroll-container">
                <div className="running-apps-list">
                {props.runningApps.map((app) => {
                    const appDef = getAppDef(app.id);
                    if (!appDef) return null;
                    return (
                    <button
                        key={app.id}
                        onClick={() => props.onAppSelect(app.id)}
                        onContextMenu={(e) => handleAppButtonContextMenu(e, app.id)}
                        className={`taskbar-app-button ${
                        props.activeAppId === app.id && !app.isMinimized ? 'active' : ''
                        }`}
                        title={appDef.name}>
                        <span className="taskbar-app-icon">{appDef.icon}</span>
                    </button>
                    );
                })}
                </div>
            </div>

            {/* Right System Controls */}
            <div className="taskbar-group">
                <BlueprintWidget blueprint={props.latestBlueprint} />
                <TinySystemMonitor />
                <button onClick={handleLiveModeClick} className={`taskbar-go-live-capsule ${props.isLiveMode ? 'live' : ''}`}>
                    <span>🔴</span>
                    <span>{props.isLiveMode ? 'LIVE' : 'Go Live'}</span>
                </button>
                <Clock />
            </div>

            <div className="taskbar-separator" />
            
            {/* Show Desktop */}
            <button
                className="show-desktop-button"
                onClick={props.onShowDesktop}
                aria-label="Show Desktop"
            />
        </div>
      </div>
    </>
  );
};
