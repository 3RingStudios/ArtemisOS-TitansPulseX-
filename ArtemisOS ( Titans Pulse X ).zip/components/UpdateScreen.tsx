/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useEffect, useState } from 'react';

interface UpdateScreenProps {
  onUpdateComplete: () => void;
}

const updateMessages = [
  { text: 'Applying updates...', time: 2000 },
  { text: 'Finalizing system changes...', time: 2500 },
  { text: 'Restarting ArtemisOS...', time: 1500 },
];

export const UpdateScreen: React.FC<UpdateScreenProps> = ({ onUpdateComplete }) => {
  const [messageIndex, setMessageIndex] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (messageIndex >= updateMessages.length) {
      setTimeout(() => onUpdateComplete(), 500);
      return;
    }

    const timer = setTimeout(() => {
      setMessageIndex(messageIndex + 1);
    }, updateMessages[messageIndex].time);

    return () => clearTimeout(timer);
  }, [messageIndex, onUpdateComplete]);
  
  useEffect(() => {
    const totalTime = updateMessages.reduce((sum, msg) => sum + msg.time, 0);
    let elapsedTime = 0;
    
    updateMessages.forEach((msg, index) => {
        if(index < messageIndex) {
            elapsedTime += msg.time;
        }
    });

    setProgress(Math.min(100, (elapsedTime / totalTime) * 100));

  }, [messageIndex]);


  return (
    <div className="boot-container w-full h-screen font-mono flex flex-col items-center justify-center select-none absolute inset-0 z-[1000]">
      <div className="boot-logo text-8xl mb-8 animate-spin">⚙️</div>
      <h1 className="boot-title text-4xl font-bold mb-4">Updating ArtemisOS</h1>
      <div className="boot-progress-bar-container w-1/3 rounded-full h-2.5 mb-8">
        <div className="boot-progress-bar h-2.5 rounded-full" style={{ width: `${progress}%`, transition: 'width 0.5s ease-out' }}></div>
      </div>
      <div className="h-6 text-center">
        {updateMessages.map((msg, index) => (
          <p key={index} className={`boot-message transition-opacity duration-500 ${index === messageIndex ? 'opacity-100' : 'opacity-0 absolute'}`}>
            {msg.text}
          </p>
        ))}
      </div>
    </div>
  );
};
