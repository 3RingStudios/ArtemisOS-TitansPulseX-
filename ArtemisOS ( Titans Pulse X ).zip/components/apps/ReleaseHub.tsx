/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState } from 'react';
import { BuildStatus, NativeAppComponentProps } from '../../types';
import './release_hub/ReleaseHub.css';
import { WindowsBuildTab } from './release_hub/WindowsBuildTab';

type BuildTarget = 'Windows' | 'macOS' | 'Linux' | 'PiOS' | 'PWA';

const PlaceholderTab: React.FC<{target: string}> = ({ target }) => (
    <div className="text-gray-500">
        <p>Build instructions for {target} would appear here.</p>
        <p>The interactive build process is currently implemented for Windows as a demonstration.</p>
    </div>
);

const TabButton: React.FC<{ 
    label: string; 
    isActive: boolean; 
    onClick: () => void;
    status: BuildStatus;
}> = ({ label, isActive, onClick, status }) => {
    const statusClasses: Record<BuildStatus, string> = {
        'Idle': 'build-status-idle',
        'Building': 'build-status-building',
        'Success': 'build-status-success',
        'Failed': 'build-status-failed',
    };

    return (
        <button
            onClick={onClick}
            className={`px-4 py-2 text-sm font-medium transition-colors rounded-t-lg border-b-2 flex items-center gap-2 ${
                isActive ? 'border-cyan-400 text-white' : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-500'
            }`}
        >
            <span className={`build-status-indicator ${statusClasses[status]}`}></span>
            {label}
        </button>
    );
};

export const ReleaseHub: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [activeTab, setActiveTab] = useState<BuildTarget>('Windows');
    const [buildStatuses, setBuildStatuses] = useState<Record<BuildTarget, BuildStatus>>({
        'Windows': 'Idle',
        'macOS': 'Idle',
        'Linux': 'Idle',
        'PiOS': 'Idle',
        'PWA': 'Success', // PWA is always "built"
    });

    const handleWindowsStatusChange = (status: 'Building' | 'Success' | 'Failed') => {
        setBuildStatuses(prev => ({...prev, 'Windows': status}));
    };

    const renderContent = () => {
        switch (activeTab) {
            case 'Windows': return <WindowsBuildTab onStatusChange={handleWindowsStatusChange} />;
            case 'macOS': return <PlaceholderTab target="macOS" />;
            case 'Linux': return <PlaceholderTab target="Linux" />;
            case 'PiOS': return <PlaceholderTab target="PiOS (ARM64)" />;
            case 'PWA': return <PlaceholderTab target="PWA (Web)" />;
            default: return null;
        }
    }

    return (
        <div className="release-hub-container">
            <div className="release-hub-header">
                <h2 className="release-hub-title">📦 Release Hub</h2>
                <p className="text-sm text-gray-400">Interactive Build & Deployment Dashboard</p>
            </div>

             <div className="release-hub-tabs">
                <nav className="-mb-px flex space-x-4" aria-label="Tabs">
                    <TabButton label="Windows" isActive={activeTab === 'Windows'} onClick={() => setActiveTab('Windows')} status={buildStatuses['Windows']} />
                    <TabButton label="macOS" isActive={activeTab === 'macOS'} onClick={() => setActiveTab('macOS')} status={buildStatuses['macOS']} />
                    <TabButton label="Linux" isActive={activeTab === 'Linux'} onClick={() => setActiveTab('Linux')} status={buildStatuses['Linux']} />
                    <TabButton label="PiOS" isActive={activeTab === 'PiOS'} onClick={() => setActiveTab('PiOS')} status={buildStatuses['PiOS']} />
                    <TabButton label="PWA" isActive={activeTab === 'PWA'} onClick={() => setActiveTab('PWA')} status={buildStatuses['PWA']} />
                </nav>
            </div>
            
            <div className="release-hub-content">
                {renderContent()}
            </div>
        </div>
    );
};