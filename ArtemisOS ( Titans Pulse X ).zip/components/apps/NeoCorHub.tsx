/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { NativeAppComponentProps } from '../../types';

// Declare Chart.js type for global scope
declare const Chart: any;

const StatusCard: React.FC<{ title: string; children: React.ReactNode; status: 'nominal' | 'warning' | 'critical' }> = ({ title, children, status }) => {
    const statusColor = {
        nominal: 'border-green-500',
        warning: 'border-yellow-500',
        critical: 'border-red-500',
    }[status];

    return (
        <div className={`bg-gray-800/50 p-4 rounded-lg border-l-4 ${statusColor}`}>
            <h3 className="text-gray-400 text-sm font-bold uppercase">{title}</h3>
            <div className="text-2xl font-semibold text-white">{children}</div>
        </div>
    );
}

const ChartComponent: React.FC<{ id: string }> = ({ id }) => {
    const chartRef = useRef<HTMLCanvasElement>(null);
    const chartInstance = useRef<any>(null);

    useEffect(() => {
        if (!chartRef.current) return;
        const ctx = chartRef.current.getContext('2d');
        if (!ctx) return;

        chartInstance.current = new Chart(ctx, {
            type: 'line',
            data: {
                labels: Array(20).fill(''),
                datasets: [{
                    data: Array(20).fill(0).map(() => Math.random() * 100),
                    borderColor: '#38bdf8',
                    borderWidth: 1.5,
                    pointRadius: 0,
                    tension: 0.4,
                    fill: false,
                }],
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: { legend: { display: false }, tooltip: { enabled: false } },
                scales: { x: { display: false }, y: { display: false, min: 0, max: 100 } },
            },
        });

        const interval = setInterval(() => {
            if (chartInstance.current) {
                const data = chartInstance.current.data.datasets[0].data;
                data.push(Math.random() * 100);
                data.shift();
                chartInstance.current.update('none');
            }
        }, 1500);

        return () => {
            clearInterval(interval);
            chartInstance.current?.destroy();
        };
    }, []);

    return <canvas ref={chartRef} id={id}></canvas>;
}


export const NeoCorHub: React.FC<Partial<NativeAppComponentProps>> = () => {
    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0 pb-2 border-b border-gray-700">
                <h2 className="text-xl text-cyan-300 font-bold">💠 NeoCor Systems Hub</h2>
                <p className="text-sm text-gray-400">High-Level Overview of the Entire Artemis-Nexus Ecosystem.</p>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <StatusCard title="System Status" status="nominal">
                    <span className="text-green-400">Nominal</span>
                </StatusCard>
                <StatusCard title="Interstellar Latency" status="nominal">
                    996 ms
                </StatusCard>
                <StatusCard title="Planetary Harmonics" status="warning">
                    <span className="text-yellow-400">Fluctuating</span>
                </StatusCard>
                <StatusCard title="Security Matrix" status="nominal">
                    <span className="text-green-400">128-Layer Active</span>
                </StatusCard>
            </div>
            
            <div className="flex-grow grid grid-cols-1 lg:grid-cols-3 gap-4 overflow-hidden">
                <div className="lg:col-span-2 bg-gray-800 rounded-lg p-4 flex flex-col">
                    <h3 className="font-semibold mb-2 text-gray-300">Wilson Generator Output</h3>
                    <div className="flex-grow">
                        <ChartComponent id="wilson-chart" />
                    </div>
                </div>
                <div className="bg-gray-800 rounded-lg p-4 flex flex-col">
                    <h3 className="font-semibold mb-2 text-gray-300">Data Flow Integrity</h3>
                    <div className="flex-grow">
                         <ChartComponent id="data-flow-chart" />
                    </div>
                     <div className="mt-4 font-mono text-xs space-y-1">
                        <p>Packets/sec: <span className="text-cyan-300">{(Math.random() * 500 + 1200).toFixed(2)}M</span></p>
                        <p>Quantum Sim: <span className="text-green-400">Stable</span></p>
                        <p>Blood-Vein Sync: <span className="text-green-400">OK</span></p>
                    </div>
                </div>
            </div>
        </div>
    );
};
