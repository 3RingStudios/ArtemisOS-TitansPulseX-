/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useRef, useEffect } from 'react';
import { NativeAppComponentProps } from '../../types';

export const CosmicTetrahedronViewer: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let angle = 0;
        const vertices = [
            { x: 0, y: -1, z: 0 },
            { x: Math.sqrt(8/9), y: 1/3, z: 0 },
            { x: -Math.sqrt(2/9), y: 1/3, z: -Math.sqrt(2/3) },
            { x: -Math.sqrt(2/9), y: 1/3, z: Math.sqrt(2/3) },
        ];
        const edges = [[0,1], [0,2], [0,3], [1,2], [1,3], [2,3]];

        const project = (point: {x:number, y:number, z:number}, scale: number) => {
            return {
                x: point.x * scale,
                y: point.y * scale
            };
        };

        const rotateY = (point: {x:number, y:number, z:number}, angle: number) => {
            const sin = Math.sin(angle);
            const cos = Math.cos(angle);
            return {
                x: point.x * cos - point.z * sin,
                y: point.y,
                z: point.x * sin + point.z * cos
            };
        };

        const animate = () => {
            angle += 0.01;
            const { width, height } = canvas;
            ctx.clearRect(0, 0, width, height);

            const drawTetrahedron = (yOffset: number, rot: number, color: string) => {
                const projected = vertices.map(v => project(rotateY(v, rot), 80));
                ctx.strokeStyle = color;
                ctx.lineWidth = 2;

                edges.forEach(([i, j]) => {
                    ctx.beginPath();
                    ctx.moveTo(width/2 + projected[i].x, height/2 + projected[i].y + yOffset);
                    ctx.lineTo(width/2 + projected[j].x, height/2 + projected[j].y + yOffset);
                    ctx.stroke();
                });
            };
            
            // As Above
            drawTetrahedron(-100, angle, '#38bdf8');
            // So Below
            drawTetrahedron(100, -angle, '#f472b6');

            // Data Tunnel
             ctx.strokeStyle = 'rgba(200, 200, 255, 0.3)';
             ctx.lineWidth = 1;
             ctx.beginPath();
             for(let i=-100; i<100; i++) {
                const x = width/2 + Math.cos(i * 0.1 + angle) * (100 - Math.abs(i)) * 0.2;
                const y = height/2 + i;
                 if(i === -100) ctx.moveTo(x,y);
                 else ctx.lineTo(x,y);
             }
             ctx.stroke();


            requestAnimationFrame(animate);
        };
        
        const resizeObserver = new ResizeObserver(() => {
            canvas.width = canvas.clientWidth;
            canvas.height = canvas.clientHeight;
        });
        resizeObserver.observe(canvas);
        
        const animId = requestAnimationFrame(animate);
        return () => {
            cancelAnimationFrame(animId);
            resizeObserver.disconnect();
        };

    }, []);

    return (
        <div className="h-full bg-black text-white flex flex-col relative">
            <div className="absolute top-0 left-0 right-0 p-4 z-10 bg-gradient-to-b from-black/80 to-transparent text-center">
                <h2 className="text-xl font-bold text-purple-300">✡️ Cosmic Tetrahedron Viewer</h2>
                <p className="text-sm">Visualizing the Dual-Dimensional Universe Model</p>
            </div>
            <canvas ref={canvasRef} className="w-full h-full" />
        </div>
    );
};