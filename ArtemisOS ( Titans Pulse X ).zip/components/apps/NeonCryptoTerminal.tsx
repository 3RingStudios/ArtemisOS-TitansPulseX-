/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { NativeAppComponentProps, CryptoAsset } from '../../types';

const initialAssets: CryptoAsset[] = [
    { id: 'eth', symbol: 'A-ETH', name: 'Aetherium', price: 3456.78, change24h: 2.5 },
    { id: 'btc', symbol: 'BTC', name: 'Bitcoin', price: 68745.12, change24h: -1.2 },
    { id: 'sol', symbol: 'SOL', name: 'Solana', price: 172.45, change24h: 5.8 },
    { id: 'nex', symbol: 'NEX', name: 'NexusCoin', price: 1.23, change24h: 12.1 },
];

export const NeonCryptoTerminal: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [assets, setAssets] = useState<CryptoAsset[]>(initialAssets);

    useEffect(() => {
        const interval = setInterval(() => {
            setAssets(prev => prev.map(asset => {
                const change = (Math.random() - 0.45) * (asset.price * 0.01);
                return { ...asset, price: asset.price + change, change24h: asset.change24h + (Math.random() * 0.2 - 0.1) };
            }));
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="h-full bg-black text-green-400 font-mono p-4 flex flex-col relative overflow-hidden">
            <div className="scanlines"></div>
            <div className="absolute inset-0 bg-black/50"></div>
            <div className="relative z-10 flex flex-col h-full">
                <div className="flex-shrink-0 pb-2 border-b-2 border-green-400/50 mb-4">
                    <h2 className="text-2xl font-bold text-cyan-300">[NEON CRYPTO TERMINAL]</h2>
                    <p className="text-xs">Live Market Data Feed</p>
                </div>
                <div className="flex-grow overflow-y-auto">
                    <table className="w-full text-left text-sm">
                        <thead>
                            <tr className="text-cyan-300">
                                <th className="p-2">SYMBOL</th>
                                <th className="p-2">PRICE (USD)</th>
                                <th className="p-2">24H CHANGE</th>
                            </tr>
                        </thead>
                        <tbody>
                            {assets.map(asset => (
                                <tr key={asset.id} className="border-t border-green-800/50">
                                    <td className="p-2 font-bold">{asset.symbol}</td>
                                    <td className="p-2">${asset.price.toFixed(2)}</td>
                                    <td className={`p-2 font-bold ${asset.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                        {asset.change24h.toFixed(2)}%
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            <style>{`
                .scanlines {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(0,0,0,0.5) 50%, rgba(0,0,0,0) 100%);
                    background-size: 100% 4px;
                    animation: scan 10s linear infinite;
                    pointer-events: none;
                }
                @keyframes scan {
                    from { background-position: 0 0; }
                    to { background-position: 0 -200px; }
                }
            `}</style>
        </div>
    );
};
