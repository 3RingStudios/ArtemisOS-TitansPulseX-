/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState } from 'react';
import { NativeAppComponentProps } from '../../types';
import { systemBus } from '../../services/systemBus';
import { playSound, SoundType } from '../../services/audioService';

const Card: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="bg-gray-800/50 p-4 rounded-lg border border-gray-700/50">
        <h3 className="text-lg font-bold text-yellow-300 mb-3">{title}</h3>
        {children}
    </div>
);

export const WebAPIExplorer: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [status, setStatus] = useState('Ready to test Web APIs.');
    const [clipboardText, setClipboardText] = useState('Copy this text!');
    const [location, setLocation] = useState<string | null>(null);
    const [wakeLock, setWakeLock] = useState<any | null>(null);

    const logSystemEvent = (message: string, icon: string = '🔌') => {
        systemBus.emit('log_system_event', {
            message, icon, source: 'WebAPIExplorer',
        });
    };

    const handleGetLocation = async () => {
        playSound(SoundType.CLICK);
        if (!navigator.geolocation) {
            setStatus('Geolocation API is not available in this browser.');
            return;
        }
        setStatus('Requesting location permission...');
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude, accuracy } = position.coords;
                const locStr = `Lat: ${latitude.toFixed(4)}, Lon: ${longitude.toFixed(4)} (Accuracy: ${accuracy.toFixed(0)}m)`;
                setLocation(locStr);
                setStatus('Location received successfully.');
                logSystemEvent(`Location acquired: ${locStr}`);
            },
            (error) => {
                setLocation(null);
                setStatus(`Error getting location: ${error.message}`);
                logSystemEvent(`Failed to acquire location: ${error.message}`, '❌');
            }
        );
    };

    const handleCopy = async () => {
        playSound(SoundType.CLICK, 0.6);
        if (!navigator.clipboard) {
            setStatus('Clipboard API is not available.');
            return;
        }
        try {
            await navigator.clipboard.writeText(clipboardText);
            setStatus(`Copied to clipboard: "${clipboardText}"`);
            logSystemEvent('Text copied to host clipboard.');
        } catch (err: any) {
            setStatus(`Failed to copy: ${err.message}`);
        }
    };

    const handlePaste = async () => {
        playSound(SoundType.CLICK, 0.6);
        if (!navigator.clipboard) {
            setStatus('Clipboard API is not available.');
            return;
        }
        try {
            const text = await navigator.clipboard.readText();
            setClipboardText(text);
            setStatus(`Pasted from clipboard.`);
            logSystemEvent('Pasted text from host clipboard.');
        } catch (err: any) {
            setStatus(`Failed to paste: ${err.message}`);
        }
    };
    
    const handleNotification = async () => {
        playSound(SoundType.OPEN);
        if (!('Notification' in window)) {
            setStatus('Notifications API not available.');
            return;
        }
        if (Notification.permission === 'granted') {
            new Notification('ArtemisOS Notification', {
                body: 'This is a native notification from the OS!',
                icon: '/icon.svg',
            });
            logSystemEvent('Sent native desktop notification.');
        } else if (Notification.permission !== 'denied') {
            const permission = await Notification.requestPermission();
            if (permission === 'granted') {
                new Notification('ArtemisOS', { body: 'Notifications enabled!' });
                logSystemEvent('Desktop notification permission granted.');
            }
        }
    };

    const handleWakeLock = async () => {
        if (!('wakeLock' in navigator)) {
            setStatus('Screen Wake Lock API is not available.');
            return;
        }
        if (wakeLock) {
            await wakeLock.release();
            setWakeLock(null);
            setStatus('Screen Wake Lock released.');
            logSystemEvent('Screen Wake Lock disabled.');
        } else {
            try {
                const lock = await (navigator as any).wakeLock.request('screen');
                setWakeLock(lock);
                setStatus('Screen Wake Lock active. The screen will not sleep.');
                logSystemEvent('Screen Wake Lock enabled.');
                lock.addEventListener('release', () => {
                    setWakeLock(null);
                    setStatus('Screen Wake Lock was released by the system.');
                });
            } catch (err: any) {
                setStatus(`Failed to acquire Wake Lock: ${err.message}`);
            }
        }
    };

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0 pb-2 border-b border-gray-700">
                <h2 className="text-xl text-yellow-300 font-bold">🔌 Web Platform Explorer</h2>
                <p className="text-sm text-gray-400">Test integrations with browser and host system APIs.</p>
            </div>

            <div className="flex-grow overflow-y-auto pr-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card title="Geolocation API">
                    <p className="text-xs text-gray-400 mb-2">Access device location data.</p>
                    <button onClick={handleGetLocation} className="llm-button m-0">Get Current Location</button>
                    {location && <p className="mt-2 font-mono text-sm">{location}</p>}
                </Card>
                <Card title="Clipboard API">
                    <p className="text-xs text-gray-400 mb-2">Share data with the host clipboard.</p>
                    <textarea value={clipboardText} onChange={e => setClipboardText(e.target.value)} className="llm-textarea m-0 w-full h-20" />
                    <div className="flex gap-2 mt-2">
                        <button onClick={handleCopy} className="llm-button flex-1 m-0">Copy</button>
                        <button onClick={handlePaste} className="llm-button flex-1 m-0 bg-gray-600 hover:bg-gray-500">Paste</button>
                    </div>
                </Card>
                <Card title="Notifications API">
                    <p className="text-xs text-gray-400 mb-2">Send native desktop notifications.</p>
                    <button onClick={handleNotification} className="llm-button m-0">Send Test Notification</button>
                </Card>
                <Card title="Screen Wake Lock API">
                    <p className="text-xs text-gray-400 mb-2">Prevent the screen from turning off.</p>
                    <button onClick={handleWakeLock} className={`llm-button m-0 ${wakeLock ? 'bg-red-600 hover:bg-red-700' : ''}`}>
                        {wakeLock ? 'Release Wake Lock' : 'Acquire Wake Lock'}
                    </button>
                </Card>
            </div>
            <div className="flex-shrink-0 p-2 border-t border-gray-700 text-xs text-center text-gray-400">
                Status: {status}
            </div>
        </div>
    );
};
