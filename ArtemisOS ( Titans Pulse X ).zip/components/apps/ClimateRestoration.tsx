/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useRef, useEffect, useState } from 'react';
import { NativeAppComponentProps } from '../../types';

export const ClimateRestoration: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [progress, setProgress] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setProgress(p => (p < 100 ? p + 0.5 : 100));
        }, 100);
        return () => clearInterval(interval);
    }, []);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        
        const draw = () => {
            const { width, height } = canvas;
            ctx.clearRect(0, 0, width, height);
            
            const radius = height / 3;
            // Before
            ctx.fillStyle = '#ef4444';
            ctx.beginPath();
            ctx.arc(width/4, height/2, radius, 0, Math.PI * 2);
            ctx.fill();
            
            // After
            const greenAmount = progress / 100;
            ctx.fillStyle = `rgb(${239 * (1-greenAmount)}, ${68 * (1-greenAmount) + 74 * greenAmount}, ${68 * (1-greenAmount) + 211 * greenAmount})`;
            ctx.beginPath();
            ctx.arc(width * 3/4, height/2, radius, 0, Math.PI * 2);
            ctx.fill();
        };
        draw();
    }, [progress]);

    return (
        <div className="h-full bg-gray-800 text-white p-4">
            <h2 className="text-xl font-bold text-green-300 text-center">🌿 Climate Restoration Progress</h2>
            <div className="w-full h-4/5">
                <canvas ref={canvasRef} className="w-full h-full"></canvas>
            </div>
            <p className="text-center font-bold text-2xl">{progress.toFixed(1)}% Complete</p>
        </div>
    );
};