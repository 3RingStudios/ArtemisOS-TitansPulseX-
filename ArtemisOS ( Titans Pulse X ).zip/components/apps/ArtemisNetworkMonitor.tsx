/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useRef, useEffect } from 'react';
import { NativeAppComponentProps, CosmicSignal } from '../../types';

const planets = [
    { name: 'Sun', x: 0.5, y: 0.5, r: 20, color: '#facc15' },
    { name: 'Earth', x: 0.3, y: 0.5, r: 8, color: '#3b82f6' },
    { name: 'Mars', x: 0.7, y: 0.3, r: 6, color: '#ef4444' },
    { name: 'Saturn', x: 0.8, y: 0.8, r: 12, color: '#f59e0b' },
];

export const ArtemisNetworkMonitor: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        
        let signals: {x:number, y:number, tx:number, ty:number, life:number}[] = [];

        const animate = () => {
            const { width, height } = canvas;
            ctx.clearRect(0, 0, width, height);

            if (Math.random() > 0.98) {
                const p1 = planets[Math.floor(Math.random() * planets.length)];
                const p2 = planets[Math.floor(Math.random() * planets.length)];
                if (p1 !== p2) {
                     signals.push({ x: p1.x * width, y: p1.y * height, tx: p2.x * width, ty: p2.y * height, life: 1});
                }
            }

            signals = signals.filter(s => s.life > 0);
            signals.forEach(s => {
                s.life -= 0.01;
                ctx.strokeStyle = `rgba(5, 255, 255, ${s.life})`;
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.moveTo(s.x, s.y);
                ctx.lineTo(s.tx, s.ty);
                ctx.stroke();
            });

            planets.forEach(p => {
                ctx.fillStyle = p.color;
                ctx.beginPath();
                ctx.arc(p.x * width, p.y * height, p.r, 0, Math.PI * 2);
                ctx.fill();
                ctx.fillStyle = 'white';
                ctx.fillText(p.name, p.x * width + p.r + 2, p.y * height);
            });


            requestAnimationFrame(animate);
        };
        
        const resizeObserver = new ResizeObserver(() => {
            canvas.width = canvas.clientWidth;
            canvas.height = canvas.clientHeight;
        });
        resizeObserver.observe(canvas);
        
        const animId = requestAnimationFrame(animate);
        return () => {
            cancelAnimationFrame(animId);
            resizeObserver.disconnect();
        };

    }, []);

    return (
        <div className="h-full bg-gray-900 text-white flex flex-col relative">
            <div className="absolute top-0 left-0 right-0 p-4 z-10 bg-gradient-to-b from-black/80 to-transparent">
                <h2 className="text-xl font-bold text-cyan-300">📡 Artemis Network Monitor</h2>
                <p className="text-sm">Monitoring planetary harmonic signal paths.</p>
            </div>
            <canvas ref={canvasRef} className="w-full h-full" />
        </div>
    );
};