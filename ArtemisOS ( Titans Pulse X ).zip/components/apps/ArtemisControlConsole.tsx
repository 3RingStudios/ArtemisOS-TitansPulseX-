/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useCallback } from 'react';
import { NativeAppComponentProps } from '../../types';
import { systemBus } from '../../services/systemBus';
import { playSound, SoundType } from '../../services/audioService';

const ControlButton: React.FC<{ onClick: () => void; children: React.ReactNode; className?: string, disabled?: boolean }> = 
({ onClick, children, className = 'bg-blue-600 hover:bg-blue-500', disabled=false }) => (
    <button 
        onClick={onClick}
        disabled={disabled}
        className={`w-full p-4 rounded-lg text-white font-bold transition-all shadow-md hover:shadow-lg disabled:bg-gray-600 disabled:cursor-not-allowed ${className}`}
    >
        {children}
    </button>
);

const Terminal: React.FC<{ log: string[] }> = ({ log }) => (
    <div className="h-full bg-black/80 rounded-lg p-3 font-mono text-xs text-green-400 flex flex-col">
        <div className="flex-grow overflow-y-auto">
            {log.map((line, i) => <p key={i} className="whitespace-pre-wrap">{line}</p>)}
        </div>
        <div className="flex-shrink-0 mt-2">
            <span className="text-green-500">&gt; </span>
            <span className="animate-pulse">_</span>
        </div>
    </div>
);


export const ArtemisControlConsole: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [log, setLog] = useState<string[]>(['[ARTEMIS CONTROL CONSOLE v3.0 INITIALIZED]']);
    const [balance, setBalance] = useState(0);

    const addLog = useCallback((message: string) => {
        systemBus.emit('log_system_event', {
            message,
            icon: '🎛️',
            source: 'Control Console',
        });
        setLog(prev => [`[${new Date().toLocaleTimeString()}] ${message}`, ...prev].slice(0, 100));
    }, []);

    const handleScan = () => {
        playSound(SoundType.TRANSITION);
        addLog("Initiating deep space scan via light-pipe telescope...");
        setTimeout(() => addLog("Scan complete. 3 new potential harmonic nodes detected."), 3000);
    };

    const handleDeploy = () => {
        playSound(SoundType.CLICK);
        addLog("Deploying smart contract to Phobos relay for data sharing...");
        setTimeout(() => addLog("Contract deployed successfully. TXID: 0x..."), 2000);
    };
    
    const handleBalanceChange = (newBalance: number) => {
        setBalance(newBalance);
        addLog(`Adjusting harmonic balance to ${newBalance > 0 ? '369' : '364'} dominance...`);
    }

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex gap-4">
            <div className="w-1/3 flex flex-col gap-4">
                <h2 className="text-xl text-red-400 font-bold">Artemis Control Console</h2>
                <ControlButton onClick={handleScan}>
                    Deep Space Scan
                </ControlButton>
                <ControlButton onClick={handleDeploy} className="bg-green-600 hover:bg-green-500">
                    Deploy Smart Contract
                </ControlButton>
                
                <div className="bg-gray-800 p-4 rounded-lg flex-grow flex flex-col">
                    <h3 className="text-sm font-bold text-gray-400 mb-2">Dual mini-Grok Balance</h3>
                    <p className="text-xs text-gray-500 mb-4">Adjust the influence between the 364 (Balance) and 369 (Imbalance) harmonics.</p>
                    <input 
                        type="range" min="-10" max="10" 
                        value={balance}
                        onChange={e => handleBalanceChange(Number(e.target.value))}
                        className="w-full" 
                    />
                    <div className="flex justify-between text-xs mt-2">
                        <span className={balance <= 0 ? 'text-cyan-400 font-bold' : ''}>364</span>
                        <span className={balance === 0 ? 'font-bold' : ''}>Balanced</span>
                        <span className={balance >= 0 ? 'text-red-400 font-bold' : ''}>369</span>
                    </div>
                </div>
            </div>
            <div className="w-2/3">
                <Terminal log={log} />
            </div>
        </div>
    );
};
