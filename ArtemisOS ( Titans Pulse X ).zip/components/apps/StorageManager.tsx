/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useCallback } from 'react';
import { NativeAppComponentProps, StorageNote } from '../../types';
import { systemBus } from '../../services/systemBus';

// Simple IndexedDB wrapper
const dbName = "ArtemisOS-Storage";
const storeName = "Notes";

const openDB = (): Promise<IDBDatabase> => {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(dbName, 1);
        request.onupgradeneeded = () => {
            request.result.createObjectStore(storeName, { keyPath: "id", autoIncrement: true });
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
};

const getAllNotes = async (): Promise<StorageNote[]> => {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(storeName, 'readonly');
        const store = tx.objectStore(storeName);
        const request = store.getAll();
        request.onsuccess = () => resolve(request.result.sort((a,b) => b.id - a.id));
        request.onerror = () => reject(request.error);
    });
};

const addNote = async (text: string): Promise<void> => {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(storeName, 'readwrite');
        const store = tx.objectStore(storeName);
        const request = store.add({ text, createdAt: new Date() });
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
    });
};

const deleteNote = async (id: number): Promise<void> => {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(storeName, 'readwrite');
        const store = tx.objectStore(storeName);
        const request = store.delete(id);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
    });
};


export const StorageManager: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [storageInfo, setStorageInfo] = useState({ usage: 0, quota: 0 });
    const [notes, setNotes] = useState<StorageNote[]>([]);
    const [newNoteText, setNewNoteText] = useState('');

    const refreshStorageInfo = useCallback(() => {
        if (navigator.storage && navigator.storage.estimate) {
            navigator.storage.estimate().then(estimate => {
                setStorageInfo({
                    usage: estimate.usage || 0,
                    quota: estimate.quota || 0,
                });
            });
        }
    }, []);

    const refreshNotes = useCallback(async () => {
        try {
            const fetchedNotes = await getAllNotes();
            setNotes(fetchedNotes);
        } catch (error) {
            console.error("Failed to fetch notes from IndexedDB", error);
        }
    }, []);

    useEffect(() => {
        refreshStorageInfo();
        refreshNotes();
    }, [refreshStorageInfo, refreshNotes]);

    const handleAddNote = async () => {
        if (!newNoteText.trim()) return;
        await addNote(newNoteText);
        setNewNoteText('');
        refreshNotes();
        refreshStorageInfo(); // Update usage info
        systemBus.emit('log_system_event', {
            message: 'Note saved to IndexedDB.',
            icon: '📝',
            source: 'StorageManager',
        });
    };
    
    const handleDeleteNote = async (id: number) => {
        await deleteNote(id);
        refreshNotes();
        refreshStorageInfo();
    };

    const formatBytes = (bytes: number, decimals = 2) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    };
    
    const usagePercentage = storageInfo.quota > 0 ? (storageInfo.usage / storageInfo.quota) * 100 : 0;

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0">
                <h2 className="text-xl text-orange-400 font-bold">💽 Storage Manager</h2>
                <p className="text-sm text-gray-400">Manage persistent offline data and cache.</p>
            </div>
            
            <div className="flex-shrink-0 bg-gray-800/50 p-4 rounded-lg">
                <h3 className="text-sm font-bold text-gray-400">Browser Storage Usage</h3>
                <div className="w-full bg-gray-700 rounded-full h-4 my-2">
                    <div className="bg-orange-500 h-4 rounded-full" style={{ width: `${usagePercentage}%` }}></div>
                </div>
                <p className="text-xs font-mono text-center">
                    {formatBytes(storageInfo.usage)} / {formatBytes(storageInfo.quota)} ({usagePercentage.toFixed(2)}%)
                </p>
            </div>

            <div className="flex-grow flex flex-col bg-gray-800/50 rounded-lg overflow-hidden">
                 <h3 className="p-3 font-bold text-gray-400 border-b border-gray-700">IndexedDB Notes (Offline Persistent)</h3>
                 <div className="p-3 flex gap-2">
                    <input 
                        type="text"
                        value={newNoteText}
                        onChange={e => setNewNoteText(e.target.value)}
                        placeholder="Type a new note..."
                        className="flex-grow p-2 rounded bg-gray-900 border border-gray-600 outline-none focus:border-orange-400"
                    />
                    <button onClick={handleAddNote} className="llm-button m-0 bg-orange-600 hover:bg-orange-700">Add Note</button>
                 </div>
                 <div className="flex-grow overflow-y-auto px-3 pb-3">
                    {notes.map(note => (
                        <div key={note.id} className="bg-gray-700/50 p-2 rounded flex justify-between items-center mb-2">
                            <div>
                                <p>{note.text}</p>
                                <p className="text-xs text-gray-500">{note.createdAt.toLocaleString()}</p>
                            </div>
                            <button onClick={() => handleDeleteNote(note.id)} className="text-red-500 hover:text-red-400 text-lg">&times;</button>
                        </div>
                    ))}
                 </div>
            </div>
        </div>
    );
};