/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { NativeAppComponentProps } from '../../types';
import { playSound, SoundType } from '../../services/audioService';

// Mock Data and Types
interface AINode {
    id: string;
    name: string;
    status: 'online' | 'syncing' | 'isolated';
    load: number;
}

const initialNodes: AINode[] = [
    { id: 'node_1', name: 'Primary Core', status: 'online', load: 75 },
    { id: 'node_2', name: 'Vision Model', status: 'online', load: 45 },
    { id: 'node_3', name: 'Audio Synth', status: 'syncing', load: 60 },
    { id: 'node_4', name: 'External Contributor', status: 'isolated', load: 0 },
];

const Panel: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className = '' }) => (
    <div className={`bg-gray-800/50 border border-gray-700/50 rounded-lg flex flex-col ${className}`}>
        <h3 className="text-sm font-bold text-cyan-400 p-2 border-b border-gray-700/50 flex-shrink-0">{title}</h3>
        <div className="flex-grow p-2 overflow-y-auto">{children}</div>
    </div>
);

const Terminal: React.FC<{ title: string; log: string[] }> = ({ title, log }) => (
    <div className="h-full flex flex-col">
        <h4 className="text-xs text-yellow-300 mb-1">{title}</h4>
        <div className="flex-grow bg-black/50 p-1 rounded-sm text-xs overflow-y-auto">
            {log.map((line, i) => <p key={i} className="whitespace-pre-wrap leading-tight">{line}</p>)}
        </div>
    </div>
);

export const AetherialDevNetHub: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [pythonCode, setPythonCode] = useState("# Real-time Python Builder\n\ndef main():\n    print('Aetherial DevNet is online.')\n\nmain()");
    const [mainLog, setMainLog] = useState<string[]>(['[CORE] Awaiting command...']);
    const [frontEndLog, setFrontEndLog] = useState<string[]>(['[VITE] HMR connected.']);
    const [backEndLog, setBackEndLog] = useState<string[]>(['[RUST] cargo check...']);
    const [nodes, setNodes] = useState<AINode[]>(initialNodes);
    const [stats, setStats] = useState({ cpu: 25, ram: 45, network: 10 });
    const canvasRef = useRef<HTMLCanvasElement>(null);
    
    const addLog = useCallback((setter: React.Dispatch<React.SetStateAction<string[]>>, message: string) => {
        setter(prev => [message, ...prev].slice(0, 50));
    }, []);

    useEffect(() => {
        const interval = setInterval(() => {
            setStats({
                cpu: Math.random() * 80 + 10,
                ram: Math.random() * 60 + 20,
                network: Math.random() * 30 + 5,
            });
            if (Math.random() > 0.8) {
                addLog(setFrontEndLog, `[SYNTH] UI element updated successfully.`);
            }
             if (Math.random() > 0.7) {
                addLog(setBackEndLog, `[API] GET /stats/nodes - 200 OK`);
            }
        }, 2000);
        return () => clearInterval(interval);
    }, [addLog]);
    
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        let time = 0;
        const animate = () => {
            time += 0.02;
            const { width, height } = canvas;
            ctx.clearRect(0, 0, width, height);
            ctx.strokeStyle = '#ec4899';
            ctx.lineWidth = 2;
            ctx.beginPath();
            for(let x=0; x < width; x++) {
                const y = height/2 + Math.sin(x*0.05 + time) * 20 * Math.sin(x*0.01);
                x === 0 ? ctx.moveTo(x,y) : ctx.lineTo(x,y);
            }
            ctx.stroke();
            requestAnimationFrame(animate);
        };
        const animId = requestAnimationFrame(animate);
        return () => cancelAnimationFrame(animId);
    }, []);

    const runCode = () => {
        playSound(SoundType.CLICK);
        addLog(setMainLog, `[PYTHON] Executing code...`);
        setTimeout(() => addLog(setMainLog, `[PYTHON] > Aetherial DevNet is online.`), 500);
    };

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-mono text-sm p-2 flex flex-col gap-2">
            <div className="flex-shrink-0 flex justify-between items-center px-2">
                <h2 className="text-lg text-indigo-400 font-bold">🧠 Aetherial DevNet Hub</h2>
                <div className="text-xs text-green-400 animate-pulse">● System Learning</div>
            </div>

            <div className="flex-grow grid grid-cols-3 grid-rows-3 gap-2 overflow-hidden">
                <Panel title="Live Python Builder" className="col-span-2 row-span-2">
                    <textarea 
                        value={pythonCode}
                        onChange={e => setPythonCode(e.target.value)}
                        className="w-full h-full bg-black/50 p-2 rounded-sm resize-none outline-none focus:ring-1 focus:ring-cyan-400"
                        spellCheck="false"
                    />
                    <div className="flex-shrink-0 pt-2 flex gap-2">
                        <button onClick={runCode} className="llm-button text-xs py-1 px-2 m-0 bg-green-600 hover:bg-green-700">▶ Run</button>
                        <button className="llm-button text-xs py-1 px-2 m-0 bg-blue-600 hover:bg-blue-700">AI Correct</button>
                    </div>
                </Panel>
                
                <Panel title="Adaptive Terminals">
                   <Terminal title="Main Dev" log={mainLog} />
                </Panel>
                 <Panel title="Frontend Monitor">
                   <Terminal title="Vite / UI" log={frontEndLog} />
                </Panel>
                 <Panel title="Backend Monitor">
                   <Terminal title="Rust / API" log={backEndLog} />
                </Panel>

                <Panel title="System & Network" className="col-span-1 row-span-2">
                    <div className="h-full flex flex-col gap-2">
                        <div>
                            <h4 className="text-xs font-bold mb-1">System Stats</h4>
                            <p>CPU: {stats.cpu.toFixed(1)}%</p>
                            <p>RAM: {stats.ram.toFixed(1)}%</p>
                            <p>NET: {stats.network.toFixed(1)} Mbps</p>
                        </div>
                        <div className="flex-grow">
                             <h4 className="text-xs font-bold mb-1 mt-2">Detected AI Nodes</h4>
                             {nodes.map(node => (
                                <div key={node.id} className="flex justify-between items-center text-xs">
                                    <span>{node.name}</span>
                                    <span className={node.status === 'online' ? 'text-green-400' : 'text-yellow-400'}>{node.status}</span>
                                </div>
                             ))}
                        </div>
                    </div>
                </Panel>
                
                <Panel title="Generative AI Synthesis">
                    <canvas ref={canvasRef} className="w-full h-full bg-black/50 rounded-sm" />
                </Panel>
            </div>
        </div>
    );
};