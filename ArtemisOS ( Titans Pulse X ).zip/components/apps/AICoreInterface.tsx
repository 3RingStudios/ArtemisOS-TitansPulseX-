/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState } from 'react';
import { NativeAppComponentProps } from '../../types';
import { systemBus } from '../../services/systemBus';

export const AICoreInterface: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [prompt, setPrompt] = useState('');

    const handleExecute = () => {
        if (!prompt.trim()) return;

        // Send message to the main AI companion bus
        systemBus.emit('send_ai_chat_message', prompt);
        
        // Close this app to show the main companion window
        systemBus.emit('execute_command', { command: 'close_app', appId: 'ai_core_interface_app' });

        setPrompt('');
    };

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0 pb-2 border-b border-gray-700">
                <h2 className="text-xl text-purple-300 font-bold">✨ AI Core Interface</h2>
                <p className="text-sm text-gray-400">Direct access to the NeoCor AI System's generative and reasoning engine.</p>
            </div>
            <div className="flex-grow bg-black/30 rounded-lg p-4 flex flex-col justify-end">
                 <div className="flex-grow overflow-y-auto text-sm">
                    <p className="text-gray-400">[AI CORE]: System online. Awaiting command. Your prompt will be sent to the main AI Companion.</p>
                 </div>
                 <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleExecute();
                        }
                    }}
                    placeholder="Enter your command or prompt here... (e.g., 'Draft a proposal for a decentralized data market on Mars.')"
                    className="w-full h-24 p-2 mt-4 rounded-md bg-gray-800 border border-gray-600 focus:border-purple-400 outline-none resize-none"
                />
            </div>
             <button onClick={handleExecute} className="w-full py-3 bg-purple-600 hover:bg-purple-700 rounded-lg font-bold">
                Execute Command
            </button>
        </div>
    );
};