/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { NativeAppComponentProps } from '../../types';
import { playSound, SoundType } from '../../services/audioService';

const SCAN_STEPS = [
    { text: "Analyzing component registry...", time: 500 },
    { text: "Scanning `StellarCartography.tsx` for static data sources...", time: 700 },
    { text: "Verifying UI interactivity in `ArtemisOperationsHub.tsx`...", time: 800 },
    { text: "Checking for core feature completeness in `FlightDynamicsLab.tsx`...", time: 600 },
    { text: "Auditing `Taskbar.tsx` for missing UX patterns...", time: 700 },
    { text: "Scan Complete. Found 4 areas for enhancement.", time: 500 },
];

const FOUND_ISSUES = [
    { id: 1, title: 'Static Data Source', component: 'StellarCartography.tsx', description: 'Celestial bodies are hardcoded. System should generate them procedurally for dynamic content.', fix: 'Implemented procedural star system generation.' },
    { id:2, title: 'Poor UX', component: 'ArtemisOperationsHub.tsx', description: 'All functions are in a single, dense view. This should be refactored into a tabbed interface.', fix: 'Rebuilt component with a tabbed layout for Security, Contracts, and Treasury.' },
    { id: 3, title: 'Incomplete Feature', component: 'FlightDynamicsLab.tsx', description: 'Vessel assembly is possible, but the core "launch" feature is missing.', fix: 'Added a "Launchpad" view with a simulated telemetry feed.' },
    { id: 4, title: 'Missing Toolbar Feature', component: 'Taskbar.tsx', description: 'No context menu available for running apps, limiting window management.', fix: 'Added a right-click context menu with Minimize/Close actions.' },
];

export const ArtemisVerifier: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [scanLog, setScanLog] = useState<string[]>([]);
    const [isScanning, setIsScanning] = useState(false);
    const [isComplete, setIsComplete] = useState(false);
    const [fixesApplied, setFixesApplied] = useState(false);

    const runScan = () => {
        setIsScanning(true);
        setScanLog([]);
        setIsComplete(false);
        setFixesApplied(false);
        playSound(SoundType.TRANSITION);

        let stepIndex = 0;
        const runNextStep = () => {
            if (stepIndex < SCAN_STEPS.length) {
                setScanLog(prev => [...prev, SCAN_STEPS[stepIndex].text]);
                setTimeout(runNextStep, SCAN_STEPS[stepIndex].time);
                stepIndex++;
            } else {
                setIsScanning(false);
                setIsComplete(true);
                playSound(SoundType.OPEN);
            }
        };
        runNextStep();
    };
    
    const handleApplyFixes = () => {
        playSound(SoundType.CLICK);
        setFixesApplied(true);
    }

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0 pb-2 border-b border-gray-700">
                <h2 className="text-xl text-lime-300 font-bold">✅ Artemis Verifier</h2>
                <p className="text-sm text-gray-400">System integrity and feature completeness scanner.</p>
            </div>
            
            <div className="flex-grow flex gap-4 overflow-hidden">
                <div className="w-1/2 flex flex-col">
                    <button onClick={runScan} disabled={isScanning} className="llm-button m-0 mb-4 w-full disabled:bg-gray-600">
                        {isScanning ? 'Scanning...' : (isComplete ? 'Scan Again' : 'Start System Scan')}
                    </button>
                    <div className="flex-grow bg-black/30 rounded-lg p-3 font-mono text-xs text-lime-400 overflow-y-auto">
                        {scanLog.map((line, i) => <p key={i}>{`> ${line}`}</p>)}
                        {isScanning && <p className="animate-pulse">{'> _'}</p>}
                    </div>
                </div>
                <div className="w-1/2 flex flex-col">
                    <h3 className="text-lg font-semibold mb-2">Scan Results</h3>
                    <div className="flex-grow bg-gray-800/50 rounded-lg p-3 overflow-y-auto space-y-3">
                        {!isComplete && <p className="text-gray-500">Awaiting scan completion...</p>}
                        {isComplete && FOUND_ISSUES.map(issue => (
                            <div key={issue.id} className="bg-gray-700/50 p-2 rounded">
                                <p className="font-bold text-yellow-300">{issue.title}: <span className="text-gray-400 font-mono text-xs">{issue.component}</span></p>
                                <p className="text-sm mt-1">{issue.description}</p>
                                {fixesApplied && <p className="text-sm mt-2 text-green-400 font-bold">✓ Fix: {issue.fix}</p>}
                            </div>
                        ))}
                    </div>
                     {isComplete && !fixesApplied && (
                        <button onClick={handleApplyFixes} className="llm-button m-0 mt-4 w-full bg-green-600 hover:bg-green-700">Apply All Fixes</button>
                    )}
                </div>
            </div>
        </div>
    );
};