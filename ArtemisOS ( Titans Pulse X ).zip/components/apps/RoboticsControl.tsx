/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { NativeAppComponentProps, RoboticArmState } from '../../types';
import { systemBus } from '../../services/systemBus';

export const RoboticsControl: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [armState, setArmState] = useState<RoboticArmState>({
        baseRotation: 0, shoulderAngle: -45, elbowAngle: 90, wristAngle: 0, gripper: 50
    });
    const [log, setLog] = useState<string[]>(['[Robotics Control Online]']);

    const addLog = useCallback((message: string) => {
        setLog(prev => [`[${new Date().toLocaleTimeString()}] ${message}`, ...prev].slice(0, 50));
        systemBus.emit('log_system_event', { message, icon: '🦾', source: 'RoboticsControl' });
    }, []);
    
    const handleControlChange = (control: keyof RoboticArmState, value: number) => {
        setArmState(prev => ({ ...prev, [control]: value }));
        addLog(`CMD: SET ${control.toUpperCase()} TO ${value}`);
    };

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const draw = () => {
            const { width, height } = canvas;
            ctx.fillStyle = '#111827';
            ctx.fillRect(0, 0, width, height);

            ctx.save();
            ctx.translate(width / 2, height * 0.9);

            // Base
            ctx.fillStyle = '#4b5563';
            ctx.fillRect(-50, 0, 100, 20);

            // Arm Segments
            ctx.rotate(armState.baseRotation * Math.PI / 180);
            
            // Shoulder
            ctx.rotate(armState.shoulderAngle * Math.PI / 180);
            ctx.fillStyle = '#6b7280';
            ctx.fillRect(-10, -100, 20, 100);
            ctx.translate(0, -100);

            // Elbow
            ctx.rotate(armState.elbowAngle * Math.PI / 180);
            ctx.fillStyle = '#9ca3af';
            ctx.fillRect(-8, -80, 16, 80);
            ctx.translate(0, -80);
            
            // Wrist & Gripper
            ctx.rotate(armState.wristAngle * Math.PI / 180);
            ctx.fillStyle = '#d1d5db';
            const gripperOpen = armState.gripper / 100 * 15;
            ctx.fillRect(-15 - gripperOpen, -20, 15, 5); // Left claw
            ctx.fillRect(gripperOpen, -20, 15, 5); // Right claw

            ctx.restore();
        };

        const animId = requestAnimationFrame(draw);
        return () => cancelAnimationFrame(animId);
    }, [armState]);

    const ControlSlider: React.FC<{ label: string; value: number; min: number; max: number; onChange: (val: number) => void }> = 
    ({ label, value, min, max, onChange }) => (
        <div>
            <label className="text-sm font-bold text-gray-400 flex justify-between">
                <span>{label}</span>
                <span>{value}°</span>
            </label>
            <input type="range" min={min} max={max} value={value}
                   onChange={e => onChange(Number(e.target.value))} className="w-full" />
        </div>
    );

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex gap-4">
            <div className="w-2/3 flex flex-col gap-4">
                <div className="flex-shrink-0">
                    <h2 className="text-xl text-orange-400 font-bold">🦾 Robotics Control Center</h2>
                </div>
                <div className="flex-grow bg-black rounded-lg">
                    <canvas ref={canvasRef} className="w-full h-full" />
                </div>
                <div className="flex-shrink-0 bg-gray-800 p-2 rounded-lg grid grid-cols-2 gap-4">
                     <div>
                        <p className="text-sm font-bold text-gray-400">Sensor Data (Simulated)</p>
                        <p className="font-mono text-xs">Proximity: 1.2m</p>
                        <p className="font-mono text-xs">Gripper Pressure: {(armState.gripper * 2.5).toFixed(1)} N</p>
                        <p className="font-mono text-xs">Ambient Temp: 22.1°C</p>
                    </div>
                    <div>
                         <button className="llm-button w-full m-0 bg-red-600 hover:bg-red-700">EMERGENCY STOP</button>
                    </div>
                </div>
            </div>
            <div className="w-1/3 flex flex-col gap-4">
                <div className="bg-gray-800 p-4 rounded-lg flex-grow flex flex-col">
                    <h3 className="text-lg font-bold mb-4">Actuator Controls</h3>
                    <div className="space-y-4">
                        <ControlSlider label="Base Rotation" value={armState.baseRotation} min={-90} max={90} onChange={v => handleControlChange('baseRotation', v)} />
                        <ControlSlider label="Shoulder Angle" value={armState.shoulderAngle} min={-90} max={0} onChange={v => handleControlChange('shoulderAngle', v)} />
                        <ControlSlider label="Elbow Angle" value={armState.elbowAngle} min={0} max={140} onChange={v => handleControlChange('elbowAngle', v)} />
                        <ControlSlider label="Wrist Angle" value={armState.wristAngle} min={-90} max={90} onChange={v => handleControlChange('wristAngle', v)} />
                        <div>
                            <label className="text-sm font-bold text-gray-400">Gripper ({armState.gripper}%)</label>
                            <input type="range" min="0" max="100" value={armState.gripper} onChange={e => handleControlChange('gripper', Number(e.target.value))} className="w-full" />
                        </div>
                    </div>
                </div>
                <div className="bg-black/50 p-2 rounded-lg flex-grow flex flex-col">
                    <h3 className="font-bold text-sm text-gray-400 mb-2">Command Log</h3>
                    <div className="flex-grow overflow-y-auto font-mono text-xs space-y-1">
                        {log.map((line, i) => <p key={i}>{line}</p>)}
                    </div>
                </div>
            </div>
        </div>
    );
};