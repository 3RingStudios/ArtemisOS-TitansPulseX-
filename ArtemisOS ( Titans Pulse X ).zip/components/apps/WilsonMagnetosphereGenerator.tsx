/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { NativeAppComponentProps } from '../../types';

type Tab = 'generator' | 'telescope';

const TabButton: React.FC<{ label: string; tab: Tab; activeTab: Tab; onClick: (tab: Tab) => void; }> = ({ label, tab, activeTab, onClick }) => (
  <button
    onClick={() => onClick(tab)}
    className={`px-4 py-2 text-sm font-medium transition-colors rounded-t-lg border-b-2 ${
      activeTab === tab ? 'border-cyan-400 text-white' : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-500'
    }`}
  >
    {label}
  </button>
);

const GeneratorControls: React.FC = () => (
    <div className="p-4 space-y-4">
        <div>
            <label className="text-xs font-bold text-gray-400">Pillar RPM</label>
            <input type="range" min="6000" max="14000" defaultValue="14000" className="w-full" />
            <p className="text-center text-sm">14,000 RPM</p>
        </div>
        <div>
            <label className="text-xs font-bold text-gray-400">Canister Ring Cycle</label>
            <input type="range" min="10" max="100" defaultValue="33" className="w-full" />
            <p className="text-center text-sm">33 Cycles/Min</p>
        </div>
         <div>
            <label className="text-xs font-bold text-gray-400">Particle Collision Rate</label>
            <input type="range" min="1000" max="66000" defaultValue="33000" className="w-full" />
            <p className="text-center text-sm">33,000 collisions/sec</p>
        </div>
        <div className="flex justify-between items-center">
            <button className="text-xs px-3 py-1 bg-blue-600 rounded">Inject Particles</button>
            <div className="flex items-center gap-2 text-xs">
                <label htmlFor="pulsar-toggle">Mini Pulsar</label>
                <input type="checkbox" id="pulsar-toggle" className="toggle-checkbox" />
            </div>
        </div>
    </div>
);

const TelescopeControls: React.FC = () => (
    <div className="p-4 space-y-4">
        <div>
            <label className="text-xs font-bold text-gray-400">Harmonic Balance (364 vs 369)</label>
             <input type="range" min="-10" max="10" defaultValue="0" className="w-full" />
            <div className="flex justify-between text-xs">
                <span>364 (Balance)</span>
                <span>369 (Imbalance)</span>
            </div>
        </div>
        <div>
            <label className="text-xs font-bold text-gray-400">Ionic Thruster Output</label>
            <input type="range" min="1000" max="9400" defaultValue="9400" className="w-full" />
            <p className="text-center text-sm">9,400 W</p>
        </div>
        <button className="w-full text-sm py-2 bg-purple-600 rounded">Engage Dispersion Shield</button>
    </div>
);


const SimulationCanvas: React.FC = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let frame = 0;
        const animate = () => {
            frame++;
            const { width, height } = canvas;
            ctx.clearRect(0, 0, width, height);

            // Draw data wave tunnel
            for (let i = 0; i < 20; i++) {
                const progress = (i + (frame * 0.01)) % 20;
                const r = (progress / 20) * (width / 4);
                const alpha = 1 - (progress / 20);
                ctx.strokeStyle = `rgba(0, 255, 255, ${alpha * 0.5})`;
                ctx.beginPath();
                ctx.arc(width / 2, height / 2, r, 0, Math.PI * 2);
                ctx.stroke();
            }
            
            // Draw helical microstrings
            ctx.strokeStyle = '#f472b6'; // pink-400
            ctx.lineWidth = 1.5;
            for(let i=0; i < 2; i++) {
                ctx.beginPath();
                for (let x = 0; x < width; x++) {
                    const angle = 0.1 * x + frame * 0.05 + i * Math.PI;
                    const y = height / 2 + Math.sin(angle) * 50 * (x / width);
                    if (x === 0) ctx.moveTo(x, y);
                    else ctx.lineTo(x, y);
                }
                ctx.stroke();
            }

            requestAnimationFrame(animate);
        };

        const resizeObserver = new ResizeObserver(() => {
            canvas.width = canvas.clientWidth;
            canvas.height = canvas.clientHeight;
        });
        resizeObserver.observe(canvas);

        const animId = requestAnimationFrame(animate);
        return () => {
            cancelAnimationFrame(animId);
            resizeObserver.disconnect();
        };

    }, []);

    return <canvas ref={canvasRef} className="w-full h-full bg-black rounded-lg" />;
};


export const WilsonMagnetosphereGenerator: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [activeTab, setActiveTab] = useState<Tab>('generator');

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans flex">
            <div className="w-1/3 h-full flex flex-col p-4 border-r border-gray-700">
                 <div className="flex-shrink-0 pb-2 border-b border-gray-600">
                    <h2 className="text-xl text-cyan-300 font-bold">Wilson M. Generator</h2>
                    <p className="text-sm text-gray-400">Planetary & Universal Harmonics</p>
                </div>

                <div className="border-b border-gray-700 mt-4">
                    <nav className="-mb-px flex space-x-4">
                        <TabButton label="Generator Core" tab="generator" activeTab={activeTab} onClick={setActiveTab} />
                        <TabButton label="Dual-Telescopic" tab="telescope" activeTab={activeTab} onClick={setActiveTab} />
                    </nav>
                </div>
                
                <div className="py-4">
                    {activeTab === 'generator' ? <GeneratorControls /> : <TelescopeControls />}
                </div>

                <div className="mt-auto bg-gray-800 p-3 rounded-lg">
                    <h4 className="text-sm font-bold mb-2">Telemetry</h4>
                    <div className="font-mono text-xs space-y-1">
                        <p>Halo Range: <span className="text-green-400">333,000 km</span></p>
                        <p>Frequency Output: <span className="text-green-400">13.333 MHz</span></p>
                        <p>System Status: <span className="text-green-400">Nominal</span></p>
                    </div>
                </div>
            </div>
            <div className="w-2/3 h-full p-4 flex flex-col">
                 <h3 className="text-lg font-semibold text-center mb-2">Live Simulation Feed</h3>
                 <div className="flex-grow">
                    <SimulationCanvas />
                 </div>
            </div>
        </div>
    );
};