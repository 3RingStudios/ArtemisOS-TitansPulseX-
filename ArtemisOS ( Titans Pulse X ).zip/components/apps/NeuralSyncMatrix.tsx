/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useEffect, useRef, useState } from 'react';
import { NativeAppComponentProps, DataPacket, Harmonic } from '../../types';

class Particle {
    x: number; y: number;
    vx: number; vy: number;
    radius: number;
    color: string;
    originalY: number;

    constructor(width: number, height: number, harmonicBalance: number) {
        this.x = Math.random() * width;
        this.y = Math.random() * height;
        this.originalY = this.y;
        this.vx = Math.random() * 0.5 + 0.2; // Flow from left to right
        this.vy = harmonicBalance * (Math.random() - 0.5) * 0.1; // Vertical drift based on balance
        this.radius = Math.random() * 1.5 + 0.5;
        this.color = Math.random() > 0.5 ? '#38bdf8' : '#ec4899'; // cyan or pink
    }

    update(width: number, height: number, time: number) {
        this.x += this.vx;
        this.y += this.vy;
        
        // Sine wave motion
        this.y += Math.sin(this.x * 0.02 + time) * 0.5;


        if (this.x > width + this.radius) {
            this.x = -this.radius;
            this.originalY = Math.random() * height;
        }
        if (this.y > height + this.radius || this.y < -this.radius) {
            this.vy *= -1;
        }
    }

    draw(ctx: CanvasRenderingContext2D) {
        ctx.fillStyle = this.color;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fill();
    }
}

export const NeuralSyncMatrix: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [stats, setStats] = useState({ packetRate: 0, dataVolume: 0, '364': 50, '369': 50 });
    
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let time = 0;
        let particles: Particle[] = [];
        let animationId: number;
        let resizeAnimationId: number;
        
        const balance = (stats['369'] - stats['364']) / 10;

        const animate = () => {
            time += 0.02;
            const { width, height } = canvas;
            ctx.clearRect(0, 0, width, height);

            particles.forEach(p => {
                p.update(width, height, time);
                p.draw(ctx);
            });
            
            animationId = requestAnimationFrame(animate);
        };
        
        const resizeObserver = new ResizeObserver(() => {
            resizeAnimationId = window.requestAnimationFrame(() => {
                if (canvas) {
                    canvas.width = canvas.clientWidth;
                    canvas.height = canvas.clientHeight;
                    particles = Array.from({ length: 200 }, () => new Particle(canvas.width, canvas.height, balance));
                }
            });
        });
        
        // Initial setup
        canvas.width = canvas.clientWidth;
        canvas.height = canvas.clientHeight;
        particles = Array.from({ length: 200 }, () => new Particle(canvas.width, canvas.height, balance));

        resizeObserver.observe(canvas);
        animate();
        
        const statsInterval = setInterval(() => {
            setStats(prev => {
                const newBalance364 = Math.max(0, Math.min(100, prev['364'] + (Math.random() - 0.5) * 5));
                const newBalance369 = 100 - newBalance364;
                return {
                    packetRate: Math.random() * 500 + 1200,
                    dataVolume: Math.random() * 10 + 80,
                    '364': newBalance364,
                    '369': newBalance369,
                }
            });
        }, 1500);

        return () => {
            cancelAnimationFrame(animationId);
            cancelAnimationFrame(resizeAnimationId);
            resizeObserver.disconnect();
            clearInterval(statsInterval);
        }
    }, [stats]);

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans flex relative">
             <div className="w-2/3 h-full">
                <canvas ref={canvasRef} className="w-full h-full" />
             </div>
             <div className="w-1/3 h-full bg-black/30 backdrop-blur-sm p-4 border-l border-gray-700 flex flex-col">
                <h2 className="text-xl text-pink-400 font-bold mb-4 pb-2 border-b border-gray-600">🧠 Neural Sync Matrix</h2>
                <h3 className="font-bold text-gray-400 text-sm mb-2">Live Data Telemetry</h3>
                <div className="space-y-3 font-mono text-sm">
                    <div className="bg-gray-800/50 p-2 rounded">
                        <p>Packet Rate:</p>
                        <p className="text-2xl text-cyan-300">{stats.packetRate.toFixed(0)} <span className="text-base text-gray-400">packets/sec</span></p>
                    </div>
                    <div className="bg-gray-800/50 p-2 rounded">
                        <p>Data Volume:</p>
                        <p className="text-2xl text-cyan-300">{stats.dataVolume.toFixed(2)} <span className="text-base text-gray-400">GB/sec</span></p>
                    </div>
                     <div className="bg-gray-800/50 p-2 rounded">
                        <p>Grok Harmonic Balance:</p>
                        <div className="w-full bg-gray-600 rounded-full h-4 my-1 flex">
                            <div className="bg-cyan-400 h-4 rounded-l-full text-center text-black text-xs font-bold" style={{width: `${stats['364']}%`}}>{stats['364'].toFixed(0)}%</div>
                            <div className="bg-red-400 h-4 rounded-r-full text-center text-black text-xs font-bold" style={{width: `${stats['369']}%`}}>{stats['369'].toFixed(0)}%</div>
                        </div>
                         <div className="flex justify-between text-xs">
                             <span>364 (Balance)</span>
                             <span>369 (Imbalance)</span>
                         </div>
                    </div>
                </div>
             </div>
        </div>
    );
};