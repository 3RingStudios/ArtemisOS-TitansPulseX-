/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { NativeAppComponentProps } from '../../types';
import { systemBus } from '../../services/systemBus';
import { playSound, SoundType } from '../../services/audioService';

export const DataCruncher: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [isWorking, setIsWorking] = useState(false);
    const [progress, setProgress] = useState(0);
    const [log, setLog] = useState<string[]>(['[Worker Ready]']);
    const workerRef = useRef<Worker | null>(null);

    useEffect(() => {
        // Initialize the worker
        workerRef.current = new Worker('/workers/dataCruncher.js');

        workerRef.current.onmessage = (e) => {
            const { type, message, progress: p } = e.data;
            if (type === 'log') {
                setLog(prev => [message, ...prev].slice(0, 100));
            } else if (type === 'progress') {
                setProgress(p);
            } else if (type === 'done') {
                setIsWorking(false);
                setProgress(100);
                 systemBus.emit('log_system_event', {
                    message: 'Background data crunching complete.',
                    icon: '🔢',
                    source: 'DataCruncher',
                });
                playSound(SoundType.OPEN);
            }
        };

        // Cleanup on unmount
        return () => {
            workerRef.current?.terminate();
        };
    }, []);

    const startWork = () => {
        if (isWorking || !workerRef.current) return;
        setIsWorking(true);
        setProgress(0);
        setLog(['[Task Started] Sending job to background worker...']);
        playSound(SoundType.TRANSITION);
        
        const dataSize = 5000; // Simulate 5000 records
        workerRef.current.postMessage({ task: 'start', dataSize });
    };

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0">
                <h2 className="text-xl text-green-400 font-bold">🔢 Data Cruncher (Web Worker)</h2>
                <p className="text-sm text-gray-400">Perform heavy computations in the background without freezing the UI.</p>
            </div>
            
            <div className="flex-shrink-0 bg-gray-800/50 p-4 rounded-lg flex flex-col items-center">
                <button onClick={startWork} disabled={isWorking} className="llm-button m-0 w-1/2 text-lg disabled:bg-gray-600">
                    {isWorking ? 'Processing...' : 'Start Heavy Calculation'}
                </button>
                <p className="text-xs text-gray-500 mt-2">This will simulate processing 5000 records in a separate thread.</p>
            </div>

            <div className="flex-grow flex flex-col bg-gray-800/50 rounded-lg overflow-hidden">
                <h3 className="p-3 font-bold text-gray-400 border-b border-gray-700">Worker Progress</h3>
                <div className="p-4">
                     <div className="w-full bg-gray-700 rounded-full h-6">
                        <div className="bg-green-500 h-6 rounded-full text-center text-black font-bold transition-all duration-500" style={{ width: `${progress}%` }}>
                            {progress.toFixed(0)}%
                        </div>
                    </div>
                </div>
                 <div className="flex-grow overflow-y-auto px-3 pb-3 font-mono text-xs">
                    {log.map((line, i) => <p key={i}>{`> ${line}`}</p>)}
                 </div>
            </div>
        </div>
    );
};