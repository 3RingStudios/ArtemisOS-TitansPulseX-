/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { NativeAppComponentProps } from '../../types';
import { identifyImage } from '../../services/geminiService';
import { classifyImage } from '../../services/localAIService';
import { systemBus } from '../../services/systemBus';
import { playSound, SoundType } from '../../services/audioService';

export const SystemScanner: React.FC<Partial<NativeAppComponentProps>> = () => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [isCameraOn, setIsCameraOn] = useState(false);
    const [status, setStatus] = useState('Camera is off. Grant permissions to start.');
    const [analysis, setAnalysis] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

     const logSystemEvent = (message: string, icon: string = '📸') => {
        systemBus.emit('log_system_event', {
            message, icon, source: 'SystemScanner',
        });
    };

    const startCamera = useCallback(async () => {
        setError(null);
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            try {
                setStatus('Requesting camera access...');
                const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
                if (videoRef.current) {
                    videoRef.current.srcObject = stream;
                    setIsCameraOn(true);
                    setStatus('Camera active. Point at an object and scan.');
                    playSound(SoundType.OPEN);
                }
            } catch (err: any) {
                setError(`Camera Error: ${err.message}. Please ensure permissions are granted.`);
                setStatus('Permission denied.');
                setIsCameraOn(false);
            }
        } else {
            setError("Your browser does not support the camera API.");
            setStatus('Camera not supported.');
        }
    }, []);

    const stopCamera = useCallback(() => {
        if (videoRef.current && videoRef.current.srcObject) {
            const stream = videoRef.current.srcObject as MediaStream;
            stream.getTracks().forEach(track => track.stop());
            videoRef.current.srcObject = null;
            setIsCameraOn(false);
            setStatus('Camera is off.');
            playSound(SoundType.CLOSE);
        }
    }, []);

    const handleScan = async () => {
        if (!isCameraOn || !videoRef.current || !canvasRef.current) return;
        
        setIsLoading(true);
        setAnalysis('');
        setError(null);
        setStatus('Scanning...');
        playSound(SoundType.TRANSITION);

        const video = videoRef.current;
        const canvas = canvasRef.current;
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const context = canvas.getContext('2d');
        if (!context) {
            setError("Could not get canvas context.");
            setIsLoading(false);
            return;
        }
        context.drawImage(video, 0, 0, canvas.width, canvas.height);

        const dataUrl = canvas.toDataURL('image/jpeg');
        const base64Data = dataUrl.split(',')[1];

        try {
            // Online-first approach
            setStatus('Querying Gemini Vision API...');
            const result = await identifyImage(base64Data, 'image/jpeg');
            setAnalysis(`[Online AI]: ${result}`);
            setStatus('Analysis complete.');
            logSystemEvent(`Scanned object identified by Gemini as: ${result.substring(0, 50)}...`, '👁️');
        } catch (e: any) {
            // Progressive AI Fallback
            setError(`Online AI failed: ${e.message}. Attempting local analysis...`);
            setStatus('Falling back to on-device AI...');
            logSystemEvent('Online AI failed, falling back to local model.', '🤖');
            try {
              const localResult = await classifyImage(canvas);
              setAnalysis(`[Local AI]: ${localResult}`);
              setStatus('Local analysis complete.');
              logSystemEvent(`Scanned object identified by local AI as: ${localResult.substring(0, 50)}...`);
            } catch (localError: any) {
              setError(`Local AI also failed: ${localError.message}`);
              setAnalysis('Both online and local AI failed.');
              setStatus('Error during local analysis.');
            }
        } finally {
            setIsLoading(false);
        }
    };

    // Cleanup camera on component unmount
    useEffect(() => {
        return () => {
            stopCamera();
        };
    }, [stopCamera]);


    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0 pb-2 border-b border-gray-700">
                <h2 className="text-xl text-amber-400 font-bold">📸 System Scanner</h2>
                <p className="text-sm text-gray-400">Use device camera and AI to identify objects. Features online/offline fallback.</p>
            </div>
            
            <div className="flex-grow bg-black rounded-lg relative flex items-center justify-center overflow-hidden">
                <video ref={videoRef} autoPlay playsInline className={`w-full h-full object-cover ${!isCameraOn && 'hidden'}`}></video>
                {!isCameraOn && (
                    <div className="text-center">
                        <p className="text-gray-500 mb-4">Camera feed is inactive.</p>
                        <button onClick={startCamera} className="llm-button">Start Camera</button>
                    </div>
                )}
                 <canvas ref={canvasRef} className="hidden"></canvas>
            </div>
            
            <div className="flex-shrink-0 grid grid-cols-3 gap-4 items-center">
                 <div className="col-span-2 bg-gray-800/50 p-3 rounded-lg min-h-[60px]">
                    <h3 className="font-bold text-sm text-gray-400">AI Analysis:</h3>
                    {isLoading ? (
                         <p className="text-amber-400 animate-pulse">{status}</p>
                    ) : (
                         <p className="text-lg">{analysis || 'Scan an object to see results.'}</p>
                    )}
                 </div>
                 <button onClick={handleScan} disabled={!isCameraOn || isLoading} className="llm-button m-0 h-full text-lg disabled:bg-gray-600">
                    Scan
                 </button>
            </div>

            <div className="flex-shrink-0 p-1 border-t border-gray-700 text-xs text-center text-gray-400">
                {error ? <span className="text-red-400">{error}</span> : <span>{status}</span>}
            </div>
        </div>
    );
};