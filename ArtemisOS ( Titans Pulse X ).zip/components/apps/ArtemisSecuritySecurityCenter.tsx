/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useCallback } from 'react';
import { NativeAppComponentProps, AppDefinition, AppPermission, FirewallRule, Contract, IntellectualProperty, PayoutMethod } from '../../types';
import { systemBus } from '../../services/systemBus';
import { playSound, SoundType } from '../../services/audioService';

type Tab = 'security' | 'contracts' | 'treasury';

const TabButton: React.FC<{ label: string; tab: Tab; activeTab: Tab; onClick: (tab: Tab) => void; }> = ({ label, tab, activeTab, onClick }) => (
  <button
    onClick={() => onClick(tab)}
    className={`px-4 py-2 text-sm font-medium transition-colors rounded-t-lg border-b-2 ${
      activeTab === tab ? 'border-green-400 text-white' : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-500'
    }`}
  >
    {label}
  </button>
);

// --- MOCK DATA ---
const initialPermissions: Record<string, AppPermission> = {
    'system_scanner_app': { fileSystem: 'none', network: 'full', sensors: 'read' },
    'data_archive_app': { fileSystem: 'read-write', network: 'none', sensors: 'none' },
    'host_bridge_app': { fileSystem: 'none', network: 'lan', sensors: 'none' },
};

const initialFirewallRules: FirewallRule[] = [
    { id: 'rule1', appId: 'any', direction: 'out', action: 'allow', target: 'lan' },
    { id: 'rule2', appId: 'ai_core_interface_app', direction: 'out', action: 'allow', target: 'any' },
    { id: 'rule3', appId: 'any', direction: 'out', action: 'block', target: 'any' },
];

const initialContracts: Contract[] = [
    { id: 'c1', title: 'Data Sharing Agreement with SpaceX', parties: ['ArtemisOS', 'SpaceX'], value: 5000, asset: 'A-ETH', status: 'Active' }
];

const initialIPs: IntellectualProperty[] = [
    { id: 'ip1', name: 'Quantum Graviton Lens', type: 'Vessel Blueprint', tokenId: '0x1a2b...', owner: 'ArtemisOS' }
];

// --- TAB COMPONENTS ---

const SecurityMatrixTab: React.FC<{ appDefinitions: AppDefinition[] }> = ({ appDefinitions }) => {
    const [permissions] = useState<Record<string, AppPermission>>(initialPermissions);
    const [rules] = useState(initialFirewallRules);
    
    const getPermission = (appId: string): AppPermission => permissions[appId] || { fileSystem: 'none', network: 'none', sensors: 'none' };
    const getAppName = (appId: string) => appId === 'any' ? 'Any App' : appDefinitions.find(a => a.id === appId)?.name || appId;

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div>
                <h4 className="font-bold mb-2">Application Permissions</h4>
                <div className="overflow-auto max-h-96">
                    <table className="w-full text-xs text-left">
                        <thead className="bg-gray-700/50 text-gray-300 uppercase sticky top-0">
                            <tr>
                                <th className="px-2 py-2">App</th>
                                <th className="px-2 py-2">Files</th>
                                <th className="px-2 py-2">Network</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-700">
                            {appDefinitions.map(app => (
                                <tr key={app.id}>
                                    <td className="px-2 py-2 font-medium">{app.name}</td>
                                    <td className="px-2 py-2">{getPermission(app.id).fileSystem}</td>
                                    <td className="px-2 py-2">{getPermission(app.id).network}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            <div>
                <h4 className="font-bold mb-2">Firewall Rules</h4>
                <div className="overflow-auto max-h-96">
                    <table className="w-full text-xs text-left">
                        <thead className="bg-gray-700/50 text-gray-300 uppercase sticky top-0">
                            <tr>
                                <th className="px-2 py-2">App</th>
                                <th className="px-2 py-2">Action</th>
                                <th className="px-2 py-2">Target</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-700">
                             {rules.map(rule => (
                                <tr key={rule.id}>
                                    <td className="px-2 py-2">{getAppName(rule.appId)}</td>
                                    <td className={`px-2 py-2 font-bold ${rule.action === 'allow' ? 'text-green-400' : 'text-red-400'}`}>{rule.action.toUpperCase()}</td>
                                    <td className="px-2 py-2 font-mono">{rule.target}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

const ContractsIPTab: React.FC = () => {
    const [contracts, setContracts] = useState<Contract[]>(initialContracts);
    const [ips, setIps] = useState<IntellectualProperty[]>(initialIPs);

    const handleGenerateContract = () => {
        playSound(SoundType.TRANSITION);
        const newContract: Contract = { id: `c${Date.now()}`, title: 'New AI-Generated Service Agreement', parties: ['ArtemisOS', 'xAI'], value: 1000, asset: 'API Credits', status: 'Draft' };
        setContracts(prev => [newContract, ...prev]);
        systemBus.emit('log_system_event', {
            message: `AI drafted new contract: ${newContract.title}`,
            icon: '📜', source: 'OperationsHub',
        });
    };
    
    const handleMintIP = () => {
        playSound(SoundType.CLICK);
        const newIp: IntellectualProperty = { id: `ip${Date.now()}`, name: 'Procedural Terrain Algorithm', type: 'Component Schematic', tokenId: `0x${Math.random().toString(16).slice(2, 10)}...`, owner: 'ArtemisOS' };
        setIps(prev => [newIp, ...prev]);
        systemBus.emit('log_system_event', {
            message: `Tokenized new IP: ${newIp.name} (NFT)`,
            icon: '💎', source: 'OperationsHub',
        });
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div>
                <h4 className="font-bold mb-2">AI Contract Generator</h4>
                <div className="bg-gray-800/50 p-3 rounded-lg space-y-2 text-sm mb-2">
                    <input type="text" placeholder="Contract Title..." className="w-full bg-gray-900 p-1 rounded border border-gray-600"/>
                    <input type="text" placeholder="Parties (e.g., ArtemisOS, SpaceX)" className="w-full bg-gray-900 p-1 rounded border border-gray-600"/>
                    <button onClick={handleGenerateContract} className="w-full py-1 bg-blue-600 hover:bg-blue-700 rounded">Draft Contract</button>
                </div>
                 <h4 className="font-bold mb-2 mt-4">Active Contracts</h4>
                <div className="overflow-auto max-h-64">
                    {contracts.map(c => <div key={c.id} className="text-xs p-2 bg-gray-700/50 rounded mb-1">{c.title} - <span className="font-bold">{c.status}</span></div>)}
                </div>
            </div>
             <div>
                <h4 className="font-bold mb-2">IP Tokenization (NFT)</h4>
                 <div className="bg-gray-800/50 p-3 rounded-lg space-y-2 text-sm mb-2">
                    <input type="text" placeholder="IP Name (e.g., Warp Drive Blueprint)" className="w-full bg-gray-900 p-1 rounded border border-gray-600"/>
                    <button onClick={handleMintIP} className="w-full py-1 bg-purple-600 hover:bg-purple-700 rounded">Mint Blueprint as NFT</button>
                </div>
                 <h4 className="font-bold mb-2 mt-4">Tokenized IP Assets</h4>
                <div className="overflow-auto max-h-64">
                    {ips.map(ip => <div key={ip.id} className="text-xs p-2 bg-gray-700/50 rounded mb-1">{ip.name} - ID: {ip.tokenId}</div>)}
                </div>
            </div>
        </div>
    );
};

const TreasuryPayoutsTab: React.FC = () => {
    const [treasury, setTreasury] = useState({ 'A-ETH': 1250.5, 'USDC': 25600.75 });
    const [walletConnected, setWalletConnected] = useState(false);
    
    const handleConnectWallet = () => {
        playSound(SoundType.OPEN);
        setWalletConnected(true);
        systemBus.emit('log_system_event', { message: `MetaMask wallet connected.`, icon: '🦊', source: 'OperationsHub' });
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div>
                <h4 className="font-bold mb-2">System Treasury</h4>
                <div className="bg-gray-800/50 p-3 rounded-lg space-y-2 text-lg font-mono">
                    <p>{treasury['A-ETH'].toFixed(4)} <span className="text-purple-400">A-ETH</span></p>
                    <p>{treasury['USDC'].toLocaleString('en-US', {style: 'currency', currency: 'USD'})} <span className="text-green-400">USDC</span></p>
                </div>
                 <h4 className="font-bold mb-2 mt-4">Wallet Integration</h4>
                 <div className="bg-gray-800/50 p-3 rounded-lg">
                    {walletConnected ? (
                        <div className="text-green-400">✅ MetaMask Connected (0x..a4b2)</div>
                    ) : (
                        <button onClick={handleConnectWallet} className="w-full py-2 bg-orange-600 hover:bg-orange-700 rounded flex items-center justify-center gap-2">
                           Connect Wallet
                        </button>
                    )}
                 </div>
            </div>
            <div>
                <h4 className="font-bold mb-2">Payouts (Fiat Off-Ramp)</h4>
                <div className="bg-gray-800/50 p-3 rounded-lg space-y-3">
                    <p className="text-xs text-gray-400">Simulate cashing out earnings to real-world payment processors.</p>
                    <input type="number" placeholder="Amount in USDC" className="w-full bg-gray-900 p-2 rounded border border-gray-600"/>
                    <button className="w-full py-2 bg-green-500 hover:bg-green-600 rounded">Payout to Cash App</button>
                    <button className="w-full py-2 bg-blue-500 hover:bg-blue-600 rounded">Payout to PayPal</button>
                </div>
            </div>
        </div>
    );
};

export const ArtemisOperationsHub: React.FC<Partial<NativeAppComponentProps>> = ({ appDefinitions = [] }) => {
    const [activeTab, setActiveTab] = useState<Tab>('security');
    
    const renderContent = () => {
        switch(activeTab) {
            case 'contracts': return <ContractsIPTab />;
            case 'treasury': return <TreasuryPayoutsTab />;
            case 'security':
            default:
                return <SecurityMatrixTab appDefinitions={appDefinitions} />;
        }
    };

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col">
            <div className="flex-shrink-0 mb-4 pb-2 border-b border-gray-700">
                <h2 className="text-xl text-green-300 font-bold">🏛️ Artemis Operations Hub</h2>
                <p className="text-sm text-gray-400">Manage security, AI-driven contracts, intellectual property, and system treasury.</p>
            </div>

            <div className="border-b border-gray-700">
                <nav className="-mb-px flex space-x-4">
                    <TabButton label="Security Matrix" tab="security" activeTab={activeTab} onClick={setActiveTab} />
                    <TabButton label="Contracts & IP" tab="contracts" activeTab={activeTab} onClick={setActiveTab} />
                    <TabButton label="Treasury & Payouts" tab="treasury" activeTab={activeTab} onClick={setActiveTab} />
                </nav>
            </div>

            <div className="flex-grow bg-gray-800 rounded-b-lg overflow-y-auto p-4">
                {renderContent()}
            </div>
        </div>
    );
};