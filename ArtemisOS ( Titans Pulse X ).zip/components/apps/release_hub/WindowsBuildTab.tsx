/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { playSound, SoundType } from '../../../services/audioService';
import { systemBus } from '../../../services/systemBus';

interface WindowsBuildTabProps {
    onStatusChange: (status: 'Building' | 'Success' | 'Failed') => void;
}

const buildSteps = [
    { text: "Verifying build environment...", time: 1000 },
    { text: "Checking for Microsoft C++ Build Tools... FOUND", time: 1500 },
    { text: "Checking for Rust (cargo)... FOUND", time: 1000 },
    { text: "Running 'npm install'...", time: 2500 },
    { text: "Dependencies installed successfully.", time: 500 },
    { text: "Compiling Rust backend (artemis-core)...", time: 4000 },
    { text: "[1/5] Compiling serde v1.0.152", time: 1000 },
    { text: "[2/5] Compiling tauri v1.2.4", time: 1500 },
    { text: "[3/5] Compiling tokio v1.25.0", time: 2000 },
    { text: "[4/5] Compiling custom system modules...", time: 1500 },
    { text: "[5/5] Finished compilation.", time: 500 },
    { text: "Bundling frontend assets with Vite...", time: 2000 },
    { text: "Frontend bundled successfully.", time: 500 },
    { text: "Creating Windows Installer (.msi)...", time: 3000 },
    { text: "Build successful! Update package is ready to be applied.", time: 500 },
];

export const WindowsBuildTab: React.FC<WindowsBuildTabProps> = ({ onStatusChange }) => {
    const [isVsDetected, setIsVsDetected] = useState(false);
    const [isDetecting, setIsDetecting] = useState(true);
    const [isBuilding, setIsBuilding] = useState(false);
    const [log, setLog] = useState<string[]>([]);
    const terminalRef = useRef<HTMLDivElement>(null);
    const [isBuildComplete, setIsBuildComplete] = useState(false);

    const appendLog = (line: string) => {
        setLog(prev => [...prev, line]);
    };

    useEffect(() => {
        terminalRef.current?.scrollTo(0, terminalRef.current.scrollHeight);
    }, [log]);
    
    useEffect(() => {
        appendLog("Auto-detecting build environment...");
        const timer = setTimeout(() => {
            setIsVsDetected(true);
            setIsDetecting(false);
            appendLog("✅ Success: Build environment ready.");
            playSound(SoundType.CLICK);
        }, 2000);
        return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleStartBuild = useCallback(() => {
        playSound(SoundType.TRANSITION);
        setIsBuilding(true);
        setIsBuildComplete(false); // Reset on new build
        setLog([]);
        onStatusChange('Building');
        systemBus.emit('log_system_event', { message: 'Started Windows EXE build.', icon: '📦', source: 'ReleaseHub' });

        let stepIndex = 0;
        const runNextStep = () => {
            if (stepIndex < buildSteps.length) {
                appendLog(buildSteps[stepIndex].text);
                setTimeout(runNextStep, buildSteps[stepIndex].time);
                stepIndex++;
            } else {
                setIsBuilding(false);
                onStatusChange('Success');
                setIsBuildComplete(true);
                playSound(SoundType.OPEN);
                systemBus.emit('log_system_event', { message: 'Windows EXE build completed successfully.', icon: '✅', source: 'ReleaseHub' });
            }
        };
        runNextStep();
    }, [onStatusChange]);
    
    const handleApplyUpdate = () => {
        systemBus.emit('initiate_system_update');
        appendLog("✅ Update package sent to OS for installation.");
        appendLog("The system will restart shortly to apply the update.");
    };


    return (
        <div>
            <div className="build-actions flex gap-4 items-center">
                <button onClick={handleStartBuild} disabled={!isVsDetected || isBuilding}>
                    {isDetecting ? 'Detecting Environment...' : (isBuilding ? 'Building...' : 'Start MSI Build')}
                </button>
                {isBuildComplete && !isBuilding && (
                    <button onClick={handleApplyUpdate} className="download-button">
                        Apply Update & Restart
                    </button>
                )}
            </div>
            {log.length > 0 && (
                <div ref={terminalRef} className="build-log-terminal">
                    {log.map((line, index) => (
                        <p key={index}>{`> ${line}`}</p>
                    ))}
                    {isBuilding && <p className="animate-pulse">{'> _'}</p>}
                </div>
            )}
        </div>
    );
};