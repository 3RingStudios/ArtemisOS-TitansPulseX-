/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { NativeAppComponentProps, MemoryCell } from '../../types';

class LiquidParticle {
    x: number; y: number;
    vx: number; vy: number;
    size: number;
    color: string;
    life: number;

    constructor(x: number, y: number) {
        this.x = x; this.y = y;
        this.vx = Math.random() * 0.2 - 0.1;
        this.vy = Math.random() * 0.2 - 0.1;
        this.size = Math.random() * 1.5 + 0.5;
        this.color = Math.random() > 0.5 ? 'rgba(0, 255, 255, 0.8)' : 'rgba(200, 200, 220, 0.8)';
        this.life = 1;
    }

    update() {
        this.x += this.vx;
        this.y += this.vy;
        this.vy += 0.005; // gravity
        this.life -= 0.005;
    }
}

export const MemoryWall: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const particlesRef = useRef<LiquidParticle[]>([]);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let laserBeams: {x: number, y: number, life: number}[] = [];

        const animate = () => {
            const { width, height } = canvas;
            ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
            ctx.fillRect(0, 0, width, height);

            // Add new particles for liquid metal effect
            if (particlesRef.current.length < 5000) {
                 for(let i=0; i<20; i++) {
                     particlesRef.current.push(new LiquidParticle(Math.random() * width, Math.random() * height));
                 }
            }

            // Update and draw particles
            particlesRef.current = particlesRef.current.filter(p => p.life > 0);
            particlesRef.current.forEach(p => {
                p.update();
                ctx.fillStyle = p.color.replace('0.8', p.life.toString());
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                ctx.fill();
            });

            // Simulate laser inscription
            if (Math.random() > 0.95) {
                laserBeams.push({ x: Math.random() * width, y: 0, life: 1 });
            }

            // Draw lasers
            laserBeams = laserBeams.filter(beam => beam.life > 0);
            laserBeams.forEach(beam => {
                beam.life -= 0.02;
                ctx.strokeStyle = `rgba(255, 255, 0, ${beam.life})`;
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.moveTo(beam.x, 0);
                ctx.lineTo(beam.x, height);
                ctx.stroke();
            });


            requestAnimationFrame(animate);
        };

        const resizeObserver = new ResizeObserver(() => {
            canvas.width = canvas.clientWidth;
            canvas.height = canvas.clientHeight;
        });
        resizeObserver.observe(canvas);
        const animId = requestAnimationFrame(animate);

        return () => {
            cancelAnimationFrame(animId);
            resizeObserver.disconnect();
        };

    }, []);

    return (
        <div className="h-full bg-black text-gray-300 font-sans flex flex-col relative">
             <div className="absolute top-0 left-0 right-0 p-4 z-10 bg-gradient-to-b from-black/80 to-transparent">
                <h2 className="text-xl text-yellow-400 font-bold">🧱 Memory Wall (Living Light Memory Cell)</h2>
                <p className="text-sm text-gray-400">Live view of the light & liquid metal data inscription process.</p>
            </div>
            <canvas ref={canvasRef} className="w-full h-full" />
        </div>
    );
};