/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useCallback, useState, useEffect} from 'react';
import {
  streamBootThemeCss,
  streamNewAppDefinition,
  streamThemeCss,
} from '../../services/geminiService';
import {playSound, SoundType} from '../../services/audioService';
import {systemBus} from '../../services/systemBus';
import {NativeAppComponentProps} from '../../types';

const ThemePreview: React.FC = () => (
    <div className="flex flex-col items-center justify-center gap-4 p-4">
        <div className="window pointer-events-none" style={{ width: 280, height: 180, position: 'static' }}>
             <div className="text-white py-1.5 px-3 flex justify-between items-center select-none rounded-t-xl flex-shrink-0 transition-colors bg-gray-800/90">
                <span className="title-bar-text font-semibold text-sm truncate">Sample Window</span>
             </div>
             <div className="flex-grow overflow-y-auto overflow-x-hidden bg-white p-4">
                <p className="text-gray-800 text-sm">This is a theme preview.</p>
                <button className="llm-button mt-4">Styled Button</button>
             </div>
        </div>
        <div className="icon">
            <div className="text-6xl mb-2 drop-shadow-lg">🎨</div>
            <div className="text-sm text-gray-800 font-semibold break-words max-w-full leading-tight">
                Synthesizer
            </div>
        </div>
    </div>
);

const BootScreenPreview: React.FC = () => (
    <div className="boot-container w-full h-full bg-gray-900 text-green-400 font-mono flex flex-col items-center justify-center select-none">
      <div className="boot-logo text-8xl mb-8">🔮</div>
      <h1 className="boot-title text-4xl font-bold mb-4">ArtemisOS</h1>
      <div className="boot-progress-bar-container w-full bg-gray-700 rounded-full h-2.5 mb-8">
        <div className="boot-progress-bar bg-green-400 h-2.5 rounded-full" style={{ width: `75%` }}></div>
      </div>
       <p className="boot-message">Verifying system integrity...</p>
    </div>
);

const TabButton: React.FC<{ label: string; isActive: boolean; onClick: () => void; disabled?: boolean; }> = ({ label, isActive, onClick, disabled }) => (
    <button
        onClick={onClick}
        disabled={disabled}
        className={`px-4 py-2 text-sm font-medium transition-colors rounded-t-lg border-b-2 disabled:text-gray-600 disabled:cursor-not-allowed ${
            isActive ? 'border-cyan-400 text-white' : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-500'
        }`}
    >
        {label}
    </button>
);

export const UISynthesizer: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [activeTab, setActiveTab] = useState<'theme' | 'boot' | 'app' | 'offlineApp'>('theme');
    const [description, setDescription] = useState('A dark theme with glowing cyan highlights, inspired by cyberpunk and DeviantArt aesthetics. Use sharp angles and neon effects.');
    const [generatedCss, setGeneratedCss] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const [bootCss, setBootCss] = useState('');
    const [isGeneratingBootCss, setIsGeneratingBootCss] = useState(false);
    
    const [appDescription, setAppDescription] = useState('A simple calculator applet that can perform basic arithmetic operations and display a history of calculations.');
    const [appSynthesisLog, setAppSynthesisLog] = useState('');
    const [isSynthesizingApp, setIsSynthesizingApp] = useState(false);
    
    const [isHostConnected, setIsHostConnected] = useState(false);
    
    const previewCss = generatedCss.replace(/\.generated-theme/g, '#theme-preview-container');
    const bootPreviewCss = bootCss.replace(/\.boot-theme-active/g, '#boot-theme-preview-container');
    
    useEffect(() => {
        const unsubConnect = systemBus.on('host_bridge_connected', () => setIsHostConnected(true));
        const unsubDisconnect = systemBus.on('host_bridge_disconnected', () => setIsHostConnected(false));
        return () => {
            unsubConnect();
            unsubDisconnect();
        };
    }, []);

    const handleSynthesize = useCallback(async () => {
        if (!description.trim()) {
            setError('Please enter a theme description.');
            return;
        }
        setIsLoading(true);
        setError('');
        setGeneratedCss('');
        playSound(SoundType.TRANSITION);

        let fullCss = '';
        try {
            const stream = streamThemeCss(description);
            for await (const chunk of stream) {
                fullCss += chunk;
                setGeneratedCss(fullCss);
            }
        } catch (e: any) {
            setError('Failed to generate theme. Please check the console.');
            console.error(e);
        } finally {
            setIsLoading(false);
            playSound(SoundType.OPEN);
        }
    }, [description]);

    const handleApplyTheme = () => {
        if (!generatedCss) {
            setError('No theme generated to apply.');
            return;
        }
        playSound(SoundType.CLICK);
        systemBus.emit('apply_theme', generatedCss);
        setError('');
        addNotification('Theme applied globally!');
    };

    const handleRevertTheme = () => {
        playSound(SoundType.CLOSE);
        systemBus.emit('apply_theme', null);
        setGeneratedCss('');
        addNotification('Theme reverted to default.');
    };
    
    const handleGenerateBootTheme = useCallback(async () => {
        if (!generatedCss) {
            setError('Please generate a main theme first to provide context.');
            return;
        }
        setIsGeneratingBootCss(true);
        setError('');
        setBootCss('');
        playSound(SoundType.TRANSITION);
        let fullCss = '';
        try {
            const stream = streamBootThemeCss(description, generatedCss);
            for await (const chunk of stream) {
                fullCss += chunk;
                setBootCss(fullCss);
            }
        } catch(e) {
             setError('Failed to generate boot theme.');
        } finally {
            setIsGeneratingBootCss(false);
            playSound(SoundType.OPEN);
        }

    }, [description, generatedCss]);

    const handleApplyBootTheme = () => {
        if (!bootCss) return;
        playSound(SoundType.CLICK);
        systemBus.emit('apply_boot_theme', bootCss);
        addNotification('Boot theme applied for next launch.');
    };
    
    const handleSynthesizeApp = useCallback(async (isOffline: boolean) => {
        if (!appDescription.trim()) return;
        setIsSynthesizingApp(true);
        setAppSynthesisLog('');
        playSound(SoundType.TRANSITION);
        let fullLog = '';
        
        if (isOffline) {
            setAppSynthesisLog('Simulating offline synthesis using local model...\n');
            setTimeout(() => setAppSynthesisLog(prev => prev + 'Analyzing request...\n'), 500);
            setTimeout(() => {
                const newAppName = "Local Calculator";
                const scriptContent = `window.systemBus.emit('register_new_app', { name: '${newAppName}', icon: '🧮', category: 'Development & Utilities', systemPrompt: 'You are a simple calculator UI.' })`;
                fullLog = `<p>Local analysis complete. Generating registration script...</p><script>${scriptContent}</script>`;
                 try {
                    const scriptFunction = new Function(scriptContent);
                    scriptFunction.call(window);
                    setAppSynthesisLog(prev => prev + 'Applet registered successfully!');
                    playSound(SoundType.OPEN);
                } catch (e) {
                     setAppSynthesisLog(prev => prev + `<p class="text-red-400 mt-2">Error executing registration script: ${e}</p>`);
                }
                setIsSynthesizingApp(false);
            }, 2000);
            return;
        }

        try {
            const stream = streamNewAppDefinition(appDescription);
            for await (const chunk of stream) {
                fullLog += chunk;
                setAppSynthesisLog(fullLog.replace(/<script>[\s\S]*?<\/script>/, ''));
            }
            
            const scriptMatch = fullLog.match(/<script>([\s\S]*?)<\/script>/);
            if (scriptMatch && scriptMatch[1]) {
                try {
                    const scriptContent = scriptMatch[1];
                    const scriptFunction = new Function(scriptContent);
                    scriptFunction.call(window);
                    setAppSynthesisLog(prev => prev + '<p class="text-green-400 mt-2 font-bold">Applet registered successfully!</p>');
                    playSound(SoundType.OPEN);
                } catch (e) {
                     setAppSynthesisLog(prev => prev + `<p class="text-red-400 mt-2">Error executing registration script: ${e}</p>`);
                }
            } else {
                 setAppSynthesisLog(prev => prev + '<p class="text-red-400 mt-2">No registration script found.</p>');
            }

        } catch (e) {
            setAppSynthesisLog(`<p class="text-red-400">Error: ${e}</p>`);
        } finally {
            setIsSynthesizingApp(false);
        }
    }, [appDescription]);

    const addNotification = (msg: string) => {
        systemBus.emit('log_system_event', {
            message: msg, icon: '🎨', source: 'UI Synthesizer',
        });
    };

    const renderTabContent = () => {
        switch (activeTab) {
            case 'boot':
                return (
                    <div className="h-full flex p-4 gap-4">
                        <style>{bootPreviewCss}</style>
                        <div className="w-1/3 flex flex-col gap-4">
                             <p className="text-sm text-gray-400">Generate a boot screen theme that matches your main OS theme.</p>
                             <button onClick={handleGenerateBootTheme} disabled={isGeneratingBootCss || !generatedCss} className="llm-button w-full bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-600">
                                {isGeneratingBootCss ? 'Generating...' : 'Generate from Main Theme'}
                            </button>
                             <div className="flex-grow flex flex-col min-h-0">
                                <label className="text-sm font-bold text-gray-400">Generated Boot CSS</label>
                                <pre className="flex-grow text-xs bg-black/50 p-2 rounded mt-1 overflow-auto">
                                    <code>{bootCss || '// Generate a theme first...'}</code>
                                </pre>
                            </div>
                            <button onClick={handleApplyBootTheme} disabled={!bootCss} className="llm-button bg-green-600 hover:bg-green-700 disabled:bg-gray-600">Apply Boot Theme</button>
                        </div>
                        <div className="w-2/3 bg-black/30 rounded-lg p-4 flex flex-col items-center justify-center">
                            <h3 className="text-lg font-semibold mb-4">Boot Screen Preview</h3>
                            <div id="boot-theme-preview-container" className="relative w-full h-96 rounded-md overflow-hidden bg-black/50">
                                <div className="absolute inset-0 transform scale-[0.85] origin-center">
                                    <BootScreenPreview />
                                </div>
                            </div>
                        </div>
                    </div>
                );
            case 'app':
                 return (
                    <div className="h-full flex p-4 gap-4">
                        <div className="w-1/2 flex flex-col gap-4">
                            <p className="text-sm text-gray-400">Describe a new application or widget you want the AI to create. It will be automatically installed and saved.</p>
                             <div>
                                <label className="text-sm font-bold text-gray-400">Applet Description</label>
                                <textarea
                                    value={appDescription}
                                    onChange={e => setAppDescription(e.target.value)}
                                    className="w-full h-32 p-2 mt-1 rounded bg-gray-800 border border-gray-600 focus:border-cyan-400 outline-none"
                                />
                            </div>
                            <button onClick={() => handleSynthesizeApp(false)} disabled={isSynthesizingApp} className="llm-button bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-600">
                                {isSynthesizingApp ? 'Synthesizing...' : 'Synthesize Applet (Online)'}
                            </button>
                        </div>
                        <div className="w-1/2 bg-black/30 rounded-lg p-4 flex flex-col">
                             <h3 className="text-lg font-semibold mb-4">Synthesis Log</h3>
                             <div className="flex-grow overflow-y-auto" dangerouslySetInnerHTML={{ __html: appSynthesisLog || '<p class="text-gray-500">Log will appear here...</p>' }}></div>
                        </div>
                    </div>
                );
            case 'offlineApp':
                return (
                    <div className="h-full flex p-4 gap-4">
                        <div className="w-1/2 flex flex-col gap-4">
                            <p className="text-sm text-gray-400">Use the simulated local AI model to synthesize a new applet without an internet connection. Functionality is limited but demonstrates offline capabilities.</p>
                            <div>
                                <label className="text-sm font-bold text-gray-400">Applet Description</label>
                                <textarea
                                    value={appDescription}
                                    onChange={e => setAppDescription(e.target.value)}
                                    className="w-full h-32 p-2 mt-1 rounded bg-gray-800 border border-gray-600 focus:border-cyan-400 outline-none"
                                />
                            </div>
                            <button onClick={() => handleSynthesizeApp(true)} disabled={isSynthesizingApp} className="llm-button bg-purple-600 hover:bg-purple-500 disabled:bg-gray-600">
                                {isSynthesizingApp ? 'Synthesizing...' : 'Synthesize Applet (Offline)'}
                            </button>
                        </div>
                         <div className="w-1/2 bg-black/30 rounded-lg p-4 flex flex-col">
                             <h3 className="text-lg font-semibold mb-4">Offline Synthesis Log</h3>
                             <pre className="flex-grow overflow-y-auto whitespace-pre-wrap">{appSynthesisLog || 'Log will appear here...'}</pre>
                        </div>
                    </div>
                );
            case 'theme':
            default:
                return (
                     <div className="h-full flex p-4 gap-4">
                        <style>{previewCss}</style>
                        <div className="w-1/3 flex flex-col gap-4">
                            <div>
                                <label className="text-sm font-bold text-gray-400">Theme Description</label>
                                <textarea
                                    value={description}
                                    onChange={e => setDescription(e.target.value)}
                                    className="w-full h-32 p-2 mt-1 rounded bg-gray-800 border border-gray-600 focus:border-cyan-400 outline-none"
                                    placeholder="e.g., A theme inspired by alien biology with glowing green accents..."
                                />
                            </div>
                            <button onClick={handleSynthesize} disabled={isLoading} className="llm-button w-full bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-600">
                                {isLoading ? 'Synthesizing...' : 'Synthesize OS Theme'}
                            </button>
                            {error && <p className="text-red-400 text-sm">{error}</p>}
                            <div className="flex-grow flex flex-col min-h-0">
                                <label className="text-sm font-bold text-gray-400">Generated CSS</label>
                                <pre className="flex-grow text-xs bg-black/50 p-2 rounded mt-1 overflow-auto">
                                    <code>{generatedCss || '// CSS will appear here...'}</code>
                                </pre>
                            </div>
                            <div className="flex gap-2">
                                <button onClick={handleApplyTheme} disabled={!generatedCss || isLoading} className="llm-button flex-1 bg-green-600 hover:bg-green-700 disabled:bg-gray-600">
                                    Apply Theme
                                </button>
                                <button onClick={handleRevertTheme} className="llm-button flex-1 bg-red-600 hover:bg-red-500">
                                    Revert to Default
                                </button>
                            </div>
                        </div>
                        <div className="w-2/3 bg-black/30 rounded-lg p-4 flex flex-col items-center justify-center">
                            <h3 className="text-lg font-semibold mb-4">Live Preview</h3>
                            <div id="theme-preview-container">
                                <ThemePreview />
                            </div>
                        </div>
                    </div>
                );
        }
    };

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans flex flex-col">
            <div className="flex-shrink-0 p-4 border-b border-gray-700">
                <h2 className="text-xl text-cyan-300 font-bold">🎨 UI Synthesizer</h2>
                <p className="text-sm text-gray-400">Generate and apply custom themes and applications using AI.</p>
            </div>
             <div className="border-b border-gray-700 px-4">
                <nav className="-mb-px flex space-x-4">
                    <TabButton label="OS Theme" isActive={activeTab === 'theme'} onClick={() => setActiveTab('theme')} />
                    <TabButton label="Boot Screen" isActive={activeTab === 'boot'} onClick={() => setActiveTab('boot')} />
                    <TabButton label="App Synthesis (Online)" isActive={activeTab === 'app'} onClick={() => setActiveTab('app')} />
                     <TabButton label="App Synthesis (Offline)" isActive={activeTab === 'offlineApp'} onClick={() => setActiveTab('offlineApp')} disabled={!isHostConnected} />
                </nav>
            </div>
            <div className="flex-grow min-h-0">
                {renderTabContent()}
            </div>
        </div>
    );
};