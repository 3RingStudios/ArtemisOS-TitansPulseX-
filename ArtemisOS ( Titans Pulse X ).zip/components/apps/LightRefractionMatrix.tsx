/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useRef, useEffect, useState } from 'react';
import { NativeAppComponentProps } from '../../types';

class Ray {
    x: number; y: number;
    vx: number; vy: number;
    life = 1;
    constructor(x: number, y: number, angle: number) {
        this.x = x; this.y = y;
        this.vx = Math.cos(angle);
        this.vy = Math.sin(angle);
    }
    update() {
        this.x += this.vx * 2;
        this.y += this.vy * 2;
        this.life -= 0.005;
    }
}

export const LightRefractionMatrix: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [lensPosition, setLensPosition] = useState({ x: 0.5, y: 0.5 });
    const [refractiveIndex, setRefractiveIndex] = useState(1.5);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let rays: Ray[] = [];
        let frame = 0;
        let animationId: number;
        let resizeAnimationId: number;

        const animate = () => {
            frame++;
            const { width, height } = canvas;
            ctx.fillStyle = 'rgba(10, 5, 20, 0.1)';
            ctx.fillRect(0, 0, width, height);

            if (frame % 2 === 0) {
                const angle = (frame * 0.01) % (Math.PI * 2);
                rays.push(new Ray(50, height/2, angle - Math.PI/4));
                rays.push(new Ray(50, height/2, -angle + Math.PI/4));
            }
            
            const lensX = width * lensPosition.x;
            const lensY = height * lensPosition.y;
            const lensRadius = 50;

            rays = rays.filter(r => r.life > 0 && r.x < width && r.y > 0 && r.y < height);
            rays.forEach(ray => {
                ray.update();
                const distToLens = Math.hypot(ray.x - lensX, ray.y - lensY);
                if (distToLens < lensRadius) {
                    const normalAngle = Math.atan2(ray.y - lensY, ray.x - lensX);
                    const incomingAngle = Math.atan2(ray.vy, ray.vx);
                    const refractedAngle = Math.asin(Math.sin(incomingAngle - normalAngle) / refractiveIndex) + normalAngle;
                    ray.vx = Math.cos(refractedAngle);
                    ray.vy = Math.sin(refractedAngle);
                }
                ctx.fillStyle = `rgba(255, 220, 180, ${ray.life})`;
                ctx.fillRect(ray.x, ray.y, 2, 2);
            });
            
            // Draw lens
            ctx.strokeStyle = 'rgba(100, 200, 255, 0.5)';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.arc(lensX, lensY, lensRadius, 0, Math.PI * 2);
            ctx.stroke();

            animationId = requestAnimationFrame(animate);
        };
        
        const resizeObserver = new ResizeObserver(() => {
            resizeAnimationId = window.requestAnimationFrame(() => {
                if (canvas) {
                    canvas.width = canvas.clientWidth;
                    canvas.height = canvas.clientHeight;
                }
            });
        });

        canvas.width = canvas.clientWidth;
        canvas.height = canvas.clientHeight;
        resizeObserver.observe(canvas);
        animate();

        return () => {
            cancelAnimationFrame(animationId);
            cancelAnimationFrame(resizeAnimationId);
            resizeObserver.disconnect();
        };

    }, [lensPosition, refractiveIndex]);

    return (
        <div className="h-full bg-gray-900 text-white flex flex-col relative">
            <div className="absolute top-0 left-0 right-0 p-4 z-10 bg-gradient-to-b from-black/80 to-transparent">
                <h2 className="text-xl font-bold text-violet-300">💎 Light Refraction Matrix</h2>
            </div>
            <canvas ref={canvasRef} className="w-full h-full" />
             <div className="absolute bottom-4 left-4 right-4 z-10 flex gap-4 justify-center">
                 <input type="range" min="1" max="3" step="0.1" value={refractiveIndex} onChange={e => setRefractiveIndex(Number(e.target.value))} />
                 <span className="font-mono text-sm">Refractive Index: {refractiveIndex.toFixed(2)}</span>
             </div>
        </div>
    );
};
