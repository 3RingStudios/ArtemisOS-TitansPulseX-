/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState } from 'react';
import { NativeAppComponentProps, AutomationJob } from '../../types';

const initialJobs: AutomationJob[] = [
    { id: 'job_1', name: 'Optimize Cluster Load', trigger: 'CPU > 80%', actions: ['Offload task to xAI', 'Rebalance nodes'], status: 'Active' },
    { id: 'job_2', name: 'Auto-deploy Royalties', trigger: 'New Blueprint License', actions: ['Deploy Smart Contract', 'Notify Partners'], status: 'Active' },
    { id: 'job_3', name: 'Archive System Logs', trigger: 'Daily @ 01:00', actions: ['Compress Logs', 'Upload to Host'], status: 'Paused' },
];

export const AIAutomationPlatform: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [jobs, setJobs] = useState<AutomationJob[]>(initialJobs);

    const getStatusColor = (status: AutomationJob['status']) => {
        switch(status) {
            case 'Active': return 'text-green-400';
            case 'Paused': return 'text-yellow-400';
            case 'Completed': return 'text-gray-400';
            default: return 'text-white';
        }
    };

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0 pb-2 border-b border-gray-700 flex justify-between items-center">
                <div>
                    <h2 className="text-xl text-green-300 font-bold">⚙️ AI Automation Platform</h2>
                    <p className="text-sm text-gray-400">Create and manage autonomous workflows.</p>
                </div>
                <button className="p-3 bg-green-600 hover:bg-green-500 rounded text-white font-bold">New Automation</button>
            </div>
            
            <div className="flex-grow overflow-y-auto pr-2">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {jobs.map(job => (
                        <div key={job.id} className="bg-gray-800 p-4 rounded-lg border border-gray-700">
                            <div className="flex justify-between items-start">
                                <h3 className="font-bold text-lg mb-2">{job.name}</h3>
                                <p className={`text-sm font-bold ${getStatusColor(job.status)}`}>{job.status}</p>
                            </div>
                            <div className="font-mono text-xs space-y-2">
                                <p><span className="text-gray-400">Trigger:</span> {job.trigger}</p>
                                <div>
                                    <p className="text-gray-400">Actions:</p>
                                    <ul className="list-disc pl-5">
                                        {job.actions.map((action, i) => <li key={i}>{action}</li>)}
                                    </ul>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};
