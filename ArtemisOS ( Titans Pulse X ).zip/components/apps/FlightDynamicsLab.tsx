/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {VEHICLE_PARTS} from '../../constants';
import {playSound, SoundType} from '../../services/audioService';
import {AssembledPart, NativeAppComponentProps, StageStats, VehiclePart} from '../../types';
import {streamText} from '../../services/geminiService';
import {systemBus} from '../../services/systemBus';
import './flight_dynamics/styles.css';
import {VabCanvas} from './flight_dynamics/VabCanvas';

const G0 = 9.81; // Standard gravity in m/s^2
type View = 'vab' | 'mission_ai' | 'launchpad';

// --- HELPER & CHILD COMPONENTS ---

const TabButton: React.FC<{label: string, isActive: boolean, onClick: () => void, disabled?: boolean}> = ({ label, isActive, onClick, disabled }) => (
    <button className={`tab-button ${isActive ? 'active' : ''}`} onClick={onClick} disabled={disabled}>{label}</button>
);

const LogModal: React.FC<{title: string, content: string, onClose: () => void}> = ({ title, content, onClose }) => (
    <div className="log-modal-backdrop" onClick={onClose}>
        <div className="log-modal-content" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold mb-2">{title}</h3>
            <pre className="whitespace-pre-wrap">{content}</pre>
            <button onClick={onClose} className="add-stage-btn mt-4">Close</button>
        </div>
    </div>
);

// --- LOG GENERATORS ---

const generateUnrealBootstrapLog = (vesselName: string): string => `
[BOOTSTRAP] Initializing Unreal Engine 5.4 project for vessel: ${vesselName}
[  0.05s] Creating project directory: /dev/projects/${vesselName}/
[  0.15s] Generating ${vesselName}.uproject file...
[  0.32s] Setting up default maps and modes...
[  0.55s] Compiling base shaders (core engine)...
[  1.23s] SUCCESS: Core engine compiled.
[  1.58s] Analyzing vessel manifest for required assets...
[  1.95s] Found 12 unique parts. Importing meshes and materials...
[  2.54s] Importing /assets/parts/CommandPodMk1.fbx... DONE
[  2.88s] Importing /assets/parts/FL-T400.fbx... DONE
[  3.12s] Generating physics assets for all components...
[  4.50s] Creating master Blueprint Actor for vessel: BP_${vesselName}
[  5.10s] Attaching components based on VAB assembly...
[  6.30s] SUCCESS: Vessel BP created and assembled.
[  7.00s] Project bootstrapping complete. Ready to open in Unreal Editor.
`;

const generateNftMintLog = (vesselName: string): string => {
    const txHash = `0x${[...Array(64)].map(() => Math.floor(Math.random() * 16).toString(16)).join('')}`;
    return `
[  0.01s] Initiating vessel blueprint minting process...
[  0.05s] Vessel: ${vesselName}
[  0.15s] Generating secure hash of vessel assembly data...
[  0.32s] Hash: ${txHash.substring(0, 32)}...
[  0.55s] Uploading blueprint and metadata to IPFS...
[  1.23s] IPFS CID: Qm... (File successfully pinned)
[  1.58s] Connecting to Aetherium Smart Contract via Grok-Liaison...
[  1.95s] Crafting mint transaction with metadata URI...
[  2.54s] Sending transaction to be signed by user wallet...
[  4.11s] Transaction signed. Submitting to the network...
[  8.75s] Transaction confirmed in block 1337.
[  9.00s] SUCCESS: Vessel "${vesselName}" minted as NFT.
[  9.01s] Transaction Hash: ${txHash}
`;
};

// --- CORE LOGIC ---

const calculateVehicleStats = (
  assembledParts: AssembledPart[],
): {stageStats: StageStats[]; vehicleStats: Record<string, number>} => {
  const numStages =
    Math.max(0, ...assembledParts.map((p) => p.stage)) + 1;
  const stageStats: StageStats[] = [];

  for (let i = numStages - 1; i >= 0; i--) {
    const partsInStage = assembledParts.filter((p) => p.stage === i);
    const partsInUpperStages = assembledParts.filter((p) => p.stage > i);

    const stageFuelMass = partsInStage.reduce(
      (sum, p) => sum + (p.part.fuel || 0),
      0,
    );
    const stageDryMass = partsInStage.reduce((sum, p) => sum + p.part.mass, 0);
    const upperStagesMass = partsInUpperStages.reduce(
      (sum, p) => sum + p.part.mass + (p.part.fuel || 0),
      0,
    );
    const stageThrust = partsInStage.reduce(
      (sum, p) => sum + (p.part.thrust || 0),
      0,
    );
    const stageIsp =
      partsInStage
        .filter((p) => p.part.type === 'engine')
        .reduce((sum, p) => sum + (p.part.isp || 0), 0) /
        partsInStage.filter((p) => p.part.type === 'engine').length || 1;

    const wetMass = stageDryMass + stageFuelMass + upperStagesMass;
    const dryMass = stageDryMass + upperStagesMass;

    const deltaV = stageIsp * G0 * Math.log(wetMass / dryMass) || 0;
    const twr = stageThrust / ((wetMass || 1) * 1000 * G0) * 1000 || 0;
    const massFlowRate = stageThrust / ((stageIsp || 1) * G0) || 0;
    const burnTime = (stageFuelMass * 1000) / massFlowRate || 0;

    stageStats.unshift({
      stage: i,
      totalMass: wetMass,
      dryMass: dryMass,
      fuelMass: stageFuelMass,
      thrust: stageThrust,
      twr: twr,
      burnTime: burnTime,
      deltaV: deltaV,
    });
  }

  const totalBuoyancy = assembledParts.reduce(
    (sum, p) => sum + (p.part.buoyancyForce || 0),
    0,
  );
  const totalMass = assembledParts.reduce(
    (sum, p) => sum + p.part.mass + (p.part.fuel || 0),
    0,
  );
  const totalTorque = assembledParts.reduce(
    (sum, p) => sum + (p.part.torque || 0),
    0,
  );
  const vehicleStats = {totalBuoyancy, totalMass, totalTorque};

  return {stageStats, vehicleStats};
};


// --- VIEW COMPONENTS ---

const PartsBin: React.FC<{onPartDragStart: (part: VehiclePart) => void}> = ({ onPartDragStart }) => {
    const categories = useMemo(() => {
        const grouped: Record<string, VehiclePart[]> = {};
        VEHICLE_PARTS.forEach(part => {
            if (!grouped[part.category]) grouped[part.category] = [];
            grouped[part.category].push(part);
        });
        const order = ['Life Support', 'Rocketry', 'Structural', 'Utility', 'Science', 'Robotics', 'Rovers', 'Submersibles', 'Payloads'];
        const orderedGrouped: Record<string, VehiclePart[]> = {};
        order.forEach(cat => { if (grouped[cat]) orderedGrouped[cat] = grouped[cat]; });
        return orderedGrouped;
    }, []);

    return (
        <div className="parts-bin">
            <h3 className="parts-bin-title">Component Library</h3>
            {Object.entries(categories).map(([category, parts]) => (
                <div key={category}>
                    <h4 className="parts-category-title">{category}</h4>
                    <div className="parts-list">
                        {parts.map(part => (
                            <div key={part.id} className="part-item" draggable onDragStart={() => onPartDragStart(part)}>
                                <span className="part-name">{part.name}</span>
                                <span className="part-mass">{part.mass.toFixed(2)}T</span>
                            </div>
                        ))}
                    </div>
                </div>
            ))}
        </div>
    );
};

const VabView: React.FC<{
    assembledParts: AssembledPart[];
    onStageDrop: (stageIndex: number) => void;
    onRemovePart: (part: AssembledPart) => void;
    onPartDragStart: (part: VehiclePart) => void;
    onAddStage: () => void;
    onRemoveStage: (stageIndex: number) => void;
    onBootstrapUnreal: () => void;
    onMintNFT: () => void;
    stageStats: StageStats[];
    vehicleStats: Record<string, number>;
    numStages: number;
}> = (props) => {
    const groupedByStage = useMemo(() => {
        const stages: AssembledPart[][] = Array.from({length: props.numStages}, () => []);
        props.assembledParts.forEach(p => {
            if (p.stage < props.numStages) stages[p.stage].push(p);
        });
        return stages;
    }, [props.assembledParts, props.numStages]);
    
    const totalDeltaV = props.stageStats.reduce((sum, s) => sum + s.deltaV, 0);

    return (
        <div className="lab-content">
            <PartsBin onPartDragStart={props.onPartDragStart} />
            <div className="vab-main">
                <div className="vab-canvas-container">
                    <VabCanvas assembledParts={props.assembledParts} />
                </div>
                <div className="vab-stats-footer">
                    <div className="stat-display">
                        <span className="stat-label">Total Δv</span>
                        <span className="stat-value">{totalDeltaV.toFixed(0)} m/s</span>
                    </div>
                    <div className="flex gap-2">
                        <button onClick={props.onBootstrapUnreal} className="launch-btn bg-purple-600 hover:bg-purple-700 text-sm">Bootstrap Unreal Project</button>
                        <button onClick={props.onMintNFT} className="launch-btn bg-indigo-600 hover:bg-indigo-700 text-sm">Mint Vessel NFT</button>
                    </div>
                </div>
            </div>
            <div className="right-panel">
                 <StagingColumn
                    stages={groupedByStage}
                    onPartClick={props.onRemovePart}
                    onStageDrop={props.onStageDrop}
                    onAddStage={props.onAddStage}
                    onRemoveStage={props.onRemoveStage}
                  />
                  <div className="stats-panel">
                      <h3 className="stats-title">Vehicle Stats</h3>
                      <div className="stats-scroll">
                          {props.stageStats.map(s => (
                              <div key={s.stage} className="stage-stats-group">
                                  <p><strong>Stage {s.stage}</strong></p>
                                  <p>TWR: {s.twr.toFixed(2)}</p>
                                  <p>Δv: {s.deltaV.toFixed(0)} m/s</p>
                                  <p>Burn Time: {s.burnTime.toFixed(1)}s</p>
                              </div>
                          ))}
                      </div>
                  </div>
            </div>
        </div>
    );
};

const StagingColumn: React.FC<{
  stages: AssembledPart[][];
  onPartClick: (part: AssembledPart) => void;
  onStageDrop: (stageIndex: number) => void;
  onAddStage: () => void;
  onRemoveStage: (stageIndex: number) => void;
}> = ({stages, onPartClick, onStageDrop, onAddStage, onRemoveStage}) => {
  return (
    <div className="staging-column">
      <div className="staging-scroll">
        {[...stages].reverse().map((parts, revIndex) => {
          const stageIndex = stages.length - 1 - revIndex;
          return (
            <div
              key={stageIndex}
              className="stage-group"
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => onStageDrop(stageIndex)}>
              <div className="stage-header">
                <span>Stage {stageIndex}</span>
                {stages.length > 1 && (
                  <button onClick={() => onRemoveStage(stageIndex)} className="remove-stage-btn">&times;</button>
                )}
              </div>
              <div className="stage-parts-list">
                {parts.map((p) => (
                  <div key={p.uniqueId} className="stage-part-item" onClick={() => onPartClick(p)}>{p.part.name}</div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      <button onClick={onAddStage} className="add-stage-btn">Add Stage</button>
    </div>
  );
};

const MissionAIView: React.FC<{
    onGenerate: (prompt: string) => void;
    isGenerating: boolean;
    aiResponse: string;
}> = ({ onGenerate, isGenerating, aiResponse }) => {
    const [prompt, setPrompt] = useState('Design a reusable single-stage-to-orbit crewed vehicle.');
    return (
        <div className="mission-ai-view">
            <div className="ai-controls">
                <h3 className="text-lg font-bold">Mission AI Planner</h3>
                <p className="text-sm text-gray-400">Describe your mission objective. Gemini will generate a vessel blueprint and mission plan.</p>
                <textarea value={prompt} onChange={e => setPrompt(e.target.value)} />
                <button onClick={() => onGenerate(prompt)} disabled={isGenerating} className="launch-btn">
                    {isGenerating ? 'Generating...' : 'Generate Blueprint'}
                </button>
            </div>
            <div className="ai-response" dangerouslySetInnerHTML={{ __html: aiResponse.replace(/\n/g, '<br />') || 'AI response will appear here...' }}></div>
        </div>
    );
};

const LaunchpadView: React.FC<{
    telemetry: any;
    isAborted: boolean;
}> = ({ telemetry, isAborted }) => {
  return (
    <div className="launchpad-view">
      <div className="telemetry-grid">
        <div className="telemetry-display">
          <span className="telemetry-label">MET</span>
          <span className="telemetry-value">T+ {new Date(telemetry.missionTime * 1000).toISOString().substr(11, 8)}</span>
        </div>
        <div className="telemetry-display">
          <span className="telemetry-label">Altitude</span>
          <span className="telemetry-value">{telemetry.altitude.toFixed(0)} m</span>
        </div>
        <div className="telemetry-display">
          <span className="telemetry-label">Velocity</span>
          <span className="telemetry-value">{telemetry.velocity.toFixed(1)} m/s</span>
        </div>
        <div className="telemetry-display">
          <span className="telemetry-label">Status</span>
          <span className={`telemetry-value ${isAborted ? 'text-yellow-400' : 'text-green-400'}`}>{isAborted ? 'ABORT' : 'NOMINAL'}</span>
        </div>
        <div className="telemetry-display">
          <span className="telemetry-label">Life Support (O₂)</span>
          <span className="telemetry-value text-green-400">{telemetry.lifeSupport.toFixed(1)}%</span>
        </div>
        <div className="telemetry-display">
          <span className="telemetry-label">Comms Link</span>
          <span className="telemetry-value text-green-400">{telemetry.signal.toFixed(0)}%</span>
        </div>
      </div>
    </div>
  );
};


// --- MAIN COMPONENT ---

export const FlightDynamicsLab: React.FC<Partial<NativeAppComponentProps>> = () => {
  const [assembledParts, setAssembledParts] = useState<AssembledPart[]>([]);
  const [numStages, setNumStages] = useState(1);
  const [draggedPart, setDraggedPart] = useState<VehiclePart | null>(null);
  const [view, setView] = useState<View>('vab');
  const [telemetry, setTelemetry] = useState({ missionTime: 0, altitude: 0, velocity: 0, lifeSupport: 99.8, signal: 98 });
  const [isAborted, setIsAborted] = useState(false);
  const missionIntervalRef = useRef<number | undefined>(undefined);
  const [logModal, setLogModal] = useState<{title: string; content: string} | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiResponse, setAiResponse] = useState('');

  const {stageStats, vehicleStats} = useMemo(() => calculateVehicleStats(assembledParts), [assembledParts]);
  const hasPod = useMemo(() => assembledParts.some(p => p.part.type === 'pod'), [assembledParts]);

  const handlePartDragStart = (part: VehiclePart) => setDraggedPart(part);
  const handleStageDrop = (stageIndex: number) => {
    if (draggedPart) {
      playSound(SoundType.CLICK, 0.5);
      setAssembledParts(prev => [...prev, { uniqueId: `${draggedPart.id}-${Date.now()}`, part: draggedPart, stage: stageIndex }]);
      setDraggedPart(null);
    }
  };

  const handleAddStage = () => setNumStages(prev => prev + 1);
  const handleRemoveStage = (stageIndex: number) => {
    if (numStages <= 1) return;
    setAssembledParts(prev => prev.filter(p => p.stage !== stageIndex));
    setNumStages(prev => prev - 1);
  };
  const handleRemovePart = useCallback((partToRemove: AssembledPart) => {
    setAssembledParts(prev => prev.filter(p => p.uniqueId !== partToRemove.uniqueId));
  }, []);

  const handleLaunch = useCallback(() => {
    if (!hasPod) return;
    playSound(SoundType.TRANSITION, 1.0);
    setView('launchpad');
    missionIntervalRef.current = window.setInterval(() => {
        setTelemetry(prev => ({
            missionTime: prev.missionTime + 1,
            velocity: prev.velocity + 9.8,
            altitude: prev.altitude + prev.velocity,
            lifeSupport: Math.max(0, prev.lifeSupport - 0.01),
            signal: Math.max(0, 98 - (prev.altitude / 10000))
        }));
    }, 1000);
  }, [hasPod]);

  const handleGenerateBlueprint = useCallback(async (prompt: string) => {
    setIsGenerating(true);
    setAiResponse('');
    const fullPrompt = `You are a mission planner for a realistic space simulation game. The user wants to achieve the following goal: "${prompt}". Based on this goal, provide a detailed mission plan and a suggested list of vehicle parts. The available part categories are: Rocketry, Rovers, Submersibles, Payloads, Utility, Robotics, Life Support, Science, Structural. Respond in markdown format. First, provide a section for "### Mission Plan", then a section for "### Suggested Vehicle Blueprint" with a list of parts.`;
    let accumulatedResponse = '';
    try {
        const stream = streamText(fullPrompt);
        for await (const chunk of stream) {
            accumulatedResponse += chunk;
            setAiResponse(accumulatedResponse);
        }
    } catch (e) {
        setAiResponse('Error generating response.');
    } finally {
        setIsGenerating(false);
    }
  }, []);

  const handleBootstrapUnreal = () => {
    playSound(SoundType.CLICK);
    const vesselName = `Vessel_${Date.now().toString().slice(-6)}`;
    setLogModal({
        title: 'Bootstrapping Unreal Engine Project...',
        content: generateUnrealBootstrapLog(vesselName),
    });
  };

  const handleMintNFT = () => {
      playSound(SoundType.CLICK, 0.8);
      const vesselName = `Vessel_${Date.now().toString().slice(-6)}`;
      setLogModal({
          title: 'Minting Vessel Blueprint as NFT...',
          content: generateNftMintLog(vesselName),
      });
      // Integrate with OS for notification
      systemBus.emit('execute_command', { 
          command: 'deploy_contract', 
          details: { type: 'VesselNFT', name: vesselName, technology: 'Advanced Propulsion' }
      });
  };

  useEffect(() => {
      return () => {
          if (missionIntervalRef.current) clearInterval(missionIntervalRef.current);
      }
  }, []);

  return (
    <div className="flight-dynamics-lab">
        <div className="lab-header">
            <h2 className="lab-title">🪐 Flight Dynamics Laboratory</h2>
            <div className="lab-tabs">
                <TabButton label="Assembly (VAB)" isActive={view === 'vab'} onClick={() => setView('vab')} />
                <TabButton label="Mission AI" isActive={view === 'mission_ai'} onClick={() => setView('mission_ai')} />
                <TabButton label="Launchpad" isActive={view === 'launchpad'} onClick={handleLaunch} disabled={!hasPod} />
            </div>
        </div>

        {view === 'vab' && (
            <VabView
                assembledParts={assembledParts}
                onPartDragStart={handlePartDragStart}
                onStageDrop={handleStageDrop}
                onRemovePart={handleRemovePart}
                onAddStage={handleAddStage}
                onRemoveStage={handleRemoveStage}
                onBootstrapUnreal={handleBootstrapUnreal}
                onMintNFT={handleMintNFT}
                stageStats={stageStats}
                vehicleStats={vehicleStats}
                numStages={numStages}
            />
        )}
        {view === 'mission_ai' && <MissionAIView onGenerate={handleGenerateBlueprint} isGenerating={isGenerating} aiResponse={aiResponse} />}
        {view === 'launchpad' && <LaunchpadView telemetry={telemetry} isAborted={isAborted} />}
        
        {logModal && <LogModal title={logModal.title} content={logModal.content} onClose={() => setLogModal(null)} />}
    </div>
  );
};