/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useRef, useEffect } from 'react';
import { NativeAppComponentProps } from '../../types';

export const OceanicDiscovery: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        
        let time = 0;
        let animationId: number;
        let resizeAnimationId: number;

        const animate = () => {
            time += 0.05;
            const { width, height } = canvas;
            
            // Background gradient
            const gradient = ctx.createLinearGradient(0, 0, 0, height);
            gradient.addColorStop(0, '#0284c7'); // sky-600
            gradient.addColorStop(0.5, '#0369a1'); // sky-700
            gradient.addColorStop(1, '#0c4a6e'); // sky-900
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, width, height);
            
            // Sonar Ping
            const pingRadius = (time % 100) * (width/100);
            const pingAlpha = 1 - (pingRadius / (width/2));
            ctx.strokeStyle = `rgba(10, 200, 255, ${pingAlpha > 0 ? pingAlpha : 0})`;
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.arc(width / 2, height, pingRadius, Math.PI, Math.PI * 2);
            ctx.stroke();

            // Bubbles
            for(let i = 0; i < 50; i++) {
                const x = Math.sin(i * 10 + time) * (width/4) + (width/2);
                const y = height - ((i * 20 + time * 20) % height);
                const r = Math.sin(i + time) * 1 + 2;
                ctx.fillStyle = `rgba(200, 230, 255, 0.5)`;
                ctx.beginPath();
                ctx.arc(x, y, r, 0, Math.PI * 2);
                ctx.fill();
            }

            animationId = requestAnimationFrame(animate);
        };
        
        const resizeObserver = new ResizeObserver(() => {
            resizeAnimationId = window.requestAnimationFrame(() => {
                if (canvas) {
                    canvas.width = canvas.clientWidth;
                    canvas.height = canvas.clientHeight;
                }
            });
        });

        canvas.width = canvas.clientWidth;
        canvas.height = canvas.clientHeight;
        resizeObserver.observe(canvas);
        
        animate();
        return () => {
            cancelAnimationFrame(animationId);
            cancelAnimationFrame(resizeAnimationId);
            resizeObserver.disconnect();
        };

    }, []);

    return (
        <div className="h-full bg-blue-900 text-white flex flex-col relative">
            <div className="absolute top-0 left-0 right-0 p-4 z-10 bg-gradient-to-b from-black/50 to-transparent">
                <h2 className="text-xl font-bold">🌊 Oceanic Discovery</h2>
                <p className="text-sm">Scanning Mariana Trench Anomaly...</p>
            </div>
            <canvas ref={canvasRef} className="w-full h-full" />
        </div>
    );
};
