/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useRef, useEffect } from 'react';
import { NativeAppComponentProps } from '../../types';

class Drone {
    x: number; y: number;
    tx: number; ty: number;
    speed = 0.5;

    constructor(width: number, height: number) {
        this.x = Math.random() * width;
        this.y = Math.random() * height;
        this.tx = Math.random() * width;
        this.ty = Math.random() * height;
    }

    update() {
        const dx = this.tx - this.x;
        const dy = this.ty - this.y;
        const dist = Math.hypot(dx, dy);
        if (dist < 1) {
            this.tx = Math.random() * 500;
            this.ty = Math.random() * 300;
        }
        this.x += (dx / dist) * this.speed;
        this.y += (dy / dist) * this.speed;
    }
}

export const InterplanetaryDroneCoordinator: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const drones = Array.from({ length: 10 }, () => new Drone(500, 300));
        
        const animate = () => {
            ctx.clearRect(0, 0, 500, 300);
            // Mars surface
            ctx.fillStyle = '#b91c1c';
            ctx.fillRect(0, 0, 500, 300);
            
            drones.forEach(d => {
                d.update();
                ctx.fillStyle = 'cyan';
                ctx.fillRect(d.x, d.y, 5, 5);
            });
            requestAnimationFrame(animate);
        };
        const animId = requestAnimationFrame(animate);
        return () => cancelAnimationFrame(animId);
    }, []);

    return (
        <div className="h-full bg-gray-900 p-4">
            <h2 className="text-xl font-bold text-orange-300">🚁 Interplanetary Drone Coordinator</h2>
            <canvas ref={canvasRef} width="500" height="300" className="w-full h-auto border border-orange-400/50 mt-4" />
        </div>
    );
};
