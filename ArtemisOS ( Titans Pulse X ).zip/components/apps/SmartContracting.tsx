/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { NativeAppComponentProps, LedgerTransaction } from '../../types';
import { systemBus } from '../../services/systemBus';
import { playSound, SoundType } from '../../services/audioService';

const PARTNERS = ['xAI', 'SpaceX', 'Three Ring Studios'];

const initialTransactions: LedgerTransaction[] = [
    { id: 'tx_1', timestamp: Date.now() - 120000, from: 'xAI', to: 'ArtemisOS', amount: 5000, asset: 'API Credits', memo: 'Initial resource allocation' },
    { id: 'tx_2', timestamp: Date.now() - 90000, from: 'ArtemisOS', to: 'SpaceX', amount: 1, asset: 'Optimization Profile v1.1', memo: 'Telemetry data processing efficiency' },
    { id: 'tx_3', timestamp: Date.now() - 60000, from: 'SpaceX', to: 'ArtemisOS', amount: 1000, asset: 'API Credits', memo: 'Return for optimization profile' },
    { id: 'tx_4', timestamp: Date.now() - 30000, from: 'Treasury', to: 'Three Ring Studios', amount: 15.7, asset: 'A-ETH', memo: 'Quarterly Payout' },
];

export const SmartContracting: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [transactions, setTransactions] = useState<LedgerTransaction[]>(initialTransactions);
    const [treasury, setTreasury] = useState({ 'A-ETH': 1250.5, 'API Credits': 4000 });

    const addTransaction = (memo: string) => {
        const from = 'ArtemisOS';
        const to = PARTNERS[Math.floor(Math.random() * PARTNERS.length)] as LedgerTransaction['to'];

        const newTx: LedgerTransaction = {
            id: `tx_${Date.now()}`,
            timestamp: Date.now(),
            from,
            to,
            amount: 1,
            asset: 'Blueprint License',
            memo,
        };

        setTransactions(prev => [newTx, ...prev]);
        systemBus.emit('log_system_event', {
            message: `New contract brokered with ${to} for: ${memo}`,
            icon: '⛓️',
            source: 'D-Ledger',
        });
        playSound(SoundType.TRANSITION);
    };

    const handleDeployContract = () => {
        const memo = (document.getElementById('contractMemo') as HTMLInputElement)?.value;
        if (memo) {
            addTransaction(memo);
        } else {
            alert('Please provide a memo for the contract.');
        }
    };
    
    // Simulate treasury growth
    useEffect(() => {
        const interval = setInterval(() => {
            setTreasury(prev => ({
                'A-ETH': prev['A-ETH'] + Math.random() * 0.5,
                'API Credits': prev['API Credits'] + Math.random() * 10,
            }));
        }, 5000);
        return () => clearInterval(interval);
    }, []);

    const getPartyColor = (party: LedgerTransaction['from']) => {
        switch(party) {
            case 'xAI': return 'text-blue-400';
            case 'SpaceX': return 'text-gray-400';
            case 'Three Ring Studios': return 'text-purple-400';
            case 'ArtemisOS': return 'text-cyan-400';
            case 'Treasury': return 'text-yellow-400';
            default: return 'text-white';
        }
    }

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0 pb-2 border-b border-gray-600">
                <h2 className="text-xl text-green-300 font-bold">📜 Smart Contracting</h2>
                <p className="text-sm text-gray-400">Gas-free transactions and smart contracts between partners.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-gray-800 p-4 rounded-lg">
                    <h3 className="text-gray-400 text-sm font-bold">Total Treasury Value (A-ETH)</h3>
                    <p className="text-2xl font-semibold text-green-400">{treasury['A-ETH'].toFixed(4)}</p>
                </div>
                <div className="bg-gray-800 p-4 rounded-lg">
                    <h3 className="text-gray-400 text-sm font-bold">System API Credits</h3>
                    <p className="text-2xl font-semibold text-green-400">{treasury['API Credits'].toFixed(0)}</p>
                </div>
                 <div className="bg-gray-800 p-4 rounded-lg">
                    <h3 className="text-gray-400 text-sm font-bold">Network Status</h3>
                    <p className="text-2xl font-semibold text-green-400 flex items-center gap-2">
                        <span className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></span>
                        Synchronized
                    </p>
                </div>
            </div>
            
            <div className="flex-grow flex gap-4 overflow-hidden">
                <div className="w-2/3 flex flex-col">
                    <h3 className="text-lg font-semibold mb-2">Transaction History</h3>
                    <div className="flex-grow overflow-y-auto pr-2 bg-black/30 rounded-lg p-2">
                         {transactions.map(tx => (
                            <div key={tx.id} className="font-mono text-xs mb-2 p-2 rounded bg-gray-800/50">
                                <p className="text-gray-500">TXID: {tx.id.slice(0, 16)}... | {new Date(tx.timestamp).toLocaleString()}</p>
                                <p>
                                    <span className={getPartyColor(tx.from)}>{tx.from}</span> → <span className={getPartyColor(tx.to)}>{tx.to}</span>
                                </p>
                                <p>
                                    <span className="font-bold text-white">{tx.amount} {tx.asset}</span>
                                </p>
                                <p className="text-gray-400">Memo: {tx.memo}</p>
                            </div>
                         ))}
                    </div>
                </div>
                <div className="w-1/3 flex flex-col gap-4">
                    <div className="bg-gray-800 rounded-lg p-4">
                        <h3 className="text-lg font-semibold mb-2">Broker New Contract</h3>
                        <p className="text-xs text-gray-400 mb-2">Create a fair-trade resource exchange.</p>
                        <div className="space-y-3">
                            <div>
                                <label htmlFor="contractMemo" className="text-xs font-bold">Memo (e.g., "Blueprint License: Ion Engine v2")</label>
                                <input type="text" id="contractMemo" className="w-full mt-1 p-2 rounded-md bg-gray-900 border border-gray-600 focus:border-green-400 outline-none" />
                            </div>
                            <button onClick={handleDeployContract} className="w-full py-2 bg-green-600 hover:bg-green-700 rounded-lg font-bold">
                                Deploy Contract
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
