/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useCallback } from 'react';
import { NativeAppComponentProps, NexusBuildConfig } from '../../types';
import { systemBus } from '../../services/systemBus';
import { playSound, SoundType } from '../../services/audioService';

const initialBuilds: NexusBuildConfig[] = [
    { id: 'build_1', name: 'Artemis Self-Setup', target: 'WSL', status: 'Deployed' },
    { id: 'build_2', name: 'Node Discovery Service', target: 'Kubernetes', status: 'Deployed' },
    { id: 'build_3', name: 'Revenue Matrix v2', target: 'Kubernetes', status: 'Building' },
];

export const NexusBuilder: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [builds, setBuilds] = useState<NexusBuildConfig[]>(initialBuilds);
    const [log, setLog] = useState<string[]>(['[NEXUS BUILDER INITIALIZED] Ready for deployment commands.']);
    
    const addLog = useCallback((message: string) => {
        systemBus.emit('log_system_event', { message, icon: '🛠️', source: 'Nexus Builder' });
        setLog(prev => [`[${new Date().toLocaleTimeString()}] ${message}`, ...prev].slice(0, 100));
    }, []);

    const handleScanHardware = () => {
        playSound(SoundType.TRANSITION);
        addLog("Scanning host hardware for capabilities...");
        setTimeout(() => addLog("Scan Complete: Detected WSL2, Docker Desktop (Kubernetes ready), PowerShell v7.4."), 1500);
        setTimeout(() => addLog("Hardware profile is suitable for NeoCor deployment."), 2000);
    };

    const handleDeploy = (target: 'WSL' | 'Kubernetes') => {
        playSound(SoundType.CLICK);
        const buildName = `New ${target} Deployment`;
        const newBuild: NexusBuildConfig = { id: `build_${Date.now()}`, name: buildName, target, status: 'Building' };
        setBuilds(prev => [newBuild, ...prev]);
        addLog(`Initiating new deployment: "${buildName}" to ${target}...`);
        setTimeout(() => addLog("Containerizing application with Docker..."), 1000);
        setTimeout(() => addLog(`Pushing image to repository...`), 2500);
        setTimeout(() => {
            addLog(`Deployment to ${target} cluster successful.`);
            setBuilds(prev => prev.map(b => b.id === newBuild.id ? { ...b, status: 'Deployed' } : b));
            playSound(SoundType.OPEN);
        }, 4000);
    };

    const getStatusColor = (status: NexusBuildConfig['status']) => {
        switch(status) {
            case 'Deployed': return 'text-green-400';
            case 'Building': return 'text-yellow-400 animate-pulse';
            case 'Failed': return 'text-red-400';
            default: return 'text-gray-400';
        }
    };

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0 pb-2 border-b border-gray-700">
                <h2 className="text-xl text-orange-400 font-bold">🛠️ Nexus Builder</h2>
                <p className="text-sm text-gray-400">Manage, build, and deploy NeoCor AI System components.</p>
            </div>

            <div className="flex-grow flex gap-4 overflow-hidden">
                <div className="w-1/2 flex flex-col">
                    <h3 className="text-lg font-semibold mb-2">Deployment Pipelines</h3>
                    <div className="flex gap-2 mb-4">
                        <button onClick={handleScanHardware} className="flex-1 p-2 bg-gray-700 hover:bg-gray-600 rounded">Scan Hardware</button>
                        <button onClick={() => handleDeploy('WSL')} className="flex-1 p-2 bg-blue-600 hover:bg-blue-500 rounded">Deploy to WSL</button>
                        <button onClick={() => handleDeploy('Kubernetes')} className="flex-1 p-2 bg-purple-600 hover:bg-purple-500 rounded">Deploy to Kubernetes</button>
                    </div>
                    <div className="flex-grow overflow-y-auto pr-2 bg-black/30 rounded-lg p-2">
                         {builds.map(build => (
                            <div key={build.id} className="font-mono text-sm mb-2 p-2 rounded bg-gray-800/50 flex justify-between items-center">
                                <div>
                                    <p className="font-bold text-white">{build.name}</p>
                                    <p className="text-xs text-gray-400">Target: {build.target}</p>
                                </div>
                                <p className={`font-bold ${getStatusColor(build.status)}`}>{build.status}</p>
                            </div>
                         ))}
                    </div>
                </div>
                <div className="w-1/2 bg-black rounded-lg p-3 font-mono text-xs text-cyan-300 flex flex-col">
                    <h3 className="text-sm font-semibold mb-2 p-2 border-b border-gray-700 text-white">Build & Deployment Log</h3>
                    <div className="flex-grow overflow-y-auto">
                        {log.map((line, i) => <p key={i} className="whitespace-pre-wrap">{line}</p>)}
                    </div>
                </div>
            </div>
        </div>
    );
};
