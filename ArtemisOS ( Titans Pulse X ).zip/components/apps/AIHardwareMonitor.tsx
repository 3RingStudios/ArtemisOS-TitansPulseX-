/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { NativeAppComponentProps, AIHardwareStats } from '../../types';

declare const Chart: any;

const createChart = (ctx: CanvasRenderingContext2D, label: string, color: string, max: number) => {
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: Array(20).fill(''),
            datasets: [{
                label,
                data: Array(20).fill(0),
                borderColor: color,
                borderWidth: 2,
                pointRadius: 0,
                tension: 0.4,
                fill: true,
                backgroundColor: `${color}33`,
            }],
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { display: false },
                y: { display: true, beginAtZero: true, max, ticks: { color: '#9ca3af', font: { size: 10 } } }
            },
        },
    });
};

export const AIHardwareMonitor: React.FC<Partial<NativeAppComponentProps>> = () => {
    const gpuChartRef = useRef<HTMLCanvasElement>(null);
    const vramChartRef = useRef<HTMLCanvasElement>(null);
    const charts = useRef<any>({});
    
    const [stats, setStats] = useState<AIHardwareStats>({
        gpu: {
            name: 'NVIDIA RTX 4090',
            utilization: 0,
            vramUsed: 0,
            vramTotal: 24,
            temperature: 35,
        },
        models: [
            { id: 'nano', name: 'Gemini Nano', status: 'Loaded', vram: 4.2 },
            { id: 'local-v2', name: 'Local-LLM-v2', status: 'Idle', vram: 8.5 },
            { id: 'vision', name: 'Vision Transformer', status: 'Loaded', vram: 2.1 },
        ],
    });

    useEffect(() => {
        if (typeof Chart === 'undefined') return;

        if (gpuChartRef.current) charts.current.gpu = createChart(gpuChartRef.current.getContext('2d')!, 'GPU %', '#22c55e', 100);
        if (vramChartRef.current) charts.current.vram = createChart(vramChartRef.current.getContext('2d')!, 'VRAM GB', '#3b82f6', stats.gpu.vramTotal);

        const interval = setInterval(() => {
            setStats(prev => {
                const loadedModels = prev.models.filter(m => m.status === 'Loaded');
                const baseVram = loadedModels.reduce((sum, m) => sum + m.vram, 0);
                const vramUsed = baseVram + Math.random() * 0.5;
                const utilization = (vramUsed / prev.gpu.vramTotal) * 70 + Math.random() * 20;
                const temperature = 45 + utilization * 0.3 + Math.random() * 5;

                const newStats: AIHardwareStats = {
                    ...prev,
                    gpu: { ...prev.gpu, utilization, vramUsed, temperature },
                };

                if (charts.current.gpu) {
                    const gpuData = charts.current.gpu.data.datasets[0].data;
                    gpuData.push(utilization);
                    gpuData.shift();
                    charts.current.gpu.update('none');
                }
                 if (charts.current.vram) {
                    const vramData = charts.current.vram.data.datasets[0].data;
                    vramData.push(vramUsed);
                    vramData.shift();
                    charts.current.vram.update('none');
                }

                return newStats;
            });
        }, 1500);

        return () => {
            clearInterval(interval);
            Object.values(charts.current).forEach((chart: any) => chart?.destroy());
        };
    }, [stats.gpu.vramTotal]);

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0 pb-2 border-b border-gray-700">
                <h2 className="text-xl text-yellow-300 font-bold">📟 AI Hardware Monitor</h2>
                <p className="text-sm text-gray-400">Real-time monitoring of the dedicated on-device AI accelerator.</p>
            </div>

            <div className="flex-shrink-0 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-gray-800 p-4 rounded-lg">
                    <h3 className="text-gray-400 text-sm font-bold">GPU</h3>
                    <p className="text-2xl font-semibold text-white">{stats.gpu.name}</p>
                </div>
                <div className="bg-gray-800 p-4 rounded-lg">
                    <h3 className="text-gray-400 text-sm font-bold">Temperature</h3>
                    <p className="text-2xl font-semibold text-white">{stats.gpu.temperature.toFixed(1)}°C</p>
                </div>
                <div className="bg-gray-800 p-4 rounded-lg">
                    <h3 className="text-gray-400 text-sm font-bold">VRAM Usage</h3>
                    <p className="text-2xl font-semibold text-white">{stats.gpu.vramUsed.toFixed(2)} / {stats.gpu.vramTotal} GB</p>
                </div>
            </div>

            <div className="flex-grow flex gap-4 overflow-hidden">
                <div className="w-2/3 flex flex-col gap-4">
                    <div className="flex-1 bg-gray-800 rounded-lg p-2"><canvas ref={gpuChartRef}></canvas></div>
                    <div className="flex-1 bg-gray-800 rounded-lg p-2"><canvas ref={vramChartRef}></canvas></div>
                </div>
                <div className="w-1/3 bg-gray-800 rounded-lg p-4 flex flex-col">
                    <h3 className="font-bold mb-2">Loaded Models</h3>
                    <div className="space-y-3">
                        {stats.models.map(model => (
                            <div key={model.id} className="bg-gray-700/50 p-3 rounded">
                                <p className="font-semibold">{model.name}</p>
                                <p className="text-xs text-gray-400">Status: <span className={model.status === 'Loaded' ? 'text-green-400' : 'text-gray-500'}>{model.status}</span></p>
                                <p className="text-xs text-gray-400">VRAM: {model.vram} GB</p>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};