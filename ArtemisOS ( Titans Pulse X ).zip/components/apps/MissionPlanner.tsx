/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useCallback, useState} from 'react';
import {streamText} from '../../services/geminiService';
import {playSound, SoundType} from '../../services/audioService';
import {Mission, NativeAppComponentProps} from '../../types';

export const MissionPlanner: React.FC<Partial<NativeAppComponentProps>> = () => {
  const [mission, setMission] = useState<Mission>({
    id: `mission_${Date.now()}`,
    name: '',
    target: 'Low Earth Orbit',
    objectives: '',
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>,
  ) => {
    const {name, value} = e.target;
    setMission((prev) => ({...prev, [name]: value}));
  };

  const handleGenerateBrief = useCallback(async () => {
    if (!mission.name || !mission.objectives) {
      alert('Please provide a mission name and objectives first.');
      return;
    }
    setIsLoading(true);
    setMission((prev) => ({...prev, brief: ''}));
    playSound(SoundType.TRANSITION);

    const prompt = `Generate a creative, narrative-style mission brief for a space mission with the following parameters. Be descriptive and engaging.
        - Mission Name: "${mission.name}"
        - Target: "${mission.target}"
        - Key Objectives: "${mission.objectives}"`;

    let accumulatedBrief = '';
    try {
      const stream = streamText(prompt);
      for await (const chunk of stream) {
        accumulatedBrief += chunk;
        setMission((prev) => ({...prev, brief: accumulatedBrief}));
      }
    } catch (e) {
      console.error(e);
      setMission((prev) => ({
        ...prev,
        brief: 'Error generating mission brief.',
      }));
    } finally {
      setIsLoading(false);
    }
  }, [mission.name, mission.target, mission.objectives]);

  const handleGeneratePackage = () => {
    if (!mission.name) {
        alert('Please provide a mission name first.');
        return;
    }
    playSound(SoundType.CLICK, 0.6);
    const projectName = mission.name.replace(/\s+/g, '');
    const log = `
[0.001s] Initiating Unreal Engine packaging sequence for project: ${projectName}...
[0.150s] Creating project file: /Content/${projectName}/${projectName}.uproject
[0.320s] Generating level blueprint: /Content/${projectName}/Maps/MainMission.umap
[0.550s] Compiling shaders for environment: ${mission.target}... 4,532 shaders compiled.
[1.230s] Generating vehicle asset: /Content/${projectName}/Blueprints/Vehicles/PlayerVehicle.uasset
[1.580s] Generating mission logic: /Content/${projectName}/Blueprints/Mission/ObjectiveManager.uasset
[1.950s] Packaging C++ source code...
[2.540s] Linking static libraries for physics simulation...
[3.110s] Packaging complete. Output: /Builds/${projectName}_v1.0.pak
    `;
    setMission(prev => ({...prev, unrealPackageLog: log.trim()}));
  };

  return (
    <div className="flex h-full bg-gray-200 text-gray-800 font-sans">
      <div className="flex-grow p-6 flex flex-col">
        <h2 className="text-2xl font-bold mb-4 text-gray-900 border-b pb-2">
          🚀 Mission Planner
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left Column: Mission Details */}
          <div>
            <div className="mb-4">
              <label htmlFor="name" className="llm-label font-semibold">
                Mission Name
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={mission.name}
                onChange={handleInputChange}
                className="llm-input"
                placeholder="e.g., Project Starfall"
              />
            </div>

            <div className="mb-4">
              <label htmlFor="target" className="llm-label font-semibold">
                Target Body
              </label>
              <select
                id="target"
                name="target"
                value={mission.target}
                onChange={handleInputChange}
                className="llm-input">
                <option>Low Earth Orbit</option>
                <option>Geostationary Orbit</option>
                <option>The Moon</option>
                <option>Mars</option>
                <option>Jupiter System</option>
                <option>Interstellar</option>
              </select>
            </div>

            <div className="mb-4">
              <label htmlFor="objectives" className="llm-label font-semibold">
                Key Objectives
              </label>
              <textarea
                id="objectives"
                name="objectives"
                value={mission.objectives}
                onChange={handleInputChange}
                className="llm-textarea"
                rows={4}
                placeholder="e.g., Deploy 3 comms satellites, perform orbital scan..."
              />
            </div>
             <button onClick={handleGenerateBrief} disabled={isLoading} className="llm-button w-full">
                {isLoading ? 'Generating Brief...' : 'AI: Generate Mission Brief'}
            </button>
          </div>
          {/* Right Column: AI Brief & Packaging */}
          <div className="flex flex-col gap-6">
            <div className="bg-white p-4 rounded-lg border flex-grow flex flex-col">
                <h3 className="text-lg font-semibold mb-2">AI-Generated Mission Brief</h3>
                <div className="flex-grow overflow-y-auto text-sm leading-relaxed pr-2">
                 {mission.brief ? (
                    <p className="whitespace-pre-wrap">{mission.brief}</p>
                ) : (
                    <p className="text-gray-500">Awaiting brief generation...</p>
                )}
                </div>
            </div>
             <div className="bg-gray-800 p-4 rounded-lg border-gray-700 border flex flex-col">
                <h3 className="text-lg font-semibold mb-2 text-green-300">Unreal Package Log</h3>
                 <div className="flex-grow overflow-y-auto text-xs font-mono text-green-400 h-32 pr-2">
                    {mission.unrealPackageLog ? (
                        <p className="whitespace-pre-wrap">{mission.unrealPackageLog}</p>
                    ) : (
                        <p className="text-gray-400">Awaiting packaging...</p>
                    )}
                </div>
                 <button onClick={handleGeneratePackage} className="llm-button bg-green-600 hover:bg-green-700 w-full mt-2">
                    Generate Unreal Package Log
                </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};