/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { systemBus } from '../../services/systemBus';
import { playSound, SoundType } from '../../services/audioService';
import { NativeAppComponentProps } from '../../types';

export const HostBridge: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [isConnected, setIsConnected] = useState(false);
    const [log, setLog] = useState<string[]>(['[WebRTC Host Bridge Initialized]']);

    const addLog = (message: string) => {
        setLog(prev => [`[${new Date().toLocaleTimeString()}] ${message}`, ...prev].slice(0, 100));
        systemBus.emit('log_system_event', {
            message,
            icon: '🌉',
            source: 'HostBridge',
        });
    };

    const handleConnect = () => {
        addLog('Attempting to establish peer connection with host...');
        playSound(SoundType.TRANSITION);
        setTimeout(() => {
            addLog('ICE candidates exchanged successfully.');
        }, 1000);
        setTimeout(() => {
            addLog('Secure data channel established. Host bridge is active.');
            setIsConnected(true);
            systemBus.emit('host_bridge_connected');
            playSound(SoundType.OPEN);
        }, 2000);
    };
    
    const handleDisconnect = () => {
        addLog('Closing peer connection...');
        setIsConnected(false);
        systemBus.emit('host_bridge_disconnected');
        playSound(SoundType.CLOSE);
        setTimeout(() => {
            addLog('Connection terminated. Host bridge is offline.');
        }, 500);
    };

    useEffect(() => {
        // Announce disconnection on unmount
        return () => {
            if (isConnected) {
                systemBus.emit('host_bridge_disconnected');
            }
        };
    }, [isConnected]);

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0 pb-2 border-b border-gray-700">
                <h2 className="text-xl text-sky-400 font-bold">🌉 Host Bridge</h2>
                <p className="text-sm text-gray-400">Bypass browser sandbox via a simulated WebRTC link to the local host.</p>
            </div>

            <div className="flex-shrink-0 bg-gray-800/50 p-4 rounded-lg flex flex-col items-center">
                <div className={`w-24 h-24 rounded-full flex items-center justify-center mb-4 transition-all ${isConnected ? 'bg-green-500 shadow-lg shadow-green-500/30' : 'bg-red-500 shadow-lg shadow-red-500/30'}`}>
                    <span className="text-5xl">{isConnected ? '✔️' : '❌'}</span>
                </div>
                 <h3 className="text-lg font-bold">{isConnected ? 'Status: Connected' : 'Status: Disconnected'}</h3>
                 <p className="text-xs text-gray-500 mb-4">{isConnected ? 'Host features are now available across the OS.' : 'Connect to enable offline capabilities.'}</p>
                <button
                    onClick={isConnected ? handleDisconnect : handleConnect}
                    className={`llm-button m-0 w-1/2 text-lg ${isConnected ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}`}
                >
                    {isConnected ? 'Disconnect' : 'Connect'}
                </button>
            </div>

            <div className="flex-grow flex flex-col bg-black/30 rounded-lg overflow-hidden">
                <h3 className="p-3 font-bold text-gray-400 border-b border-gray-700">Connection Log</h3>
                 <div className="flex-grow overflow-y-auto p-3 font-mono text-xs">
                    {log.map((line, i) => <p key={i}>{line}</p>)}
                 </div>
            </div>
        </div>
    );
};