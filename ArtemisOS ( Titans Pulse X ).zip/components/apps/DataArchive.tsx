/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useCallback, useMemo } from 'react';
import { NativeAppComponentProps } from '../../types';
import { systemBus } from '../../services/systemBus';
import { playSound, SoundType } from '../../services/audioService';

// Type definitions for the File System Access API handles
interface FSItem {
    name: string;
    kind: 'file' | 'directory';
    handle: FileSystemHandle;
}

export const DataArchive: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [currentDirectoryHandle, setCurrentDirectoryHandle] = useState<FileSystemDirectoryHandle | null>(null);
    const [currentItems, setCurrentItems] = useState<FSItem[]>([]);
    const [currentPath, setCurrentPath] = useState<string[]>([]);
    const [fileContent, setFileContent] = useState<string | null>(null);
    const [status, setStatus] = useState('Ready. Open a host directory to begin.');
    const [error, setError] = useState<string | null>(null);
    const [searchTerm, setSearchTerm] = useState('');

    const logSystemEvent = (message: string) => {
        systemBus.emit('log_system_event', {
            message,
            icon: '🗂️',
            source: 'HostFileBrowser',
        });
    };

    const loadDirectory = useCallback(async (dirHandle: FileSystemDirectoryHandle, path: string[]) => {
        try {
            setStatus(`Reading directory: ${path.join('/')}...`);
            const items: FSItem[] = [];
            for await (const handle of (dirHandle as any).values()) {
                items.push({ name: handle.name, kind: handle.kind, handle });
            }
            setCurrentItems(items.sort((a, b) => {
                if (a.kind === b.kind) return a.name.localeCompare(b.name);
                return a.kind === 'directory' ? -1 : 1;
            }));
            setCurrentDirectoryHandle(dirHandle);
            setCurrentPath(path);
            setFileContent(null);
            setError(null);
            setStatus(`Loaded ${items.length} items from ${path.join('/')}.`);
        } catch (e: any) {
            setError(`Permission denied or error reading directory: ${e.message}`);
            setStatus('Error.');
        }
    }, []);

    const handleOpenDirectory = async () => {
        try {
            const handle = await (window as any).showDirectoryPicker();
            loadDirectory(handle, [handle.name]);
            playSound(SoundType.OPEN);
            logSystemEvent(`Opened host directory: ${handle.name}`);
        } catch (e: any) {
            if (e.name !== 'AbortError') {
                setError(`Could not open directory: ${e.message}`);
            }
        }
    };

    const handleItemClick = async (item: FSItem) => {
        setError(null);
        if (item.kind === 'directory') {
            loadDirectory(item.handle as FileSystemDirectoryHandle, [...currentPath, item.name]);
        } else if (item.kind === 'file') {
            try {
                setStatus(`Reading file: ${item.name}...`);
                const fileHandle = item.handle as FileSystemFileHandle;
                const file = await fileHandle.getFile();
                
                // Open editable files in the Code Editor
                if (file.type.startsWith('text/') || file.type.includes('json') || file.type.includes('javascript') || item.name.match(/\.(md|log|py|rb|xml|html|css|ts|tsx)$/)) {
                    const content = await file.text();
                    systemBus.emit('execute_command', {
                        command: 'open_app',
                        appId: 'code_editor_app',
                        payload: { name: item.name, content: content } // Send file data to editor
                    });
                    logSystemEvent(`Opened ${item.name} in Code Editor.`);
                    setFileContent(null);
                    setStatus(`Opened ${item.name} in Code Editor.`);
                } else {
                    // For non-editable files, show info
                    setFileContent(`[Binary File: ${item.name}]\nType: ${file.type}\nSize: ${file.size} bytes\n\nPreview is not available. Open in Code Editor to view as text.`);
                    setStatus(`Preview not available for ${item.name}.`);
                }
            } catch (e: any) {
                setError(`Could not read file: ${e.message}`);
                setFileContent(null);
            }
        }
    };
    
    const handleCreateFile = async () => {
        if (!currentDirectoryHandle) return;
        const fileName = prompt('Enter new text file name:', 'new-file.txt');
        if (fileName) {
            try {
                const fileHandle = await currentDirectoryHandle.getFileHandle(fileName, { create: true });
                const writable = await fileHandle.createWritable();
                await writable.write(`// Created by ArtemisOS at ${new Date().toISOString()}`);
                await writable.close();
                logSystemEvent(`Created file: ${fileName}`);
                loadDirectory(currentDirectoryHandle, currentPath); // Refresh
            } catch (e: any) {
                setError(`Could not create file: ${e.message}`);
            }
        }
    };

    const handleCreateFolder = async () => {
        if (!currentDirectoryHandle) return;
        const folderName = prompt('Enter new folder name:');
        if (folderName) {
            try {
                await currentDirectoryHandle.getDirectoryHandle(folderName, { create: true });
                logSystemEvent(`Created directory: ${folderName}`);
                loadDirectory(currentDirectoryHandle, currentPath); // Refresh
            } catch (e: any) {
                setError(`Could not create folder: ${e.message}`);
            }
        }
    };

    const filteredItems = useMemo(() => {
        if (!searchTerm) return currentItems;
        return currentItems.filter(item => item.name.toLowerCase().includes(searchTerm.toLowerCase()));
    }, [currentItems, searchTerm]);

    return (
        <div className="h-full bg-gray-800 text-gray-300 font-sans flex flex-col">
            <div className="flex-shrink-0 p-2 border-b border-gray-700 flex items-center gap-2">
                <button onClick={handleOpenDirectory} className="llm-button m-0 py-1 px-2 text-sm">Open Directory</button>
                <button onClick={handleCreateFile} disabled={!currentDirectoryHandle} className="llm-button m-0 py-1 px-2 text-sm bg-green-600 hover:bg-green-700 disabled:bg-gray-600">New File</button>
                <button onClick={handleCreateFolder} disabled={!currentDirectoryHandle} className="llm-button m-0 py-1 px-2 text-sm bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600">New Folder</button>
                <div className="flex-grow font-mono text-sm p-2 bg-black/30 rounded">
                    {currentPath.join(' / ')}
                </div>
            </div>
             <div className="flex-shrink-0 p-2 border-b border-gray-700">
                <input
                    type="text"
                    placeholder="Search current folder..."
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="w-full p-2 rounded-md bg-gray-900 border border-gray-600 focus:border-cyan-400 outline-none text-sm"
                    disabled={!currentDirectoryHandle}
                />
            </div>

            <div className="flex-grow flex overflow-hidden">
                <div className="w-1/3 border-r border-gray-700 overflow-y-auto">
                    {filteredItems.map(item => (
                        <div key={item.name} onDoubleClick={() => handleItemClick(item)}
                            className="flex items-center gap-3 p-2 cursor-pointer hover:bg-gray-700/50 text-sm">
                            <span className="text-xl">{item.kind === 'directory' ? '📁' : '📄'}</span>
                            <span className="truncate">{item.name}</span>
                        </div>
                    ))}
                </div>
                <div className="w-2/3 flex flex-col">
                    <div className="flex-grow bg-black/30 p-2 overflow-y-auto">
                        <pre className="text-xs whitespace-pre-wrap">{fileContent ?? '// Select a file to view its content, or double-click an editable file to open it in the Code Editor.'}</pre>
                    </div>
                </div>
            </div>
             <div className="flex-shrink-0 p-1 border-t border-gray-700 text-xs text-center text-gray-400">
                {error ? <span className="text-red-400">{error}</span> : <span>{status}</span>}
            </div>
        </div>
    );
};