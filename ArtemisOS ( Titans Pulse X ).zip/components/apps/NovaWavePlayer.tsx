/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState } from 'react';
import { NativeAppComponentProps, MediaItem } from '../../types';

const mockPlaylist: MediaItem[] = [
    { id: 'track_1', title: 'Starlight Echoes', artist: 'Celestial Harmonics', duration: 210, source: '' },
    { id: 'track_2', title: 'Frequency Shift', artist: 'JW1667', duration: 185, source: '' },
    { id: 'track_3', title: 'Quantum Entanglement', artist: 'Artemis AI', duration: 240, source: '' },
];

export const NovaWavePlayer: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [playlist] = useState<MediaItem[]>(mockPlaylist);
    const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
    const [isPlaying, setIsPlaying] = useState(false);
    const [progress, setProgress] = useState(0);

    const currentTrack = playlist[currentTrackIndex];

    const formatTime = (seconds: number) => new Date(seconds * 1000).toISOString().substr(14, 5);

    return (
        <div 
            className="h-full bg-cover bg-center text-white font-sans flex flex-col p-6"
            style={{ backgroundImage: "url('https://source.unsplash.com/random/1024x768/?nebula')" }}
        >
            <div className="absolute inset-0 bg-black/70 backdrop-blur-md"></div>
            <div className="relative z-10 flex flex-col h-full">
                <div className="flex-grow flex items-center justify-center flex-col">
                    <div className="text-center">
                        <h2 className="text-4xl font-bold">{currentTrack.title}</h2>
                        <p className="text-xl text-gray-300">{currentTrack.artist}</p>
                    </div>
                </div>

                <div className="flex-shrink-0">
                    <div className="w-full bg-white/20 rounded-full h-1.5 mb-2">
                        <div className="bg-cyan-400 h-1.5 rounded-full" style={{ width: `${progress}%` }}></div>
                    </div>
                    <div className="flex justify-between text-xs">
                        <span>{formatTime(progress / 100 * currentTrack.duration)}</span>
                        <span>{formatTime(currentTrack.duration)}</span>
                    </div>

                    <div className="flex items-center justify-center gap-6 my-4">
                        <button className="text-3xl hover:text-cyan-300 transition-colors">⏮</button>
                        <button 
                            onClick={() => setIsPlaying(!isPlaying)}
                            className="w-16 h-16 rounded-full bg-cyan-400 text-black flex items-center justify-center text-4xl hover:bg-cyan-300 transition-colors"
                        >
                            {isPlaying ? '⏸' : '▶'}
                        </button>
                        <button className="text-3xl hover:text-cyan-300 transition-colors">⏭</button>
                    </div>
                </div>
            </div>
        </div>
    );
};
