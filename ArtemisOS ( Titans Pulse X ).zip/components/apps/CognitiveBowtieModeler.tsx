/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState } from 'react';
import { NativeAppComponentProps, BowtieDecision } from '../../types';
import { playSound, SoundType } from '../../services/audioService';

const DECISIONS: Record<string, string[]> = {
    '3': ['Innovate', 'Observe', 'Wait'],
    '2': ['Will', 'Will Not'],
    '1': ['Can'],
};

export const CognitiveBowtieModeler: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [path, setPath] = useState<number[]>([]);
    const [outcome, setOutcome] = useState<string>('');

    const handleSelect = (level: number, choice: number) => {
        playSound(SoundType.CLICK, 0.5);
        const newPath = [...path, choice];
        setPath(newPath);

        if (newPath.length === 6) {
            // Simple outcome generation
            const outcomes = [
                "Result: New technology blueprint synthesized.",
                "Result: Market trend identified and exploited.",
                "Result: System resource allocation optimized.",
                "Result: Anomaly detected and neutralized."
            ];
            setOutcome(outcomes[Math.floor(Math.random() * outcomes.length)]);
        }
    };
    
    const reset = () => {
        playSound(SoundType.TRANSITION);
        setPath([]);
        setOutcome('');
    };
    
    const renderNode = (level: number, text: string, choiceIndex: number) => {
        const isSelected = path[level] === choiceIndex;
        const isFuture = path.length < level;
        return (
            <button 
                onClick={() => handleSelect(level, choiceIndex)}
                disabled={path.length !== level}
                className={`p-2 rounded border-2 transition-all text-xs
                    ${isSelected ? 'bg-pink-500 border-pink-400' : ''}
                    ${path.length === level ? 'bg-gray-600 border-gray-500 hover:bg-pink-600' : ''}
                    ${isFuture ? 'bg-gray-800 border-gray-700 text-gray-500' : ''}
                `}
            >
                {text}
            </button>
        );
    };

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col items-center">
            <h2 className="text-xl text-pink-300 font-bold mb-2">🎀 Cognitive Bowtie Modeler</h2>
            <p className="text-sm text-gray-400 mb-6">Tracing the 3x2x1 :: 1x2x3 Decision-Making Process</p>
            
            <div className="w-full flex justify-center items-center gap-4 font-mono">
                {/* Cause */}
                <div className="flex flex-col gap-2 items-center">
                    {renderNode(0, 'Innovate', 0)}
                    {renderNode(0, 'Observe', 1)}
                    {renderNode(0, 'Wait', 2)}
                </div>
                →
                <div className="flex flex-col gap-2 items-center">
                    {renderNode(1, 'Will', 0)}
                    {renderNode(1, 'Will Not', 1)}
                </div>
                →
                <div className="flex flex-col gap-2 items-center">
                    {renderNode(2, 'Can', 0)}
                </div>

                <div className="text-4xl text-pink-400">::</div>

                {/* Effect */}
                <div className="flex flex-col gap-2 items-center">
                    {renderNode(3, 'Cannot', 0)}
                </div>
                →
                <div className="flex flex-col gap-2 items-center">
                    {renderNode(4, 'Did', 0)}
                    {renderNode(4, 'Did Not', 1)}
                </div>
                →
                <div className="flex flex-col gap-2 items-center">
                    {renderNode(5, 'Result A', 0)}
                    {renderNode(5, 'Result B', 1)}
                    {renderNode(5, 'Result C', 2)}
                </div>
            </div>

            <div className="mt-8 p-4 bg-black/30 rounded-lg w-full max-w-lg text-center">
                <h3 className="font-bold mb-2">Outcome</h3>
                <p className="text-green-400 h-6">{outcome}</p>
            </div>
            
            <button onClick={reset} className="mt-4 px-6 py-2 bg-gray-700 hover:bg-gray-600 rounded">Reset Flow</button>
        </div>
    );
};