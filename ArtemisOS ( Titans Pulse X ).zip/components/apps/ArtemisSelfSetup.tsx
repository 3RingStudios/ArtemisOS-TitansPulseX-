/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { NativeAppComponentProps } from '../../types';
import { playSound, SoundType } from '../../services/audioService';

const STEPS = [
    "Detecting Host Hardware...",
    "Calibrating Neural Net...",
    "Linking to Quantum Simulation...",
    "Verifying Harmonic Resonators...",
    "System Integrity Check...",
    "Artemis Self-Setup Complete."
];

export const ArtemisSelfSetup: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [currentStep, setCurrentStep] = useState(0);
    const [completed, setCompleted] = useState(false);

    useEffect(() => {
        if (completed) return;
        const timer = setInterval(() => {
            setCurrentStep(prev => {
                if (prev >= STEPS.length - 1) {
                    clearInterval(timer);
                    setCompleted(true);
                    playSound(SoundType.OPEN);
                    return prev;
                }
                playSound(SoundType.CLICK, 0.3);
                return prev + 1;
            });
        }, 1500);
        return () => clearInterval(timer);
    }, [completed]);

    return (
        <div className="h-full bg-gray-800 text-gray-300 font-sans p-6 flex flex-col items-center justify-center text-center">
             <h2 className="text-2xl text-red-300 font-bold mb-4">🚀 Artemis Self-Setup</h2>
             <div className="w-full max-w-md space-y-3">
                {STEPS.map((step, index) => (
                    <div key={index} className={`p-3 rounded-lg border transition-all duration-500
                        ${index < currentStep ? 'bg-green-800/50 border-green-600' : ''}
                        ${index === currentStep ? 'bg-blue-800/50 border-blue-600' : ''}
                        ${index > currentStep ? 'bg-gray-700/50 border-gray-600' : ''}
                    `}>
                        <p>
                            {index < currentStep ? '✅' : (index === currentStep ? '⏳' : '📋')} {step}
                        </p>
                    </div>
                ))}
             </div>
             {completed && <p className="mt-6 text-xl text-green-400 font-bold animate-pulse">System is ready.</p>}
        </div>
    );
};