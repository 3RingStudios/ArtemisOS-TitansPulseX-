/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useMemo, useCallback } from 'react';
import { NativeAppComponentProps, EarthDataSet } from '../../types';
import { systemBus } from '../../services/systemBus';

const mockDataSets: EarthDataSet[] = [
    { 
      id: 'ds_1', name: 'Global Temperature Anomaly (GISTEMP v4)', type: 'Atmospheric', region: 'Global', 
      resolution: '250km', lastUpdated: '2024-07-15', 
      description: 'Provides a measure of the changing global surface temperature.',
      imageUrl: 'https://images.unsplash.com/photo-1542036989-923812735749?q=80&w=2070'
    },
    { 
      id: 'ds_2', name: 'Sea Surface Temperature (MODIS)', type: 'Oceanic', region: 'Global', 
      resolution: '4km', lastUpdated: '2024-07-28',
      description: 'Daily sea surface temperature aggregated from the MODIS sensor on Aqua and Terra satellites.',
      imageUrl: 'https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?q=80&w=2070'
    },
    { 
      id: 'ds_3', name: 'Antarctic Ice Sheet Mass (GRACE)', type: 'Cryosphere', region: 'Antarctica', 
      resolution: '150km', lastUpdated: '2024-06-30',
      description: 'Measures changes in the mass of the Antarctic ice sheet using gravitational data.',
      imageUrl: 'https://images.unsplash.com/photo-1549472301-34f37e454378?q=80&w=1974'
    },
    { 
      id: 'ds_4', name: 'Carbon Monoxide Concentration (MOPITT)', type: 'Atmospheric', region: 'Global', 
      resolution: '22km', lastUpdated: '2024-07-29',
      description: 'Tracks the global distribution of carbon monoxide in the lower atmosphere.',
      imageUrl: 'https://images.unsplash.com/photo-1516091876541-1314a3a6b8ea?q=80&w=2070'
    },
    {
      id: 'ds_5', name: 'Global Digital Elevation Model (ASTER)', type: 'Geological', region: 'Global',
      resolution: '30m', lastUpdated: '2022-10-15',
      description: 'A high-resolution topographic map of nearly the entire Earth.',
      imageUrl: 'https://images.unsplash.com/photo-1590214298491-2d570531b793?q=80&w=2071'
    }
];

const Modal: React.FC<{ title: string; content: string; onClose: () => void }> = ({ title, content, onClose }) => (
    <div className="absolute inset-0 bg-black/70 z-20 flex items-center justify-center" onClick={onClose} role="dialog" aria-modal="true">
        <div className="bg-gray-800 rounded-lg p-4 w-1/2 max-w-2xl border border-gray-600" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-lg text-cyan-300 mb-2">{title}</h3>
            <pre className="bg-black/50 p-3 rounded text-xs text-green-300 overflow-auto max-h-96"><code>{content}</code></pre>
            <button onClick={onClose} className="mt-4 w-full py-2 bg-gray-600 hover:bg-gray-500 rounded">Close</button>
        </div>
    </div>
);

export const NasaEarthDataExplorer: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [datasets] = useState<EarthDataSet[]>(mockDataSets);
    const [selectedDataset, setSelectedDataset] = useState<EarthDataSet | null>(datasets[1]);
    const [filters, setFilters] = useState({ searchTerm: '', type: 'all', region: 'all' });
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [modalContent, setModalContent] = useState({ title: '', content: '' });

    const filteredDatasets = useMemo(() => {
        return datasets.filter(ds => 
            ds.name.toLowerCase().includes(filters.searchTerm.toLowerCase()) &&
            (filters.type === 'all' || ds.type === filters.type) &&
            (filters.region === 'all' || ds.region === filters.region)
        );
    }, [datasets, filters]);
    
    const handleAction = (type: 'analyze' | 'simulate' | 'algorithm' | 'python') => {
        if (!selectedDataset) return;
        
        switch(type) {
            case 'analyze':
                systemBus.emit('execute_command', { command: 'open_app', appId: 'data_cruncher_app', payload: { datasetId: selectedDataset.id } });
                break;
            case 'simulate':
                systemBus.emit('execute_command', { command: 'open_app', appId: 'climate_restoration_app', payload: { datasetId: selectedDataset.id } });
                break;
            case 'algorithm':
                setModalContent({
                    title: `Source Algorithm for ${selectedDataset.name}`,
                    content: `// Simplified algorithm for demonstration\nfunction process${selectedDataset.type}Data(rawData) {\n  const calibrated = applyCalibration(rawData);\n  const projected = reprojectToGrid(calibrated);\n  return aggregate(projected, '${selectedDataset.resolution}');\n}`
                });
                setIsModalOpen(true);
                break;
            case 'python':
                 setModalContent({
                    title: `Python Access via earthaccess`,
                    content: `import earthaccess\n\n# Authenticate\nearthaccess.login()\n\n# Search for data\nresults = earthaccess.search_data(\n  short_name='${selectedDataset.name.split(' ')[0]}',\n  cloud_hosted=True,\n  temporal=("2024-01-01", "2024-01-31")\n)\n\n# Download data\nearthaccess.download(results, local_path='./data/')`
                });
                setIsModalOpen(true);
                break;
        }
    };


    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans flex relative">
            {isModalOpen && <Modal title={modalContent.title} content={modalContent.content} onClose={() => setIsModalOpen(false)} />}
            
            {/* Left Panel: Filters & Datasets */}
            <div role="region" aria-labelledby="filter-heading" className="w-1/4 h-full flex flex-col p-2 border-r border-gray-700 bg-black/20">
                <h2 id="filter-heading" className="text-xl text-blue-300 font-bold mb-2 p-2">🌍 NASA Earth Data</h2>
                <div className="p-2 space-y-2">
                    <label className="block text-xs text-gray-400">Search datasets
                        <input type="text" placeholder="Search datasets..." value={filters.searchTerm} onChange={e => setFilters(f => ({...f, searchTerm: e.target.value}))} className="w-full bg-gray-800 p-2 rounded border border-gray-600 outline-none focus:border-blue-400 mt-1"/>
                    </label>
                    <label className="block text-xs text-gray-400">Filter by type
                        <select value={filters.type} onChange={e => setFilters(f => ({...f, type: e.target.value}))} className="w-full bg-gray-800 p-2 rounded border border-gray-600 mt-1">
                            <option value="all">All Types</option>
                            <option value="Atmospheric">Atmospheric</option>
                            <option value="Oceanic">Oceanic</option>
                            <option value="Geological">Geological</option>
                            <option value="Cryosphere">Cryosphere</option>
                        </select>
                    </label>
                     <button onClick={() => setFilters({ searchTerm: '', type: 'all', region: 'all' })} className="w-full text-xs text-gray-400 hover:text-white py-1">Clear Filters</button>
                </div>
                <div className="flex-grow overflow-y-auto pr-1 mt-2" role="listbox" aria-label="Available Datasets">
                    {filteredDatasets.map(ds => (
                        <div key={ds.id} onClick={() => setSelectedDataset(ds)}
                            role="option"
                            aria-selected={selectedDataset?.id === ds.id}
                            className={`p-2 rounded mb-1 cursor-pointer transition-colors ${selectedDataset?.id === ds.id ? 'bg-blue-600/50' : 'hover:bg-gray-700/50'}`}>
                            <p className="font-semibold text-sm">{ds.name}</p>
                            <p className="text-xs text-gray-400">{ds.type} - {new Date(ds.lastUpdated).toLocaleDateString()}</p>
                        </div>
                    ))}
                </div>
            </div>

            {/* Center Panel: Map */}
            <main role="region" aria-labelledby="map-heading" className="w-1/2 h-full flex items-center justify-center bg-black relative">
                 <div className="w-full h-full rounded-lg bg-cover bg-center transition-all duration-500" style={{backgroundImage: `url('${selectedDataset?.imageUrl}')`}}>
                    <div className="w-full h-full bg-blue-900/10 flex items-end p-4">
                        <h3 id="map-heading" className="text-white font-bold text-2xl drop-shadow-lg bg-black/30 p-2 rounded">
                           {selectedDataset?.name || "Select a Layer"}
                        </h3>
                    </div>
                </div>
            </main>

            {/* Right Panel: Details */}
             <aside role="region" aria-labelledby="details-heading" className="w-1/4 h-full flex flex-col p-2 border-l border-gray-700 bg-black/20">
                <h3 id="details-heading" className="font-bold text-lg p-2">Dataset Details</h3>
                {selectedDataset ? (
                    <div className="flex-grow p-2 overflow-y-auto">
                        <h4 className="font-bold text-blue-300">{selectedDataset.name}</h4>
                        <p className="text-sm mt-2">{selectedDataset.description}</p>
                        <div className="font-mono text-xs mt-4 space-y-1 bg-gray-800/50 p-2 rounded">
                           <p><strong>Resolution:</strong> {selectedDataset.resolution}</p>
                           <p><strong>Last Updated:</strong> {new Date(selectedDataset.lastUpdated).toDateString()}</p>
                           <p><strong>Region:</strong> {selectedDataset.region}</p>
                        </div>
                        <div className="mt-4">
                            <h4 className="font-bold mb-2">Actions</h4>
                            <div className="space-y-2">
                                <button onClick={() => handleAction('analyze')} disabled={!selectedDataset} className="w-full text-sm py-2 bg-green-600 hover:bg-green-700 rounded disabled:bg-gray-500 disabled:cursor-not-allowed">Analyze in Data Cruncher</button>
                                <button onClick={() => handleAction('simulate')} disabled={!selectedDataset} className="w-full text-sm py-2 bg-purple-600 hover:bg-purple-700 rounded disabled:bg-gray-500 disabled:cursor-not-allowed">Simulate Restoration Scenario</button>
                                <button onClick={() => handleAction('algorithm')} disabled={!selectedDataset} className="w-full text-sm py-2 bg-gray-600 hover:bg-gray-500 rounded disabled:bg-gray-500 disabled:cursor-not-allowed">View Source Algorithm</button>
                                <button onClick={() => handleAction('python')} disabled={!selectedDataset} className="w-full text-sm py-2 bg-gray-600 hover:bg-gray-500 rounded disabled:bg-gray-500 disabled:cursor-not-allowed">Access via `earthaccess`</button>
                            </div>
                        </div>
                    </div>
                ) : (
                    <p className="p-2 text-gray-500">Select a dataset to see details and actions.</p>
                )}
             </aside>

        </div>
    );
};
