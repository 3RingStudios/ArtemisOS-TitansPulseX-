/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useCallback, useEffect, useRef, useState} from 'react';
import { NativeAppComponentProps } from '../../types';

// Since Bootstrap is loaded globally, we can use its JS.
// We declare the `bootstrap` object to satisfy TypeScript.
declare const bootstrap: any;

// A self-contained, stateful React component for the Revenue Hub.
export const RevenueHub: React.FC<Partial<NativeAppComponentProps>> = () => {
  const [stats, setStats] = useState({
    totalAssets: 18456.78,
    dailyRevenue: 125.45,
    activeStreams: 3,
    aiCollaborators: 3,
  });

  const [systemHealth, setSystemHealth] = useState({
    cpu: 25,
    memory: 45,
    network: 15,
  });

  const [revenueStreams, setRevenueStreams] = useState([
    {
      id: 'stream_1',
      name: 'Smart Contract Royalties',
      type: 'smart-contract',
      balance: 12500.75,
      dailyChange: 42.5,
      status: 'active',
      contractAddress: '0x742d35Cc6634C0532925a3b844Bc454e4438f44e',
    },
    {
      id: 'stream_2',
      name: 'Affiliate Marketing',
      type: 'affiliate',
      balance: 875.2,
      dailyChange: 18.75,
      status: 'active',
      network: 'Amazon Associates',
    },
    {
      id: 'stream_3',
      name: 'DeFi Yield Farming',
      type: 'defi',
      balance: 5080.83,
      dailyChange: 64.2,
      status: 'active',
      protocol: 'Aave',
    },
  ]);

  const [activities, setActivities] = useState<
    {timestamp: Date; message: string}[]
  >([
    {timestamp: new Date(), message: 'System initialized and ready'},
    {timestamp: new Date(), message: 'Loaded 3 revenue streams'},
  ]);

  const [chat, setChat] = useState([
    {
      sender: 'ai',
      text: "Hello! I'm your AI Revenue Assistant. How can I help optimize your revenue streams today?",
    },
  ]);

  const [terminalLog, setTerminalLog] = useState([
    'Autonomous Revenue System Terminal v1.0',
    'Type "help" for available commands',
    '-----------------------------------',
  ]);

  // Refs for modals
  const addStreamModalRef = useRef<any>(null);
  const aiCollabModalRef = useRef<any>(null);
  const settingsModalRef = useRef<any>(null);

  const addActivity = useCallback((message: string) => {
    setActivities((prev) => [
      {timestamp: new Date(), message},
      ...prev,
    ].slice(0, 20));
  }, []);

  const addTerminalLine = useCallback((line: string) => {
    setTerminalLog((prev) => [...prev, line].slice(-50));
  }, []);

  const addChatMessage = useCallback(
    (sender: 'ai' | 'human', text: string) => {
      setChat((prev) => [...prev, {sender, text}].slice(-20));
    },
    [],
  );

  // Effect for initializing and managing modals
  useEffect(() => {
    const addStreamEl = document.getElementById('addStreamModal');
    const aiCollabEl = document.getElementById('aiCollabModal');
    const settingsEl = document.getElementById('settingsModal');

    if (addStreamEl) addStreamModalRef.current = new bootstrap.Modal(addStreamEl);
    if (aiCollabEl) aiCollabModalRef.current = new bootstrap.Modal(aiCollabEl);
    if (settingsEl) settingsModalRef.current = new bootstrap.Modal(settingsEl);
  }, []);

  // Effect for live data simulation
  useEffect(() => {
    const healthInterval = setInterval(() => {
      setSystemHealth({
        cpu: Math.max(5, Math.min(80, systemHealth.cpu + (Math.random() * 10 - 5))),
        memory: Math.max(20, Math.min(90, systemHealth.memory + (Math.random() * 10 - 5))),
        network: Math.max(5, Math.min(50, systemHealth.network + (Math.random() * 10 - 5))),
      });
    }, 5000);

    const revenueInterval = setInterval(() => {
      let dailyTotal = 0;
      const updatedStreams = revenueStreams.map((s) => {
        const change = (Math.random() - 0.3) * (s.balance / 1000);
        dailyTotal += change;
        return {...s, balance: s.balance + change, dailyChange: change};
      });

      setRevenueStreams(updatedStreams);
      setStats((prev) => ({
        ...prev,
        totalAssets: updatedStreams.reduce((sum, s) => sum + s.balance, 0),
        dailyRevenue: prev.dailyRevenue + dailyTotal,
        activeStreams: updatedStreams.filter((s) => s.status === 'active').length,
      }));
    }, 3000);

    return () => {
      clearInterval(healthInterval);
      clearInterval(revenueInterval);
    };
  }, [revenueStreams, systemHealth.cpu, systemHealth.memory, systemHealth.network]);

  const handleCreateStream = () => {
    const newStream = {
      id: 'stream_' + Date.now(),
      name: 'New Custom Stream',
      type: 'smart-contract',
      balance: Math.random() * 500,
      dailyChange: 0,
      status: 'active',
      contractAddress: '0x' + Math.random().toString(16).substr(2, 40),
    };
    setRevenueStreams((prev) => [...prev, newStream]);
    addActivity(`Created new revenue stream: ${newStream.name}`);
    addStreamModalRef.current?.hide();
  };

  const handleSendCollabMessage = (inputElId: string) => {
    const input = document.getElementById(inputElId) as HTMLInputElement;
    if (input && input.value) {
      addChatMessage('human', input.value);
      const userMessage = input.value;
      input.value = '';
      setTimeout(() => {
        const responses = [
            `Regarding "${userMessage}", I've analyzed your streams and suggest optimizing the smart contract royalties for better returns.`,
            `Interesting point. Based on current market trends for "${userMessage}", I recommend increasing your DeFi allocations by 15%.`,
            `I've detected an opportunity related to "${userMessage}" to bundle your AI services with smart contract deployments for increased revenue.`
        ];
        addChatMessage('ai', responses[Math.floor(Math.random() * responses.length)]);
      }, 1000);
    }
  };

  const handleTerminalExecute = () => {
    const input = document.getElementById('terminalInput') as HTMLInputElement;
    const command = input.value.trim();
    if (command) {
        addTerminalLine(`> ${command}`);
        input.value = '';
        if (command === 'help') {
            addTerminalLine('Available: status, deploy [contract], clear');
        } else if (command === 'status') {
            addTerminalLine(`System OK. Streams: ${stats.activeStreams}. Assets: $${stats.totalAssets.toFixed(2)}`);
        } else if (command.startsWith('deploy')) {
            addTerminalLine('Simulating contract deployment...');
            setTimeout(() => addTerminalLine(`Deployment successful. Address: 0x...${Math.random().toString(16).substr(-6)}`), 1500);
        } else {
            addTerminalLine(`Error: Command not found: ${command}`);
        }
    }
  }

  return (
    <div className="container-fluid py-4 h-full overflow-y-auto bg-gray-50">
       <div className="row mb-4">
            <div className="col-12">
                <div className="card p-3">
                    <div className="d-flex justify-content-between align-items-center">
                        <div>
                            <h1 className="mb-0 h5"><i className="bi bi-robot"></i> Autonomous Revenue & Collaboration Hub</h1>
                            <p className="text-muted mb-0 small">Complete Personal Revenue and AI-Human Collaboration System</p>
                        </div>
                        <div className="d-flex align-items-center">
                            <div className="me-3">
                                <span className="status-indicator status-active"></span>
                                <span id="systemStatus">Operational</span>
                            </div>
                            <div className="btn-group">
                                <button className="btn btn-sm btn-outline-secondary">Emergency Stop</button>
                                <button className="btn btn-sm btn-outline-primary" onClick={() => settingsModalRef.current?.show()}>
                                    <i className="bi bi-gear"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div className="row">
            <div className="col-md-3">
                 <div className="card mb-4">
                    <div className="card-header bg-primary text-white"><i className="bi bi-speedometer2"></i> Quick Stats</div>
                    <div className="card-body">
                        <p className="mb-1 small"><strong>Total Assets</strong></p>
                        <h5>${stats.totalAssets.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h5>
                        <p className="mb-1 small"><strong>Daily Revenue</strong></p>
                        <h5>${stats.dailyRevenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</h5>
                        <p className="mb-1 small"><strong>Active Streams</strong></p>
                        <h5>{stats.activeStreams}</h5>
                        <p className="mb-1 small"><strong>AI Collaborators</strong></p>
                        <h5>{stats.aiCollaborators}</h5>
                    </div>
                </div>
                <div className="card mb-4">
                    <div className="card-header bg-success text-white"><i className="bi bi-lightning"></i> Quick Actions</div>
                    <div className="card-body">
                        <button className="btn btn-primary w-100 mb-2 btn-sm"><i className="bi bi-cash-coin"></i> Request Payout</button>
                        <button className="btn btn-secondary w-100 mb-2 btn-sm" onClick={() => addStreamModalRef.current?.show()}><i className="bi bi-file-earmark-code"></i> New Contract</button>
                        <button className="btn btn-info w-100 mb-2 btn-sm text-white" onClick={() => aiCollabModalRef.current?.show()}><i className="bi bi-robot"></i> AI Collaboration</button>
                    </div>
                </div>
                 <div className="card">
                    <div className="card-header bg-dark text-white"><i className="bi bi-heart-pulse"></i> System Health</div>
                    <div className="card-body">
                        <p className="mb-1 small">CPU Usage</p>
                        <div className="progress mb-2" style={{height: '1rem'}}><div className="progress-bar" style={{ width: `${systemHealth.cpu}%` }}>{systemHealth.cpu.toFixed(0)}%</div></div>
                        <p className="mb-1 small">Memory Usage</p>
                        <div className="progress mb-2" style={{height: '1rem'}}><div className="progress-bar bg-success" style={{ width: `${systemHealth.memory}%` }}>{systemHealth.memory.toFixed(0)}%</div></div>
                        <p className="mb-1 small">Network Activity</p>
                        <div className="progress" style={{height: '1rem'}}><div className="progress-bar bg-info" style={{ width: `${systemHealth.network}%` }}>{systemHealth.network.toFixed(0)}%</div></div>
                    </div>
                </div>
            </div>

            <div className="col-md-6">
                <div className="card mb-4">
                    <div className="card-header d-flex justify-content-between align-items-center">
                        <h5 className="mb-0"><i className="bi bi-collection"></i> Active Revenue Streams</h5>
                        <button className="btn btn-sm btn-primary" onClick={() => addStreamModalRef.current?.show()}>+ Add</button>
                    </div>
                    <div className="card-body">
                        <div className="table-responsive">
                            <table className="table table-hover table-sm small">
                                <thead><tr><th>Name</th><th>Balance</th><th>24h</th><th>Status</th></tr></thead>
                                <tbody>
                                    {revenueStreams.map(stream => (
                                        <tr key={stream.id}>
                                            <td>{stream.name}</td>
                                            <td>${stream.balance.toFixed(2)}</td>
                                            <td className={stream.dailyChange >= 0 ? 'text-success' : 'text-danger'}>
                                                {stream.dailyChange >= 0 ? '+' : ''}{stream.dailyChange.toFixed(2)}
                                            </td>
                                            <td><span className={`badge bg-${stream.status === 'active' ? 'success' : 'warning'}`}>{stream.status}</span></td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div className="card mb-4">
                    <div className="card-header"><h5 className="mb-0"><i className="bi bi-people"></i> AI-Human Collaboration</h5></div>
                    <div className="card-body">
                        <div className="message-container" style={{height: '150px', overflowY: 'auto', marginBottom: '15px'}}>
                            {chat.map((msg, i) => (
                                <div key={i} className={`collaboration-message ${msg.sender}-message`}>
                                    <span className={`badge ${msg.sender}-badge`}>{msg.sender === 'ai' ? 'AI' : 'You'}</span>
                                    <p className="mb-0 small">{msg.text}</p>
                                </div>
                            ))}
                        </div>
                        <div className="input-group">
                            <input type="text" className="form-control form-control-sm" id="collabInputMain" placeholder="Ask AI..." />
                            <button className="btn btn-primary btn-sm" onClick={() => handleSendCollabMessage('collabInputMain')}><i className="bi bi-send"></i></button>
                        </div>
                    </div>
                </div>
            </div>

             <div className="col-md-3">
                <div className="card mb-4">
                    <div className="card-header bg-info text-white"><i className="bi bi-clock-history"></i> Recent Activity</div>
                    <div className="card-body small" style={{height: '250px', overflowY: 'auto'}}>
                        {activities.map(act => (
                            <div key={act.timestamp.toISOString()} className="mb-2">
                                <div className="small text-muted">{act.timestamp.toLocaleTimeString()}</div>
                                <div>{act.message}</div>
                            </div>
                        ))}
                    </div>
                </div>
                <div className="card">
                    <div className="card-header bg-dark text-white"><h5 className="mb-0"><i className="bi bi-terminal"></i> System Terminal</h5></div>
                    <div className="card-body p-2">
                        <div id="terminalOutput" className="small" style={{height: '150px'}}>
                           {terminalLog.map((line, i) => <div key={i}>{line}</div>)}
                        </div>
                        <div className="input-group mt-2">
                            <span className="input-group-text small">$</span>
                            <input type="text" className="form-control form-control-sm" id="terminalInput" placeholder="Enter command..." onKeyPress={e => e.key === 'Enter' && handleTerminalExecute()} />
                        </div>
                    </div>
                </div>
            </div>
        </div>

      {/* Modals */}
      <div className="modal fade" id="addStreamModal" tabIndex={-1}>
          <div className="modal-dialog modal-lg">
              <div className="modal-content">
                  <div className="modal-header">
                      <h5 className="modal-title">Add Revenue Stream</h5>
                      <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
                  </div>
                  <div className="modal-body">
                     <p>Select the type of revenue stream to create.</p>
                     {/* Simplified form for brevity */}
                     <div className="mb-3"><label className="form-label">Stream Name</label><input type="text" className="form-control" placeholder="My New DeFi Strategy" /></div>
                     <div className="mb-3">
                        <label className="form-label">Stream Type</label>
                        <select className="form-select">
                            <option>Smart Contract</option><option>Affiliate</option><option>DeFi</option><option>AI Service</option>
                        </select>
                     </div>
                  </div>
                  <div className="modal-footer">
                      <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                      <button type="button" className="btn btn-primary" onClick={handleCreateStream}>Create Stream</button>
                  </div>
              </div>
          </div>
      </div>
      <div className="modal fade" id="aiCollabModal" tabIndex={-1}>
          <div className="modal-dialog modal-lg">
              <div className="modal-content">
                  <div className="modal-header"><h5 className="modal-title">Advanced AI Collaboration</h5><button type="button" className="btn-close" data-bs-dismiss="modal"></button></div>
                  <div className="modal-body">
                      <div className="message-container" style={{height: '300px', overflowY: 'auto', marginBottom: '15px'}}>
                         {chat.map((msg, i) => (
                            <div key={i} className={`collaboration-message ${msg.sender}-message`}>
                                <span className={`badge ${msg.sender}-badge`}>{msg.sender === 'ai' ? 'AI Assistant' : 'You'}</span>
                                <p className="mb-0">{msg.text}</p>
                            </div>
                         ))}
                      </div>
                      <div className="input-group">
                          <input type="text" className="form-control" id="aiCollabInputModal" placeholder="Ask your AI assistant..." />
                          <button className="btn btn-primary" onClick={() => handleSendCollabMessage('aiCollabInputModal')}><i className="bi bi-send"></i></button>
                      </div>
                  </div>
              </div>
          </div>
      </div>
       <div className="modal fade" id="settingsModal" tabIndex={-1}>
          <div className="modal-dialog">
              <div className="modal-content">
                  <div className="modal-header"><h5 className="modal-title">System Settings</h5><button type="button" className="btn-close" data-bs-dismiss="modal"></button></div>
                  <div className="modal-body">
                    <p>Full settings panel would be here. This includes General, Security, Notifications, Integrations, and Advanced tabs.</p>
                    <div className="form-check form-switch">
                        <input className="form-check-input" type="checkbox" id="neuralNetIntegration" defaultChecked />
                        <label className="form-check-label" htmlFor="neuralNetIntegration">Neural Net Integration</label>
                    </div>
                    <div className="form-check form-switch">
                        <input className="form-check-input" type="checkbox" id="aetheriumCoreIntegration" defaultChecked />
                        <label className="form-check-label" htmlFor="aetheriumCoreIntegration">Aetherium Core Integration</label>
                    </div>
                  </div>
                  <div className="modal-footer">
                      <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      <button type="button" className="btn btn-primary">Save changes</button>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
};