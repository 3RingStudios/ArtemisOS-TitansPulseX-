/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useCallback, useEffect, useRef} from 'react';
import {AssembledPart, VehiclePart} from '../../../types';

interface VabCanvasProps {
  assembledParts: AssembledPart[];
}

const PART_VISUALS: Record<
  VehiclePart['type'],
  (ctx: CanvasRenderingContext2D, w: number, h: number) => void
> = {
  pod: (ctx, w, h) => {
    ctx.fillStyle = '#d1d5db';
    ctx.beginPath();
    ctx.moveTo(w * 0.25, h);
    ctx.lineTo(w * 0.75, h);
    ctx.lineTo(w, h * 0.5);
    ctx.bezierCurveTo(w, h * 0.2, w * 0.8, 0, w * 0.5, 0);
    ctx.bezierCurveTo(w * 0.2, 0, 0, h * 0.2, 0, h * 0.5);
    ctx.lineTo(w * 0.25, h);
    ctx.fill();
    ctx.stroke();
  },
  tank: (ctx, w, h) => {
    ctx.fillStyle = '#f3f4f6';
    ctx.fillRect(0, 0, w, h);
    ctx.strokeRect(0, 0, w, h);
  },
  engine: (ctx, w, h) => {
    ctx.fillStyle = '#4b5563';
    ctx.beginPath();
    ctx.moveTo(w * 0.2, 0);
    ctx.lineTo(w * 0.8, 0);
    ctx.lineTo(w, h * 0.3);
    ctx.lineTo(w * 0.6, h);
    ctx.lineTo(w * 0.4, h);
    ctx.lineTo(0, h * 0.3);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  },
  payload: (ctx, w, h) => {
    ctx.fillStyle = '#bfdbfe';
    ctx.beginPath();
    ctx.moveTo(w * 0.1, h);
    ctx.lineTo(w * 0.9, h);
    ctx.lineTo(w, h*0.1);
    ctx.lineTo(w*0.1, 0);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  },
  chassis: (ctx, w, h) => {
    ctx.fillStyle = '#6b7280';
    ctx.fillRect(0, 0, w, h);
    ctx.strokeRect(0, 0, w, h);
  },
  wheel: (ctx, w, h) => {
     ctx.fillStyle = '#1f2937';
     ctx.beginPath();
     ctx.arc(w/2, h/2, w/2, 0, Math.PI * 2);
     ctx.fill();
     ctx.strokeStyle = '#4b5563';
     ctx.stroke();
  },
  propeller: (ctx, w, h) => {
    ctx.fillStyle = '#9ca3af';
    ctx.beginPath();
    ctx.arc(w/2, h/2, w/2, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(w/2, h/2);
    ctx.lineTo(w/2, 0);
    ctx.moveTo(w/2, h/2);
    ctx.lineTo(w * 0.85, h * 0.85);
     ctx.moveTo(w/2, h/2);
    ctx.lineTo(w * 0.15, h * 0.85);
    ctx.stroke();
  },
  buoyancy: (ctx, w, h) => {
    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(0, 0, w, h);
    ctx.strokeRect(0, 0, w, h);
  },
  utility: (ctx, w, h) => {
    ctx.fillStyle = '#64748b';
    ctx.fillRect(0, 0, w, h);
    ctx.strokeRect(0, 0, w, h);
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, w / 4, 0, Math.PI * 2);
    ctx.strokeStyle = '#f1f5f9';
    ctx.stroke();
  },
};

export const VabCanvas: React.FC<VabCanvasProps> = ({assembledParts}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = '#1f2937';
    ctx.lineWidth = 2;

    const sortedParts = [...assembledParts].sort((a, b) => {
      // Sort by stage descending, then by type to get a sensible stack
      if (a.stage !== b.stage) return b.stage - a.stage;
      const typeOrder = { pod: 0, chassis: 1, payload: 2, tank: 3, utility: 4, buoyancy: 5, engine: 6, propeller: 7, wheel: 8 };
      return typeOrder[a.part.type] - typeOrder[b.part.type];
    });

    let currentY = canvas.height - 20; // Start from bottom
    const partWidth = 60;

    sortedParts.forEach(({part}) => {
      let partHeight = 40; // Default height
      if (part.type === 'tank') partHeight = part.fuel! * 15;
      else if (part.type === 'chassis') partHeight = 20;
      else if (part.type === 'utility') partHeight = 15;

      currentY -= partHeight;

      ctx.save();
      ctx.translate(canvas.width / 2 - partWidth / 2, currentY);
      const drawFunc = PART_VISUALS[part.type];
      if (drawFunc) {
        drawFunc(ctx, partWidth, partHeight);
      }
      ctx.restore();
      currentY -= 5; // spacing
    });
  }, [assembledParts]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let animationFrameId: number;
    const resizeObserver = new ResizeObserver(() => {
      // Defer resize handling to the next animation frame to avoid loop errors.
      animationFrameId = window.requestAnimationFrame(() => {
        if (canvas) {
          canvas.width = canvas.clientWidth;
          canvas.height = canvas.clientHeight;
          draw();
        }
      });
    });
    
    resizeObserver.observe(canvas);

    // Set initial size and draw
    canvas.width = canvas.clientWidth;
    canvas.height = canvas.clientHeight;
    draw();

    return () => {
      resizeObserver.disconnect();
      window.cancelAnimationFrame(animationFrameId);
    };
  }, [draw]);

  return <canvas ref={canvasRef} className="vab-canvas"></canvas>;
};