/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { LogEntry, NativeAppComponentProps } from '../../types';

const SystemLog: React.FC<Partial<NativeAppComponentProps>> = ({ systemLog = [] }) => {
  return (
    <div className="h-full bg-gray-900 text-gray-300 font-mono text-sm p-4 flex flex-col">
      <h2 className="text-lg text-cyan-300 mb-4 border-b border-gray-700 pb-2">System Activity Log</h2>
      <div className="flex-grow overflow-y-auto pr-2">
        {systemLog.length > 0 ? (
          systemLog.map((log) => (
            <div key={log.id} className="flex items-start gap-3 mb-2 animate-fade-in">
              <span className="text-gray-500">{new Date(log.timestamp).toLocaleTimeString()}</span>
              <span className="text-cyan-400 font-bold w-32 flex-shrink-0 text-right">[{log.source}]</span>
              <span className="flex-grow whitespace-pre-wrap">
                {log.icon} {log.message}
              </span>
            </div>
          ))
        ) : (
          <p className="text-gray-500 text-center py-8">No system events logged yet.</p>
        )}
      </div>
    </div>
  );
};

export { SystemLog };