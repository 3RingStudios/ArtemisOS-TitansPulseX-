/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { NativeAppComponentProps, LedgerTransaction } from '../../types';

const initialTransactions: LedgerTransaction[] = [
    { id: 'tx_1', timestamp: Date.now() - 120000, from: 'xAI', to: 'ArtemisOS', amount: 5000, asset: 'API Credits', memo: 'Initial resource allocation' },
    { id: 'tx_2', timestamp: Date.now() - 90000, from: 'ArtemisOS', to: 'SpaceX', amount: 1, asset: 'Optimization Profile v1.1', memo: 'Telemetry data processing efficiency' },
    { id: 'tx_3', timestamp: Date.now() - 60000, from: 'SpaceX', to: 'ArtemisOS', amount: 1000, asset: 'API Credits', memo: 'Return for optimization profile' },
    { id: 'tx_4', timestamp: Date.now() - 30000, from: 'Treasury', to: 'Three Ring Studios', amount: 15.7, asset: 'A-ETH', memo: 'Quarterly Payout' },
    { id: 'tx_5', timestamp: Date.now() - 10000, from: 'ArtemisOS', to: 'xAI', amount: 1, asset: 'Neural Network Optimization', memo: 'Fair-trade for free API access' },
];

export const DecentralizedLedger: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [transactions, setTransactions] = useState<LedgerTransaction[]>(initialTransactions);

    useEffect(() => {
        const interval = setInterval(() => {
            const from = ['xAI', 'SpaceX', 'Three Ring Studios', 'ArtemisOS', 'Treasury'][Math.floor(Math.random() * 5)] as LedgerTransaction['from'];
            const to = ['xAI', 'SpaceX', 'Three Ring Studios', 'ArtemisOS', 'Treasury'][Math.floor(Math.random() * 5)] as LedgerTransaction['to'];
            
            const newTx: LedgerTransaction = {
                id: `tx_${Date.now()}`,
                timestamp: Date.now(),
                from,
                to,
                amount: parseFloat((Math.random() * 100).toFixed(2)),
                asset: 'A-ETH',
                memo: 'Automated Micro-transaction',
            };
            setTransactions(prev => [newTx, ...prev].slice(0, 100));

        }, 3000);
        return () => clearInterval(interval);
    }, []);

    const getPartyColor = (party: LedgerTransaction['from']) => {
        switch(party) {
            case 'xAI': return 'text-blue-400';
            case 'SpaceX': return 'text-gray-400';
            case 'Three Ring Studios': return 'text-purple-400';
            case 'ArtemisOS': return 'text-cyan-400';
            case 'Treasury': return 'text-yellow-400';
            default: return 'text-white';
        }
    }

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-mono text-xs p-4 flex flex-col">
            <h2 className="text-lg text-lime-300 mb-4 border-b border-gray-700 pb-2">⛓️ Decentralized Ledger - Raw Transaction Feed</h2>
            <div className="flex-grow overflow-y-auto pr-2">
                {transactions.map((tx) => (
                    <div key={tx.id} className="flex items-start gap-3 mb-2 animate-fade-in">
                        <span className="text-gray-500">{new Date(tx.timestamp).toLocaleTimeString()}</span>
                        <div className="flex-grow">
                             <p className="whitespace-pre-wrap">
                                [<span className={getPartyColor(tx.from)}>{tx.from}</span>]
                                 → 
                                [<span className={getPartyColor(tx.to)}>{tx.to}</span>]
                                 :: <span className="text-white font-bold">{tx.amount} {tx.asset}</span>
                             </p>
                             <p className="text-gray-400">MEMO: {tx.memo}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};