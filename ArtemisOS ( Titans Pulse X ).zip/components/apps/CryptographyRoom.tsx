/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { NativeAppComponentProps, HolographicObject } from '../../types';

class Star {
    x: number;
    y: number;
    z: number;
    x_prev: number;
    y_prev: number;
    
    constructor(width: number, height: number) {
        this.x = Math.random() * width - width / 2;
        this.y = Math.random() * height - height / 2;
        this.z = Math.random() * 400;
        this.x_prev = this.x;
        this.y_prev = this.y;
    }

    update(width: number, height: number, speed: number, spiral: number) {
        this.z -= speed;
        if (this.z < 1) {
            this.z = 400;
            this.x = Math.random() * width - width / 2;
            this.y = Math.random() * height - height / 2;
            this.x_prev = this.x;
            this.y_prev = this.y;
        }

        // Apply spiral motion based on harmonic balance
        if (spiral !== 0) {
            const angle = spiral * (400 / this.z) * 0.001; // reduced multiplier for subtlety
            const newX = this.x * Math.cos(angle) - this.y * Math.sin(angle);
            const newY = this.x * Math.sin(angle) + this.y * Math.cos(angle);
            this.x = newX;
            this.y = newY;
        }
    }

    draw(ctx: CanvasRenderingContext2D, width: number, height: number) {
        const k = 128 / this.z;
        const px = this.x * k + width / 2;
        const py = this.y * k + height / 2;

        if (px > 0 && px < width && py > 0 && py < height) {
            const size = (1 - this.z / 400) * 4;
            ctx.fillStyle = `rgba(200, 220, 255, ${1 - this.z/400})`;
            ctx.beginPath();
            ctx.arc(px, py, size/2, 0, Math.PI * 2);
            ctx.fill();
        }
    }
}

export const CryptographyRoom: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [harmonicBalance, setHarmonicBalance] = useState(0); // -10 (364) to 10 (369)
    const [speed, setSpeed] = useState(2);
    
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let stars = Array.from({ length: 1000 }, () => new Star(canvas.width, canvas.height));
        let animationId: number;
        let resizeAnimationId: number;

        const animate = () => {
            const { width, height } = canvas;
            ctx.fillStyle = 'rgba(0, 0, 0, 0.2)'; // Fading trail effect
            ctx.fillRect(0, 0, width, height);
            
            // God Ray effect from top center, influenced by imbalance
            const godRayIntensity = 0.1 + Math.abs(harmonicBalance) * 0.015;
            const gradient = ctx.createRadialGradient(width / 2, height / 2 - (harmonicBalance * 10), 0, width / 2, height / 2, height);
            gradient.addColorStop(0, `rgba(100, 150, 255, ${godRayIntensity})`);
            gradient.addColorStop(1, 'rgba(100, 150, 255, 0)');
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, width, height);

            stars.forEach(star => {
                star.update(width, height, speed, harmonicBalance);
                star.draw(ctx, width, height);
            });
            animationId = requestAnimationFrame(animate);
        };

        const resizeObserver = new ResizeObserver(() => {
            resizeAnimationId = window.requestAnimationFrame(() => {
                if (canvas) {
                    canvas.width = canvas.clientWidth;
                    canvas.height = canvas.clientHeight;
                    stars = Array.from({ length: 1000 }, () => new Star(canvas.width, canvas.height));
                }
            });
        });
        
        // Initial setup
        canvas.width = canvas.clientWidth;
        canvas.height = canvas.clientHeight;
        stars = Array.from({ length: 1000 }, () => new Star(canvas.width, canvas.height));
        
        resizeObserver.observe(canvas);
        animate();

        return () => {
            cancelAnimationFrame(animationId);
            cancelAnimationFrame(resizeAnimationId);
            resizeObserver.disconnect();
        }
    }, [speed, harmonicBalance]);

    return (
        <div className="h-full bg-black text-gray-300 font-sans flex flex-col">
            <div className="absolute top-0 left-0 right-0 p-4 z-10 bg-gradient-to-b from-black/80 to-transparent">
                <h2 className="text-xl text-purple-300 font-bold">🌌 Cryptography Room</h2>
                <p className="text-sm text-gray-400">Visualizing the Fabric of the Universe. Manipulate harmonics to observe reality.</p>
            </div>
            <canvas ref={canvasRef} className="w-full h-full" />
            <div className="absolute bottom-0 left-0 right-0 p-4 z-10 bg-gradient-to-t from-black/80 to-transparent flex items-center justify-center gap-6">
                <div className="w-64">
                    <label className="text-xs font-bold text-gray-400">Harmonic Balance (As Above/Below)</label>
                    <input 
                        type="range" min="-10" max="10" 
                        value={harmonicBalance}
                        onChange={e => setHarmonicBalance(Number(e.target.value))}
                        className="w-full" />
                    <div className="flex justify-between text-xs">
                        <span className={harmonicBalance <= 0 ? 'text-cyan-400' : ''}>364 (Balance)</span>
                        <span className={harmonicBalance >= 0 ? 'text-red-400' : ''}>369 (Imbalance)</span>
                    </div>
                </div>
                 <div className="w-64">
                    <label className="text-xs font-bold text-gray-400">Warp Speed</label>
                    <input 
                        type="range" min="0.5" max="20" step="0.5" 
                        value={speed}
                        onChange={e => setSpeed(Number(e.target.value))}
                        className="w-full" />
                </div>
            </div>
        </div>
    );
};