/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useRef, useEffect } from 'react';
import { NativeAppComponentProps } from '../../types';

export const OrbitalCybersecurityMonitor: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        
        const particles: {x: number, y: number, vx: number, vy: number, life: number}[] = [];

        const animate = () => {
            const { width, height } = canvas;
            ctx.clearRect(0, 0, width, height);

            if (Math.random() > 0.9) {
                particles.push({x: Math.random() * width, y: 0, vx: Math.random() * 2 - 1, vy: 2, life: 1});
            }
            
            // Shield
            const shieldY = height * 0.8;
            ctx.strokeStyle = '#3b82f6';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(0, shieldY);
            ctx.quadraticCurveTo(width/2, shieldY - 50, width, shieldY);
            ctx.stroke();

            particles.forEach(p => {
                p.y += p.vy;
                p.x += p.vx;
                p.life -= 0.01;

                if (p.y > shieldY - 5 && p.y < shieldY + 5) {
                    p.y = shieldY;
                    p.vy = -2;
                }

                ctx.fillStyle = `rgba(239, 68, 68, ${p.life})`;
                ctx.fillRect(p.x, p.y, 3, 3);
            });

            requestAnimationFrame(animate);
        };
        
        const animId = requestAnimationFrame(animate);
        return () => cancelAnimationFrame(animId);
    }, []);

    return (
        <div className="h-full bg-black text-white">
            <h2 className="text-xl font-bold p-4 text-red-400">🛡️ Orbital Cybersecurity Monitor</h2>
            <canvas ref={canvasRef} className="w-full h-[calc(100%-4rem)]" />
        </div>
    );
};