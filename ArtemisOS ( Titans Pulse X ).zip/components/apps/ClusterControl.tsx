/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useEffect, useMemo, useState} from 'react';
import {NativeAppComponentProps} from '../../types';

interface ClusterNode {
  id: string;
  name: string;
  ip: string;
  arch: 'ARM64' | 'Arch64' | 'x86_64' | 'Apple Silicon';
  status: 'Online' | 'Offline' | 'Stressed';
  task: string;
  signal: number; // LoRaWAN signal strength in dBm
  cpu: number;
  ram: number;
}

type Tab = 'status' | 'orchestration' | 'projection';

const initialNodes: ClusterNode[] = [
  {id: 'host-pc', name: 'Operator PC', ip: '192.168.1.100', arch: 'x86_64', status: 'Online', task: 'OS Host', signal: -45, cpu: 15, ram: 25},
  {id: 'ipad-pro', name: 'iPad Pro', ip: '192.168.1.150', arch: 'Apple Silicon', status: 'Online', task: 'Idle', signal: -55, cpu: 5, ram: 15},
  {id: 'pi-01', name: 'Raspberry Pi 4B', ip: '192.168.1.101', arch: 'ARM64', status: 'Online', task: 'Idle', signal: -65, cpu: 10, ram: 25},
  {id: 'pi-02', name: 'Raspberry Pi 4B', ip: '192.168.1.102', arch: 'ARM64', status: 'Online', task: 'Idle', signal: -72, cpu: 12, ram: 30},
  {id: 'pi-03', name: 'Raspberry Pi 4B', ip: '192.168.1.103', arch: 'ARM64', status: 'Online', task: 'Simulating Trajectory', signal: -68, cpu: 75, ram: 60},
  {id: 'pi-04', name: 'Raspberry Pi 4B', ip: '192.168.1.104', arch: 'ARM64', status: 'Online', task: 'Idle', signal: -80, cpu: 8, ram: 22},
  {id: 'pi-05', name: 'Raspberry Pi 4B', ip: '192.168.1.105', arch: 'ARM64', status: 'Offline', task: 'N/A', signal: 0, cpu: 0, ram: 0},
  {id: 'pi-06', name: 'Raspberry Pi 4B', ip: '192.168.1.106', arch: 'ARM64', status: 'Online', task: 'Compiling Shaders', signal: -75, cpu: 88, ram: 75},
  {id: 'bobcat-01', name: 'Bobcat 300', ip: '192.168.1.201', arch: 'ARM64', status: 'Online', task: 'Idle', signal: -60, cpu: 15, ram: 40},
  {id: 'bobcat-02', name: 'Bobcat 300', ip: '192.168.1.202', arch: 'ARM64', status: 'Stressed', task: 'AI Model Inference', signal: -63, cpu: 95, ram: 90},
  {id: 'rak-miner', name: 'RAK Miner v2', ip: '192.168.1.210', arch: 'Arch64', status: 'Online', task: 'Network Gateway', signal: -55, cpu: 20, ram: 35},
];

const tasks = ['Idle', 'Simulating Trajectory', 'Compiling Shaders', 'AI Model Inference', 'Data Synchronization', 'Rendering Frame', 'Learning from Dataset'];

const StatusIndicator: React.FC<{status: ClusterNode['status']}> = ({status}) => {
  const color = {
    Online: 'bg-green-500',
    Offline: 'bg-red-500',
    Stressed: 'bg-yellow-500',
  }[status];
  return (
    <span className={`inline-block w-3 h-3 rounded-full ${color} ring-2 ring-offset-2 ring-offset-gray-800`}></span>
  );
};

const NodeStatusView: React.FC<{nodes: ClusterNode[]}> = ({nodes}) => (
    <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
        <thead className="bg-gray-700 text-xs text-gray-300 uppercase">
            <tr>
            <th scope="col" className="px-4 py-3">Status</th>
            <th scope="col" className="px-4 py-3">Node Name</th>
            <th scope="col" className="px-4 py-3">Arch</th>
            <th scope="col" className="px-4 py-3">Task</th>
            <th scope="col" className="px-4 py-3">CPU/RAM</th>
            <th scope="col" className="px-4 py-3">LoRa Signal</th>
            </tr>
        </thead>
        <tbody className="divide-y divide-gray-700">
            {nodes.map((node) => (
            <tr key={node.id} className="hover:bg-gray-700/50">
                <td className="px-4 py-3"><StatusIndicator status={node.status} /></td>
                <td className="px-4 py-3 font-medium text-white">{node.name}</td>
                <td className="px-4 py-3">{node.arch}</td>
                <td className="px-4 py-3 font-mono text-xs">{node.task}</td>
                <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                        <div className="w-16 bg-gray-600 rounded-full h-2.5">
                        <div className="bg-blue-500 h-2.5 rounded-full" style={{width: `${node.cpu}%`}}></div>
                        </div>
                        <span>{node.cpu.toFixed(0)}%</span>
                    </div>
                </td>
                <td className="px-4 py-3">{node.status === 'Offline' ? 'N/A' : `${node.signal.toFixed(1)} dBm`}</td>
            </tr>
            ))}
        </tbody>
        </table>
    </div>
);

const OrchestrationView: React.FC<{nodes: ClusterNode[]}> = ({nodes}) => {
    const onlineNodes = nodes.filter(node => node.status !== 'Offline');
    const architectureGroups = onlineNodes.reduce((acc, node) => {
        if (!acc[node.arch]) acc[node.arch] = [];
        acc[node.arch].push(node);
        return acc;
    }, {} as Record<string, ClusterNode[]>);

    return (
        <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(architectureGroups).map(([arch, archNodes]) => (
                <div key={arch} className="bg-gray-800/50 p-4 rounded-lg">
                    <h4 className="font-bold text-lg text-cyan-400 mb-2">{arch} ({archNodes.length} nodes)</h4>
                    <ul className="space-y-2 text-sm">
                        {archNodes.map(node => (
                           <li key={node.id}>
                               <strong>{node.name}:</strong> <span className="text-yellow-300 font-mono text-xs">{node.task}</span>
                           </li>
                        ))}
                    </ul>
                </div>
            ))}
        </div>
    );
};

const DesktopProjectionView: React.FC<{nodes: ClusterNode[]}> = ({nodes}) => (
    <div className="p-4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {nodes.map(node => (
            <div key={node.id} className={`p-2 rounded-lg border-2 ${node.status === 'Online' ? 'border-green-500/50' : 'border-red-500/50'} bg-black`}>
                <p className="text-xs font-bold text-white mb-1 truncate">{node.name}</p>
                 <div className="aspect-video bg-gray-900 rounded flex items-center justify-center text-gray-500 font-mono text-xs">
                    {node.status === 'Online' ? `[VNC] ${node.ip}` : '[No Signal]'}
                </div>
            </div>
        ))}
    </div>
);


export const ClusterControl: React.FC<Partial<NativeAppComponentProps>> = () => {
  const [nodes, setNodes] = useState<ClusterNode[]>(initialNodes);
  const [activeTab, setActiveTab] = useState<Tab>('status');

  useEffect(() => {
    const interval = setInterval(() => {
      setNodes((currentNodes) =>
        currentNodes.map((node) => {
          if (node.status === 'Offline') return node;

          let newCpu = node.cpu + (Math.random() * 10 - 5);
          newCpu = Math.max(5, Math.min(98, newCpu));

          let newRam = node.ram + (Math.random() * 8 - 4);
          newRam = Math.max(10, Math.min(95, newRam));

          let newStatus: ClusterNode['status'] = 'Online';
          if (newCpu > 90 || newRam > 85) {
            newStatus = 'Stressed';
          }

          const newSignal = node.signal + (Math.random() * 2 - 1);

          const shouldChangeTask =
            node.task === 'Idle' && Math.random() < 0.05;
          const newTask = shouldChangeTask
            ? tasks[Math.floor(Math.random() * tasks.length)]
            : node.task;

          return {
            ...node,
            cpu: newCpu,
            ram: newRam,
            status: newStatus,
            signal: newSignal,
            task: newTask,
          };
        }),
      );
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const onlineNodes = useMemo(
    () => nodes.filter((n) => n.status !== 'Offline').length,
    [nodes],
  );
  const totalCpu = useMemo(
    () => nodes.reduce((sum, n) => sum + n.cpu, 0) / onlineNodes || 0,
    [nodes, onlineNodes],
  );

  const renderContent = () => {
    switch(activeTab) {
        case 'orchestration': return <OrchestrationView nodes={nodes} />;
        case 'projection': return <DesktopProjectionView nodes={nodes} />;
        case 'status':
        default:
            return <NodeStatusView nodes={nodes} />
    }
  }

  const TabButton: React.FC<{ label: string; tab: Tab }> = ({ label, tab }) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={`px-4 py-2 text-sm font-medium transition-colors rounded-t-lg border-b-2 ${
        activeTab === tab ? 'border-cyan-400 text-white' : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-500'
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col">
      <div className="flex-shrink-0 mb-4 pb-2 border-b border-gray-700">
        <h2 className="text-xl text-cyan-300 font-bold">🌐 Cluster Control</h2>
        <p className="text-sm text-gray-400">
          Manage and monitor the distributed ArtemisOS node network.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 flex-shrink-0">
        <div className="bg-gray-800 p-4 rounded-lg">
          <h3 className="text-gray-400 text-sm font-bold">Nodes Online</h3>
          <p className="text-2xl font-semibold text-green-400">
            {onlineNodes} <span className="text-lg">/ {nodes.length}</span>
          </p>
        </div>
        <div className="bg-gray-800 p-4 rounded-lg">
          <h3 className="text-gray-400 text-sm font-bold">Avg. Cluster Load</h3>
          <p className="text-2xl font-semibold text-yellow-400">
            {totalCpu.toFixed(1)}%
          </p>
        </div>
        <div className="bg-gray-800 p-4 rounded-lg">
          <h3 className="text-gray-400 text-sm font-bold">Network Type</h3>
          <p className="text-2xl font-semibold text-blue-400">LoRaWAN Mesh</p>
        </div>
      </div>

       <div className="border-b border-gray-700">
          <nav className="-mb-px flex space-x-4" aria-label="Tabs">
            <TabButton label="Node Status" tab="status" />
            <TabButton label="Hybrid Core Orchestration" tab="orchestration" />
            <TabButton label="Desktop Projection" tab="projection" />
          </nav>
        </div>

      <div className="flex-grow bg-gray-800 rounded-b-lg overflow-y-auto">
        {renderContent()}
      </div>
    </div>
  );
};
