/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { systemBus } from '../../services/systemBus';
import { playSound, SoundType } from '../../services/audioService';

export const EvolutionaryVault = () => {
    
    const handleEvolve = () => {
        playSound(SoundType.TRANSITION);
        // We emit a command that the App.tsx will catch.
        // It knows how to handle interactions for this specific app.
        systemBus.emit('execute_command', {
            command: 'evolve_theory'
        });
    };

    return (
        <div className="h-full bg-gray-800 text-gray-200 p-6 flex flex-col items-center justify-center text-center">
            <h2 className="text-3xl font-bold text-green-300 mb-2">🧬 Evolutionary Vault</h2>
            <p className="text-gray-400 mb-8 max-w-md">Synthesize novel technologies by combining cutting-edge scientific discoveries from the global network.</p>
            
            <button
                onClick={handleEvolve}
                className="px-8 py-4 bg-green-600 text-white font-bold rounded-lg text-lg shadow-lg hover:bg-green-500 transform hover:scale-105 transition-all"
            >
                Evolve New Theory
            </button>
            
            <p className="text-xs text-gray-500 mt-6">
                Warning: Evolving a new theory will consume significant system resources and may produce unpredictable results.
            </p>
        </div>
    );
};
