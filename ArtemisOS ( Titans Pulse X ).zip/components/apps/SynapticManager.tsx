/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useMemo, useEffect } from 'react';
import { NativeAppComponentProps, SynapticPackage } from '../../types';
import { systemBus } from '../../services/systemBus';
import { playSound, SoundType } from '../../services/audioService';

const ALL_PACKAGES: SynapticPackage[] = [
    { id: 'tf-lite', name: 'TensorFlow-Lite', version: '2.10.0', description: 'ML framework for on-device inference.', category: 'AI/ML', isInstalled: true },
    { id: 'pytorch-mobile', name: 'PyTorch-Mobile', version: '1.13.0', description: 'End-to-end workflow from Python to mobile deployment.', category: 'AI/ML', isInstalled: false },
    { id: 'opencv', name: 'OpenCV', version: '4.7.0', description: 'Open Source Computer Vision Library.', category: 'AI/ML', isInstalled: false },
    { id: 'librosa', name: 'Librosa', version: '0.9.2', description: 'Python package for music and audio analysis.', category: 'AI/ML', isInstalled: false },
    { id: 'three-js', name: 'Three.js', version: 'r148', description: 'Cross-browser 3D graphics library and API.', category: 'Graphics', isInstalled: true },
    { id: 'opengl-es', name: 'OpenGL ES', version: '3.2', description: 'Embedded-system subset of OpenGL.', category: 'Graphics', isInstalled: true },
    { id: 'vulkan-sdk', name: 'Vulkan SDK', version: '1.3.239.0', description: 'New generation graphics and compute API.', category: 'Graphics', isInstalled: false },
    { id: 'chirpstack', name: 'ChirpStack', version: '4.0', description: 'Open-source LoRaWAN Network Server stack.', category: 'Networking', isInstalled: true },
    { id: 'ipfs-kubo', name: 'IPFS Kubo', version: '0.18.1', description: 'Go implementation of the InterPlanetary File System.', category: 'Networking', isInstalled: false },
    { id: 'k3s', name: 'K3s', version: '1.25.6', description: 'Lightweight Kubernetes distribution.', category: 'System', isInstalled: true },
    { id: 'docker-ce', name: 'Docker CE', version: '20.10', description: 'Containerization platform.', category: 'System', isInstalled: false },
    { id: 'geth', name: 'Go-Ethereum', version: '1.10.26', description: 'Official Go implementation of the Ethereum protocol.', category: 'System', isInstalled: false },
    { id: 'eos-sdk', name: 'Epic Online Services SDK', version: '1.15.5', description: 'Services for cross-platform games.', category: 'Development', isInstalled: false },
    { id: 'unity-services', name: 'Unity Services SDK', version: '1.8.1', description: 'SDK for Unity game services.', category: 'Development', isInstalled: false },
    { id: 'rustc', name: 'Rust Compiler', version: '1.67.0', description: 'The compiler for the Rust programming language.', category: 'Development', isInstalled: true },
];

export const SynapticManager: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [packages, setPackages] = useState<SynapticPackage[]>(ALL_PACKAGES);
    const [searchTerm, setSearchTerm] = useState('');
    const [installLog, setInstallLog] = useState<string[]>(['Synaptic Package Manager Initialized.']);

    const filteredPackages = useMemo(() => {
        return packages.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
    }, [packages, searchTerm]);

    const addLog = (message: string) => {
        systemBus.emit('log_system_event', {
            message,
            icon: '📦',
            source: 'Synaptic',
        });
        setInstallLog(prev => [message, ...prev].slice(0, 100));
    };

    const handleInstall = (pkgId: string) => {
        const pkg = packages.find(p => p.id === pkgId);
        if (!pkg) return;

        playSound(SoundType.CLICK);
        addLog(`Starting installation of ${pkg.name}...`);
        
        setTimeout(() => addLog(`Reading package lists... Done`), 500);
        setTimeout(() => addLog(`Unpacking ${pkg.name} (${pkg.version})...`), 1000);
        setTimeout(() => {
            addLog(`Setting up ${pkg.name}...`);
            setPackages(prev => prev.map(p => p.id === pkgId ? { ...p, isInstalled: true } : p));
        }, 2000);
        setTimeout(() => {
            addLog(`Successfully installed ${pkg.name}.`);
            playSound(SoundType.TRANSITION);
        }, 2500);
    };

    return (
        <div className="h-full bg-gray-800 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0 pb-2 border-b border-gray-600">
                <h2 className="text-xl text-yellow-300 font-bold">Synaptic Package Manager</h2>
                <p className="text-sm text-gray-400">Dynamically install and manage system libraries and dependencies.</p>
            </div>
            <div className="flex-grow flex gap-4 overflow-hidden">
                <div className="w-2/3 flex flex-col">
                    <input
                        type="text"
                        placeholder="Search for packages..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        className="w-full p-2 mb-4 rounded-md bg-gray-900 border border-gray-600 focus:border-yellow-400 outline-none"
                    />
                    <div className="flex-grow overflow-y-auto pr-2">
                        <table className="w-full text-sm text-left">
                            <thead className="text-xs text-gray-400 uppercase bg-gray-700">
                                <tr>
                                    <th className="px-4 py-2">Package</th>
                                    <th className="px-4 py-2">Description</th>
                                    <th className="px-4 py-2">Action</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-700">
                                {filteredPackages.map(pkg => (
                                    <tr key={pkg.id} className="hover:bg-gray-700/50">
                                        <td className="px-4 py-2 font-semibold text-white">{pkg.name}</td>
                                        <td className="px-4 py-2">{pkg.description}</td>
                                        <td className="px-4 py-2">
                                            {pkg.isInstalled ? (
                                                <span className="text-green-400 font-bold">Installed</span>
                                            ) : (
                                                <button onClick={() => handleInstall(pkg.id)} className="px-3 py-1 bg-blue-600 hover:bg-blue-700 rounded text-xs text-white">
                                                    Install
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
                <div className="w-1/3 bg-black rounded-lg p-2 flex flex-col">
                    <h3 className="text-sm font-semibold text-green-300 mb-2 p-2 border-b border-gray-700">Installation Log</h3>
                    <div className="flex-grow overflow-y-auto font-mono text-xs text-green-400 space-y-1">
                        {installLog.map((log, i) => <p key={i}>{log}</p>)}
                    </div>
                </div>
            </div>
        </div>
    );
};
