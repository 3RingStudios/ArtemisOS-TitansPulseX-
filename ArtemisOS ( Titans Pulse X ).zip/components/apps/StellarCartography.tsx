/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useCallback, useEffect, useRef, useState} from 'react';
import { NativeAppComponentProps } from '../../types';

interface CelestialBody {
  id: string;
  name: string;
  type: 'Star' | 'Planet' | 'Moon';
  radius: number;
  color: string;
  orbitRadius: number;
  speed: number;
  angle: number;
  x: number;
  y: number;
  parentId?: string;
  moons?: CelestialBody[];
  // Kerbal-style info
  mass: string;
  gravity: string;
  description: string;
}

const KSP_NAMES = {
  first: ['Ker', 'Mun', 'Min', 'Eve', 'Mo', 'Jeb', 'Val', 'Dun', 'Dres'],
  second: ['bal', 'mus', 'ho', 'a', 'ia', 'us', 'na', 'lar', 'ik'],
  third: [' I', ' II', ' III', ' IV', ' V', ' Prime', ' Alpha', ' Beta', ''],
};

const generateName = () => {
  const f = KSP_NAMES.first[Math.floor(Math.random() * KSP_NAMES.first.length)];
  const s = KSP_NAMES.second[Math.floor(Math.random() * KSP_NAMES.second.length)];
  const t = KSP_NAMES.third[Math.floor(Math.random() * KSP_NAMES.third.length)];
  return f + s + t;
};

// Procedurally generates a new star system
const generateStarSystem = (): CelestialBody[] => {
  const bodies: CelestialBody[] = [];
  const starName = generateName();
  const star: CelestialBody = {
    id: starName,
    name: starName,
    type: 'Star',
    radius: 20 + Math.random() * 10,
    color: `hsl(${20 + Math.random() * 40}, 90%, 60%)`, // Yellow-orange range
    orbitRadius: 0,
    speed: 0,
    angle: 0,
    x: 0,
    y: 0,
    mass: `${(1.5 + Math.random()).toFixed(2)}e30 kg`,
    gravity: '274 m/s²',
    description: 'A vibrant main-sequence star, center of this system.',
  };
  bodies.push(star);

  const numPlanets = 3 + Math.floor(Math.random() * 4);
  let lastOrbit = star.radius + 60 + Math.random() * 20;

  for (let i = 0; i < numPlanets; i++) {
    const planetRadius = 4 + Math.random() * 8;
    const orbitRadius = lastOrbit + 40 + Math.random() * 80;
    lastOrbit = orbitRadius;
    const planetName = generateName();

    const planet: CelestialBody = {
      id: planetName,
      name: planetName,
      type: 'Planet',
      parentId: star.id,
      radius: planetRadius,
      color: `hsl(${Math.random() * 360}, 70%, 60%)`,
      orbitRadius,
      speed: 0.005 / Math.sqrt(orbitRadius / 100),
      angle: Math.random() * 2 * Math.PI,
      x: 0,
      y: 0,
      mass: `${(Math.random() * 10).toExponential(2)} kg`,
      gravity: `${(Math.random() * 15 + 3).toFixed(1)} m/s²`,
      description: 'A newly discovered celestial body orbiting ' + star.name,
    };
    bodies.push(planet);

    // Add moons
    const numMoons = Math.random() > 0.5 ? Math.floor(Math.random() * 3) + 1 : 0;
    let lastMoonOrbit = planetRadius + 10;
    for (let j = 0; j < numMoons; j++) {
      const moonOrbit = lastMoonOrbit + 5 + Math.random() * 5;
      lastMoonOrbit = moonOrbit;
      const moonName = generateName();

      const moon: CelestialBody = {
        id: moonName,
        name: moonName,
        type: 'Moon',
        parentId: planet.id,
        radius: 1 + Math.random() * 2,
        color: '#a1a1aa',
        orbitRadius: moonOrbit,
        speed:
          (0.05 / Math.sqrt(moonOrbit / 10)) * (Math.random() > 0.5 ? 1 : -1),
        angle: Math.random() * 2 * Math.PI,
        x: 0,
        y: 0,
        mass: `${(Math.random() * 1).toExponential(2)} kg`,
        gravity: `${(Math.random() * 2 + 0.5).toFixed(1)} m/s²`,
        description: 'A small natural satellite of ' + planet.name,
      };
      bodies.push(moon);
    }
  }
  return bodies;
};

export const StellarCartography: React.FC<Partial<NativeAppComponentProps>> = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [initialSystem] = useState(generateStarSystem);
  const bodiesRef = useRef<CelestialBody[]>(initialSystem);
  const [selectedBody, setSelectedBody] = useState<CelestialBody | null>(bodiesRef.current[0]);
  const animationFrameIdRef = useRef<number | null>(null);
  const starfieldRef = useRef<{x: number; y: number; r: number}[]>([]);

  const update = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    const updatedPositions = new Map<string, {x: number; y: number}>();
    updatedPositions.set('center', {x: centerX, y: centerY});

    bodiesRef.current.forEach((body) => {
      let parentX = centerX;
      let parentY = centerY;

      if (body.parentId) {
        const parentPos = updatedPositions.get(body.parentId);
        if (parentPos) {
          parentX = parentPos.x;
          parentY = parentPos.y;
        }
      }

      const newAngle = body.angle + body.speed;
      body.angle = newAngle;
      body.x = parentX + Math.cos(newAngle) * body.orbitRadius;
      body.y = parentY + Math.sin(newAngle) * body.orbitRadius;
      updatedPositions.set(body.id, {x: body.x, y: body.y});
    });
  }, []);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext('2d');
    if (!context) return;

    // A resize observer should handle this, but as a fallback
    if (canvas.width !== canvas.clientWidth || canvas.height !== canvas.clientHeight) {
      canvas.width = canvas.clientWidth;
      canvas.height = canvas.clientHeight;
    }

    context.clearRect(0, 0, canvas.width, canvas.height);
    context.fillStyle = '#0f172a'; // Deep space blue
    context.fillRect(0, 0, canvas.width, canvas.height);

    // Draw starfield
    context.fillStyle = 'white';
    starfieldRef.current.forEach((star) => {
      context.beginPath();
      context.arc(star.x, star.y, star.r, 0, 2 * Math.PI);
      context.fill();
    });

    const bodyPositions = new Map<string, {x: number; y: number}>();
    bodyPositions.set('center', {x: canvas.width / 2, y: canvas.height / 2});
    bodiesRef.current.forEach((b) => bodyPositions.set(b.id, {x: b.x, y: b.y}));

    // Draw orbits
    context.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    context.lineWidth = 1;
    bodiesRef.current.forEach((body) => {
      if (body.parentId) {
        const parentPos = bodyPositions.get(body.parentId) || bodyPositions.get('center')!;
        context.beginPath();
        context.arc(parentPos.x, parentPos.y, body.orbitRadius, 0, 2 * Math.PI);
        context.stroke();
      }
    });

    // Draw bodies
    bodiesRef.current.forEach((body) => {
      context.fillStyle = body.color;
      context.beginPath();
      context.arc(body.x, body.y, body.radius, 0, 2 * Math.PI);
      context.fill();

      // Selection highlight
      if (selectedBody && selectedBody.id === body.id) {
        context.strokeStyle = '#38bdf8';
        context.lineWidth = 2;
        context.stroke();
      }
    });
  }, [selectedBody]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    let resizeAnimationFrameId: number;

    const generateStars = () => {
        if (canvas) {
            starfieldRef.current = Array.from({length: 200}, () => ({
              x: Math.random() * canvas.clientWidth,
              y: Math.random() * canvas.clientHeight,
              r: Math.random() * 1.5,
            }));
        }
    };
    
    const loop = () => {
      update();
      draw();
      animationFrameIdRef.current = requestAnimationFrame(loop);
    };

    const handleCanvasClick = (event: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      const clickX = event.clientX - rect.left;
      const clickY = event.clientY - rect.top;

      let clickedBody: CelestialBody | null = null;
      for (let i = bodiesRef.current.length - 1; i >= 0; i--) {
        const body = bodiesRef.current[i];
        const dist = Math.hypot(clickX - body.x, clickY - body.y);
        if (dist <= body.radius + 5) {
          clickedBody = body;
          break;
        }
      }
      setSelectedBody(clickedBody);
    };

    const resizeObserver = new ResizeObserver(() => {
       resizeAnimationFrameId = window.requestAnimationFrame(() => {
           if (canvas) {
               canvas.width = canvas.clientWidth;
               canvas.height = canvas.clientHeight;
               generateStars();
               draw(); // Draw immediately after resize
           }
       });
    });

    resizeObserver.observe(canvas);
    canvas.addEventListener('click', handleCanvasClick);

    // Initial setup
    canvas.width = canvas.clientWidth;
    canvas.height = canvas.clientHeight;
    generateStars();
    animationFrameIdRef.current = requestAnimationFrame(loop);

    return () => {
      if (animationFrameIdRef.current) {
        cancelAnimationFrame(animationFrameIdRef.current);
      }
      window.cancelAnimationFrame(resizeAnimationFrameId);
      canvas.removeEventListener('click', handleCanvasClick);
      resizeObserver.disconnect();
    };
  }, [draw, update]);
  
  return (
      <div className="h-full bg-gray-900 text-white flex">
        <div className="w-2/3 h-full relative">
          <canvas ref={canvasRef} className="w-full h-full" />
        </div>
        <div className="w-1/3 h-full bg-gray-800 p-4 overflow-y-auto">
          <h3 className="text-lg font-bold text-cyan-300 mb-2">System Information</h3>
          {selectedBody ? (
            <div>
              <h4 className="text-xl font-semibold">{selectedBody.name}</h4>
              <p className="text-sm text-gray-400">{selectedBody.type}</p>
              <div className="mt-4 space-y-2 text-sm font-mono">
                  <p><strong>Mass:</strong> {selectedBody.mass}</p>
                  <p><strong>Gravity:</strong> {selectedBody.gravity}</p>
                  <p className="mt-2 text-xs text-gray-300 whitespace-pre-wrap">{selectedBody.description}</p>
              </div>
            </div>
          ) : (
            <p>Select a celestial body to view details.</p>
          )}
           <button onClick={() => { bodiesRef.current = generateStarSystem(); setSelectedBody(bodiesRef.current[0] ?? null); }} className="mt-4 w-full p-2 bg-blue-600 hover:bg-blue-500 rounded">
              Generate New System
           </button>
        </div>
      </div>
    );
};