/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useRef, useEffect } from 'react';
import { NativeAppComponentProps } from '../../types';

class CommNode {
    x: number; y: number;
    vx: number; vy: number;
    radius: number;

    constructor(width: number, height: number) {
        this.x = Math.random() * width;
        this.y = Math.random() * height;
        this.vx = Math.random() * 0.2 - 0.1;
        this.vy = Math.random() * 0.2 - 0.1;
        this.radius = Math.random() * 3 + 2;
    }

    update(width: number, height: number) {
        this.x += this.vx;
        this.y += this.vy;
        if (this.x < 0 || this.x > width) this.vx *= -1;
        if (this.y < 0 || this.y > height) this.vy *= -1;
    }
}

export const SubbaseComms: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        
        let nodes: CommNode[] = [];
        let animationId: number;
        let resizeAnimationId: number;
        
        const animate = () => {
            const { width, height } = canvas;
            ctx.fillStyle = 'rgba(15, 23, 42, 0.1)';
            ctx.fillRect(0, 0, width, height);

            nodes.forEach(node => {
                node.update(width, height);
                ctx.fillStyle = `rgba(14, 165, 233, ${Math.random()})`; // sky-500
                ctx.beginPath();
                ctx.arc(node.x, node.y, node.radius, 0, Math.PI * 2);
                ctx.fill();
            });

            animationId = requestAnimationFrame(animate);
        };
        
        const resizeObserver = new ResizeObserver(() => {
            resizeAnimationId = window.requestAnimationFrame(() => {
                if (canvas) {
                    canvas.width = canvas.clientWidth;
                    canvas.height = canvas.clientHeight;
                    nodes = Array.from({ length: 50 }, () => new CommNode(canvas.width, canvas.height));
                }
            });
        });
        
        canvas.width = canvas.clientWidth;
        canvas.height = canvas.clientHeight;
        nodes = Array.from({ length: 50 }, () => new CommNode(canvas.width, canvas.height));

        resizeObserver.observe(canvas);
        animate();

        return () => {
            cancelAnimationFrame(animationId);
            cancelAnimationFrame(resizeAnimationId);
            resizeObserver.disconnect();
        };

    }, []);

    return (
        <div className="h-full bg-slate-900 text-white flex flex-col relative">
            <div className="absolute top-0 left-0 right-0 p-4 z-10 bg-gradient-to-b from-black/50 to-transparent">
                <h2 className="text-xl font-bold text-sky-400">〰️ Subspace Comms</h2>
                <p className="text-sm">Monitoring secure data channels.</p>
            </div>
            <canvas ref={canvasRef} className="w-full h-full" />
        </div>
    );
};
