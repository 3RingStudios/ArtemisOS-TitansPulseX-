/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { NativeAppComponentProps } from '../../types';
import { loadModel, classifyImage } from '../../services/localAIService';
import { systemBus } from '../../services/systemBus';

export const LocalAILab: React.FC<Partial<NativeAppComponentProps>> = () => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const imageRef = useRef<HTMLImageElement>(null);
    const [status, setStatus] = useState('Local AI model not loaded.');
    const [isModelLoaded, setIsModelLoaded] = useState(false);
    const [classification, setClassification] = useState('');
    const [isCameraOn, setIsCameraOn] = useState(false);
    const [error, setError] = useState('');
    const [isDragging, setIsDragging] = useState(false);
    
    useEffect(() => {
        setStatus('Loading local AI model...');
        loadModel()
            .then(() => {
                setIsModelLoaded(true);
                setStatus('Local AI model loaded. Ready for classification.');
            })
            .catch(err => {
                setError(`Failed to load model: ${err.message}`);
                setStatus('Error loading model.');
            });
    }, []);

    const startCamera = useCallback(async () => {
        if (isCameraOn) { // Toggle off
            if (videoRef.current?.srcObject) {
                const stream = videoRef.current.srcObject as MediaStream;
                stream.getTracks().forEach(track => track.stop());
                videoRef.current.srcObject = null;
            }
            setIsCameraOn(false);
            return;
        }

        if (navigator.mediaDevices?.getUserMedia) {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ video: true });
                if (videoRef.current) {
                    videoRef.current.srcObject = stream;
                    setIsCameraOn(true);
                }
            } catch (err) {
                setError('Could not access camera.');
            }
        }
    }, [isCameraOn]);

    const runClassification = useCallback(async (element: HTMLImageElement | HTMLVideoElement) => {
        if (!isModelLoaded || !element) return;
        setClassification('Classifying...');
        try {
            const result = await classifyImage(element);
            setClassification(result);
            systemBus.emit('log_system_event', {
                message: `Local AI classified image: ${result}`,
                icon: '🤖',
                source: 'LocalAILab',
            });
        } catch (err: any) {
            setError(`Classification failed: ${err.message}`);
        }
    }, [isModelLoaded]);
    
    const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        setIsDragging(false);
        const file = event.dataTransfer.files[0];
        if (file && file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = (e) => {
                if (imageRef.current && e.target?.result) {
                    imageRef.current.src = e.target.result as string;
                    imageRef.current.onload = () => runClassification(imageRef.current!);
                }
            };
            reader.readAsDataURL(file);
        }
    };

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0">
                <h2 className="text-xl text-purple-400 font-bold">🤖 Local AI Lab (On-Device)</h2>
                <p className="text-sm text-gray-400">Image classification using TensorFlow.js, running entirely in the browser.</p>
            </div>

            <div 
                className={`flex-grow bg-black rounded-lg relative flex items-center justify-center overflow-hidden border-2 border-dashed ${isDragging ? 'border-purple-500' : 'border-gray-700'}`}
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
            >
                <video ref={videoRef} autoPlay playsInline className={`w-full h-full object-cover ${!isCameraOn && 'hidden'}`} />
                <img ref={imageRef} className={`max-w-full max-h-full ${isCameraOn && 'hidden'}`} alt="Drop an image here" />
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <p className="text-gray-500 bg-black/50 p-2 rounded">{isDragging ? 'Drop Image to Classify' : 'Drop an image or use camera'}</p>
                </div>
            </div>

            <div className="flex-shrink-0 grid grid-cols-3 gap-4 items-center">
                 <div className="col-span-2 bg-gray-800/50 p-3 rounded-lg min-h-[60px]">
                    <h3 className="font-bold text-sm text-gray-400">Classification Result:</h3>
                    <p className="text-lg">{classification}</p>
                 </div>
                 <div className="flex flex-col gap-2">
                    <button onClick={() => runClassification(isCameraOn ? videoRef.current! : imageRef.current!)} disabled={!isModelLoaded} className="llm-button m-0 h-full text-base disabled:bg-gray-600">Classify</button>
                    <button onClick={startCamera} className="llm-button m-0 h-full text-base bg-gray-600 hover:bg-gray-500">{isCameraOn ? 'Stop Camera' : 'Use Camera'}</button>
                 </div>
            </div>

             <div className="flex-shrink-0 p-1 border-t border-gray-700 text-xs text-center text-gray-400">
                Status: {error ? <span className="text-red-400">{error}</span> : <span>{status}</span>}
            </div>
        </div>
    );
};