/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useRef, useEffect } from 'react';
import { NativeAppComponentProps } from '../../types';

export const GlobalDisasterPrediction: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let rotation = 0;
        const animate = () => {
            rotation += 0.002;
            const { width, height } = canvas;
            ctx.clearRect(0, 0, width, height);

            // Globe
            ctx.fillStyle = '#1e40af';
            ctx.beginPath();
            ctx.arc(width/2, height/2, height/3, 0, Math.PI * 2);
            ctx.fill();

            // Alerts
            const alertX = width/2 + Math.cos(rotation) * height/3;
            const alertY = height/2 + Math.sin(rotation) * 20; // Elliptical orbit
            ctx.fillStyle = 'red';
            ctx.beginPath();
            ctx.arc(alertX, alertY, 5, 0, Math.PI * 2);
            ctx.fill();

            requestAnimationFrame(animate);
        };
        const animId = requestAnimationFrame(animate);
        return () => cancelAnimationFrame(animId);
    }, []);

    return (
        <div className="h-full bg-gray-900 text-white flex flex-col relative">
            <h2 className="text-xl font-bold p-4 text-yellow-300">🌋 Global Disaster Prediction</h2>
            <canvas ref={canvasRef} className="w-full h-full" />
        </div>
    );
};
