/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useRef, useEffect } from 'react';
import { NativeAppComponentProps } from '../../types';

class Node {
    x: number; y: number;
    vx: number; vy: number;
    radius: number;

    constructor(width: number, height: number) {
        this.x = Math.random() * width;
        this.y = Math.random() * height;
        this.vx = Math.random() * 0.5 - 0.25;
        this.vy = Math.random() * 0.5 - 0.25;
        this.radius = Math.random() * 2 + 2;
    }

    update(width: number, height: number) {
        this.x += this.vx;
        this.y += this.vy;
        if (this.x < 0 || this.x > width) this.vx *= -1;
        if (this.y < 0 || this.y > height) this.vy *= -1;
    }

    draw(ctx: CanvasRenderingContext2D) {
        ctx.fillStyle = '#a3e635'; // lime-400
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fill();
    }
}

export const APINodeEntangler: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        
        let nodes: Node[] = [];
        let animationId: number;
        let resizeAnimationId: number;
        
        const animate = () => {
            const { width, height } = canvas;
            ctx.fillStyle = 'rgba(17, 24, 39, 0.1)';
            ctx.fillRect(0, 0, width, height);

            nodes.forEach(node => {
                node.update(width, height);
                node.draw(ctx);
            });

            // Draw connections
            for(let i = 0; i < nodes.length; i++) {
                for(let j = i + 1; j < nodes.length; j++) {
                    const dist = Math.hypot(nodes[i].x - nodes[j].x, nodes[i].y - nodes[j].y);
                    if (dist < 150) {
                        ctx.strokeStyle = `rgba(163, 230, 53, ${1 - dist/150})`;
                        ctx.lineWidth = 0.5;
                        ctx.beginPath();
                        ctx.moveTo(nodes[i].x, nodes[i].y);
                        ctx.lineTo(nodes[j].x, nodes[j].y);
                        ctx.stroke();
                    }
                }
            }

            animationId = requestAnimationFrame(animate);
        };
        
        const resizeObserver = new ResizeObserver(() => {
            resizeAnimationId = window.requestAnimationFrame(() => {
                if (canvas) {
                    canvas.width = canvas.clientWidth;
                    canvas.height = canvas.clientHeight;
                    nodes = Array.from({ length: 100 }, () => new Node(canvas.width, canvas.height));
                }
            });
        });

        canvas.width = canvas.clientWidth;
        canvas.height = canvas.clientHeight;
        nodes = Array.from({ length: 100 }, () => new Node(canvas.width, canvas.height));
        
        resizeObserver.observe(canvas);
        animate();

        return () => {
            cancelAnimationFrame(animationId);
            cancelAnimationFrame(resizeAnimationId);
            resizeObserver.disconnect();
        };

    }, []);

    return (
        <div className="h-full bg-gray-900 text-white flex flex-col relative">
            <div className="absolute top-0 left-0 right-0 p-4 z-10 bg-gradient-to-b from-black/50 to-transparent">
                <h2 className="text-xl font-bold text-lime-300">🔗 API Node Entangler</h2>
                <p className="text-sm">Establishing quantum-simulated links between distributed services.</p>
            </div>
            <canvas ref={canvasRef} className="w-full h-full" />
        </div>
    );
};
