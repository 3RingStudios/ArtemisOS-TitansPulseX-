/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useCallback, useEffect, useRef, useMemo } from 'react';
import { NativeAppComponentProps } from '../../types';
import { systemBus } from '../../services/systemBus';
import { playSound, SoundType } from '../../services/audioService';
import { streamCodeHelperResponse } from '../../services/geminiService';

type AiMode = 'explain' | 'refactor' | 'generate' | null;
// The browser's File System Access API provides these types, but for TS we can define a minimal version.
type FileSystemFileHandle = any;

export const CodeEditor: React.FC<Partial<NativeAppComponentProps>> = ({ payload, onPayloadConsumed }) => {
  const [content, setContent] = useState<string>('// Use File > Open to edit a local file, or use the AI to generate code.');
  const [fileHandle, setFileHandle] = useState<FileSystemFileHandle | null>(null);
  const [fileName, setFileName] = useState<string>('Untitled');
  const [status, setStatus] = useState<string>('Ready.');
  const [aiResponse, setAiResponse] = useState<string>('');
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);
  const [activeAiMode, setActiveAiMode] = useState<AiMode>(null);

  const lineNumbersRef = useRef<HTMLTextAreaElement>(null);
  const codeInputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (payload && onPayloadConsumed) {
      const { name, content: fileContent } = payload;
      setFileHandle(null); // This is from an internal app, not the file system
      setFileName(name);
      setContent(fileContent);
      setStatus(`Loaded ${name} from internal app. Use 'Save As' to save to disk.`);
      onPayloadConsumed();
    }
  }, [payload, onPayloadConsumed]);

  const logToSystem = (message: string, icon: string) => {
    systemBus.emit('log_system_event', {
      message,
      icon,
      source: 'Code Editor',
    });
  };

  const handleNewFile = () => {
    playSound(SoundType.CLICK);
    setContent('// New file. Start typing or use "Generate Code".');
    setFileHandle(null);
    setFileName('Untitled.txt');
    setStatus('New file created.');
    setAiResponse('');
  };

  const handleOpenFile = useCallback(async () => {
    try {
      if (!('showOpenFilePicker' in window)) {
        setStatus('Error: Your browser does not support the File System Access API.');
        return;
      }
      setStatus('Opening file...');
      const [handle] = await (window as any).showOpenFilePicker();
      const file = await handle.getFile();
      const fileContent = await file.text();
      
      playSound(SoundType.OPEN);
      setFileHandle(handle);
      setFileName(handle.name);
      setContent(fileContent);
      setStatus(`Successfully opened ${handle.name}.`);
      logToSystem(`Opened file from host: ${handle.name}`, '📂');
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        setStatus(`Error opening file: ${err.message}`);
        console.error(err);
      } else {
        setStatus('File open cancelled.');
      }
    }
  }, []);

  const handleSave = useCallback(async () => {
    if (fileHandle) {
      try {
        setStatus(`Saving ${fileName}...`);
        const writable = await fileHandle.createWritable();
        await writable.write(content);
        await writable.close();
        playSound(SoundType.CLICK, 0.6);
        setStatus(`Successfully saved ${fileName} to disk.`);
        logToSystem(`Saved file to host: ${fileName}`, '💾');
      } catch (err: any) {
        setStatus(`Error saving file: ${err.message}`);
        console.error(err);
      }
    } else {
      await handleSaveAs();
    }
  }, [fileHandle, fileName, content]);

  const handleSaveAs = useCallback(async () => {
    try {
       if (!('showSaveFilePicker' in window)) {
        setStatus('Error: Your browser does not support the File System Access API.');
        return;
      }
      setStatus('Saving new file...');
      const handle = await (window as any).showSaveFilePicker({
          suggestedName: fileName,
          types: [{
              description: 'Text Files',
              accept: { 'text/plain': ['.txt', '.js', '.ts', '.css', '.html', '.md'] },
          }],
      });
      const writable = await handle.createWritable();
      await writable.write(content);
      await writable.close();
      
      playSound(SoundType.CLICK, 0.6);
      setFileHandle(handle);
      setFileName(handle.name);
      setStatus(`Successfully saved as ${handle.name} to disk.`);
      logToSystem(`Saved new file to host: ${handle.name}`, '💾');
    } catch (err: any) {
       if (err.name !== 'AbortError') {
        setStatus(`Error saving file: ${err.message}`);
        console.error(err);
      } else {
        setStatus('File save cancelled.');
      }
    }
  }, [content, fileName]);

  const handleAiAction = useCallback(async (mode: AiMode, prompt: string) => {
    if (!prompt) return;
    
    setIsAiLoading(true);
    setAiResponse('');
    setActiveAiMode(mode);
    setStatus(`AI is ${mode}ing...`);
    playSound(SoundType.TRANSITION);

    let fullResponse = '';
    try {
      const stream = streamCodeHelperResponse(prompt, mode!);
      for await (const chunk of stream) {
        fullResponse += chunk;
        setAiResponse(fullResponse);
      }
      setStatus(`AI ${mode} complete.`);
    } catch (e: any) {
      setAiResponse(`Error during AI operation: ${e.message}`);
      setStatus('AI Error.');
    } finally {
      setIsAiLoading(false);
      playSound(SoundType.OPEN, 0.5);
    }
  }, []);

  const handleGenerate = () => {
    const description = prompt("Describe the code you want to generate:");
    if (description) {
        handleAiAction('generate', description);
    }
  };
  const handleExplain = () => handleAiAction('explain', content);
  const handleRefactor = () => handleAiAction('refactor', content);

  const applyRefactoredCode = () => {
    const codeBlockRegex = /```(?:\w*\n)?([\s\S]*?)```/;
    const match = aiResponse.match(codeBlockRegex);
    if (match && match[1]) {
        setContent(match[1].trim());
        setStatus('Refactored code applied.');
        logToSystem('Applied AI code refactoring.', '🔧');
    } else {
        setStatus('Could not find a code block to apply.');
    }
  };

  const lineNumbers = useMemo(() => {
    const lines = content.split('\n').length;
    return Array.from({ length: lines }, (_, i) => i + 1).join('\n');
  }, [content]);

  const syncScroll = () => {
    if (lineNumbersRef.current && codeInputRef.current) {
      lineNumbersRef.current.scrollTop = codeInputRef.current.scrollTop;
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-900 text-gray-300 font-sans">
      {/* Toolbar */}
      <div className="flex items-center p-2 bg-gray-800 border-b border-gray-700 flex-shrink-0 gap-2">
        <button onClick={handleNewFile} className="code-editor-button">📄 New</button>
        <button onClick={handleOpenFile} className="code-editor-button">📂 Open</button>
        <button onClick={handleSave} className="code-editor-button">💾 Save</button>
        <button onClick={handleSaveAs} className="code-editor-button">💾 Save As...</button>
        <div className="w-px h-6 bg-gray-600 mx-2"></div>
        <button onClick={handleGenerate} className="code-editor-button ai-button">✨ Generate</button>
        <button onClick={handleExplain} disabled={!content} className="code-editor-button ai-button">📚 Explain</button>
        <button onClick={handleRefactor} disabled={!content} className="code-editor-button ai-button">🔧 Refactor</button>
      </div>
      
      <div className="flex-grow flex min-h-0">
         <div className="w-2/3 flex flex-col">
            <div className="flex-grow flex relative">
                <textarea
                    ref={lineNumbersRef}
                    readOnly
                    value={lineNumbers}
                    className="line-numbers"
                />
                <textarea
                    ref={codeInputRef}
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    onScroll={syncScroll}
                    className="code-input"
                    spellCheck="false"
                />
            </div>
         </div>
         <div className="w-1/3 border-l border-gray-700 flex flex-col">
            <h3 className="text-sm font-bold p-2 bg-gray-800 border-b border-gray-700">AI Assistant</h3>
            <div className="flex-grow bg-black/30 p-2 overflow-y-auto">
                {isAiLoading && <p className="text-cyan-400 animate-pulse">AI is thinking...</p>}
                <pre className="text-xs whitespace-pre-wrap">{aiResponse}</pre>
            </div>
             {activeAiMode === 'refactor' && !isAiLoading && aiResponse && (
                <div className="flex-shrink-0 p-2 border-t border-gray-700">
                    <button onClick={applyRefactoredCode} className="w-full llm-button m-0">Apply Refactored Code</button>
                </div>
             )}
         </div>
      </div>
      
      {/* Status Bar */}
      <div className="flex justify-between items-center p-2 bg-gray-800 border-t border-gray-700 text-xs flex-shrink-0">
        <span className="font-mono">{fileName}</span>
        <span className="text-gray-400">{status}</span>
        <span className="font-mono">Lines: {lineNumbers.split('\n').length} Chars: {content.length}</span>
      </div>
      
      <style>{`
        .code-editor-button {
          background-color: #374151; color: #d1d5db; border: none;
          padding: 0.5rem 1rem; border-radius: 0.25rem; cursor: pointer;
          transition: background-color 0.2s;
        }
        .code-editor-button:hover { background-color: #4b5563; }
        .code-editor-button:disabled { background-color: #4b5563; color: #6b7280; cursor: not-allowed; }
        .code-editor-button.ai-button { background-color: #1d4ed8; }
        .code-editor-button.ai-button:hover { background-color: #2563eb; }
        .line-numbers {
            width: 40px; padding: 1rem 0.5rem; resize: none; outline: none;
            background-color: #1f2937; color: #6b7280; text-align: right;
            border: none; font-family: monospace; line-height: 1.5rem;
        }
        .code-input {
            flex-grow: 1; padding: 1rem; resize: none; outline: none;
            background-color: #111827; color: #d1d5db;
            border: none; font-family: monospace; line-height: 1.5rem;
        }
        .llm-button { margin-top: 0; }
      `}</style>
    </div>
  );
};