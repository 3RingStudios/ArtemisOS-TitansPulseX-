/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useRef, useEffect } from 'react';
import { NativeAppComponentProps, UnrealNode } from '../../types';

const mockNodes: Omit<UnrealNode, 'id'>[] = [
    { lat: 34.0522, lon: -118.2437, type: 'Data Center' }, // LA
    { lat: 40.7128, lon: -74.0060, type: 'Data Center' }, // NYC
    { lat: 51.5074, lon: -0.1278, type: 'Data Center' }, // London
    { lat: 35.6895, lon: 139.6917, type: 'Data Center' }, // Tokyo
    { lat: 28.6139, lon: 77.2090, type: 'AI System' }, // New Delhi
    { lat: -23.5505, lon: -46.6333, type: 'AI System' }, // Sao Paulo
    { lat: 48.8566, lon: 2.3522, type: 'User' },
    { lat: 55.7558, lon: 37.6173, type: 'User' },
    { lat: 19.4326, lon: -99.1332, type: 'User' },
];

export const UnrealEngineNexus: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let rotation = 0;
        const nodes = mockNodes.map((n, i) => ({ ...n, id: `node_${i}` }));
        let animationId: number;
        let resizeAnimationId: number;

        const project = (lat: number, lon: number, radius: number) => {
            const phi = (90 - lat) * (Math.PI / 180);
            const theta = (lon + 180 + rotation) * (Math.PI / 180);
            const x = -(radius * Math.sin(phi) * Math.cos(theta));
            const z = radius * Math.sin(phi) * Math.sin(theta);
            const y = radius * Math.cos(phi);
            return { x, y, z };
        };

        const animate = () => {
            rotation += 0.2;
            const { width, height } = canvas;
            const radius = Math.min(width, height) * 0.35;
            
            ctx.clearRect(0, 0, width, height);

            // Globe
            ctx.fillStyle = '#0ea5e9'; // sky-500
            ctx.beginPath();
            ctx.arc(width / 2, height / 2, radius, 0, Math.PI * 2);
            ctx.fill();
            
            // Connections
            const projectedNodes = nodes.map(n => ({...n, ...project(n.lat, n.lon, radius)}));
            projectedNodes.forEach((n1, i) => {
                for (let j = i + 1; j < projectedNodes.length; j++) {
                    const n2 = projectedNodes[j];
                    if (n1.z > 0 && n2.z > 0) { // only draw on front face
                         ctx.strokeStyle = `rgba(255, 255, 255, ${0.1 * n1.z / radius})`;
                         ctx.beginPath();
                         ctx.moveTo(width / 2 + n1.x, height / 2 + n1.y);
                         ctx.lineTo(width / 2 + n2.x, height / 2 + n2.y);
                         ctx.stroke();
                    }
                }
            });

            // Nodes
            projectedNodes.sort((a,b) => a.z - b.z).forEach(node => {
                if (node.z > 0) {
                    const size = 2 + (node.z / radius) * 4;
                    const color = {
                        'User': '#f472b6', // pink-400
                        'AI System': '#a78bfa', // violet-400
                        'Data Center': '#facc15' // yellow-400
                    }[node.type];
                    ctx.fillStyle = color;
                    ctx.beginPath();
                    ctx.arc(width/2 + node.x, height/2 + node.y, size/2, 0, Math.PI * 2);
                    ctx.fill();
                }
            });

            animationId = requestAnimationFrame(animate);
        };
        
        const resizeObserver = new ResizeObserver(() => {
            resizeAnimationId = window.requestAnimationFrame(() => {
                if (canvas) {
                    canvas.width = canvas.clientWidth;
                    canvas.height = canvas.clientHeight;
                }
            });
        });
        
        canvas.width = canvas.clientWidth;
        canvas.height = canvas.clientHeight;
        resizeObserver.observe(canvas);
        animate();
        
        return () => {
            cancelAnimationFrame(animationId);
            cancelAnimationFrame(resizeAnimationId);
            resizeObserver.disconnect();
        };

    }, []);

    return (
        <div className="h-full bg-gray-900 text-white flex flex-col relative">
             <div className="absolute top-0 left-0 right-0 p-4 z-10 bg-gradient-to-b from-black/80 to-transparent">
                <h2 className="text-xl font-bold text-orange-400">🔥 Unreal Engine Nexus</h2>
                <p className="text-sm">Visualizing the Global Neural Network via Epic Online Services.</p>
            </div>
            <canvas ref={canvasRef} className="w-full h-full" />
        </div>
    );
};
