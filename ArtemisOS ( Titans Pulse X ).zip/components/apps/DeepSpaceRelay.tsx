/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useRef, useEffect } from 'react';
import { NativeAppComponentProps } from '../../types';

export const DeepSpaceRelay: React.FC<Partial<NativeAppComponentProps>> = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let frame = 0;
        const animate = () => {
            frame++;
            const { width, height } = canvas;
            ctx.clearRect(0, 0, width, height);
            
            const earth = { x: 50, y: height/2 };
            const mars = { x: width - 50, y: height/2 - 50};
            const saturn = { x: width - 100, y: 50};
            
            // Planets
            ctx.fillStyle = 'blue'; ctx.beginPath(); ctx.arc(earth.x, earth.y, 10, 0, 2 * Math.PI); ctx.fill();
            ctx.fillStyle = 'red'; ctx.beginPath(); ctx.arc(mars.x, mars.y, 8, 0, 2 * Math.PI); ctx.fill();
            ctx.fillStyle = 'orange'; ctx.beginPath(); ctx.arc(saturn.x, saturn.y, 12, 0, 2 * Math.PI); ctx.fill();
            
            // Signal
            const signalProgress = (frame % 200) / 200;
            const x = earth.x + (mars.x - earth.x) * signalProgress;
            const y = earth.y + (mars.y - earth.y) * signalProgress;
            
            ctx.fillStyle = 'cyan';
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, 2 * Math.PI);
            ctx.fill();

            requestAnimationFrame(animate);
        };
        const animId = requestAnimationFrame(animate);
        return () => cancelAnimationFrame(animId);
    }, []);

    return (
        <div className="h-full bg-black text-white">
            <h2 className="text-xl font-bold p-4 text-sky-300">🛰️ Deep Space Relay</h2>
            <canvas ref={canvasRef} className="w-full h-[calc(100%-4rem)]" />
        </div>
    );
};
