/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { NativeAppComponentProps } from '../../types';

export const ImageViewer: React.FC<Partial<NativeAppComponentProps>> = ({ payload }) => {
    const { imageUrl, prompt } = payload || { imageUrl: null, prompt: 'No image data received.' };

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0">
                <h2 className="text-xl text-cyan-300 font-bold">🖼️ Image Viewer</h2>
                <p className="text-sm text-gray-400 font-mono truncate">Prompt: {prompt}</p>
            </div>
            <div className="flex-grow bg-black/50 rounded-lg flex items-center justify-center overflow-hidden">
                {imageUrl ? (
                    <img src={imageUrl} alt={prompt} className="max-w-full max-h-full object-contain" />
                ) : (
                    <p>No image loaded.</p>
                )}
            </div>
        </div>
    );
};