/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useCallback } from 'react';
import { NativeAppComponentProps, UnityProject } from '../../types';
import { systemBus } from '../../services/systemBus';
import { playSound, SoundType } from '../../services/audioService';

const mockProjects: UnityProject[] = [
    { id: 'proj_1', name: 'ArtemisLegacy_UE5', path: '/dev/games/ArtemisLegacy', lastModified: Date.now() - 86400000 },
    { id: 'proj_2', name: 'HolographicSim', path: '/dev/sims/HolographicSim', lastModified: Date.now() - 3600000 },
    { id: 'proj_3', name: 'LightPipe_Prototype', path: '/dev/prototypes/LightPipe', lastModified: Date.now() - 120000 },
];

export const UnityToolkit: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [projects, setProjects] = useState<UnityProject[]>([]);
    const [selectedProject, setSelectedProject] = useState<UnityProject | null>(null);
    const [log, setLog] = useState<string[]>(['[UNITY TOOLKIT v1.0] Ready.']);

    const addLog = useCallback((message: string) => {
        systemBus.emit('log_system_event', { message, icon: '🎮', source: 'Unity Toolkit' });
        setLog(prev => [`[${new Date().toLocaleTimeString()}] ${message}`, ...prev].slice(0, 100));
    }, []);

    const handleScan = () => {
        playSound(SoundType.TRANSITION);
        addLog("Scanning for local Unity/Unreal projects...");
        setTimeout(() => {
            setProjects(mockProjects);
            addLog(`Found ${mockProjects.length} projects.`);
            if (mockProjects.length > 0) {
                setSelectedProject(mockProjects[0]);
            }
        }, 1500);
    };

    const handleBuild = () => {
        if (!selectedProject) return;
        playSound(SoundType.CLICK);
        addLog(`Executing Python build script for "${selectedProject.name}"...`);
        setTimeout(() => addLog(`Compiling shaders...`), 500);
        setTimeout(() => addLog(`Building assets... Packed 1,234 assets.`), 2000);
        setTimeout(() => {
            addLog(`Build successful for platform: Windows_x64.`);
            playSound(SoundType.OPEN);
        }, 3500);
    };

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex gap-4">
            <div className="w-1/3 flex flex-col gap-4">
                <div className="flex-shrink-0 pb-2 border-b border-gray-700">
                    <h2 className="text-xl text-purple-400 font-bold">🎮 Unity/Unreal Toolkit</h2>
                </div>
                <button onClick={handleScan} className="p-3 bg-blue-600 hover:bg-blue-500 rounded text-white font-bold">Scan for Projects</button>
                <div className="flex-grow overflow-y-auto bg-black/30 rounded-lg p-2 space-y-2">
                    {projects.map(proj => (
                        <div 
                            key={proj.id}
                            onClick={() => setSelectedProject(proj)}
                            className={`p-3 rounded cursor-pointer ${selectedProject?.id === proj.id ? 'bg-purple-600/50' : 'bg-gray-800 hover:bg-gray-700'}`}
                        >
                            <p className="font-bold truncate">{proj.name}</p>
                            <p className="text-xs text-gray-400 truncate">{proj.path}</p>
                        </div>
                    ))}
                </div>
            </div>
            <div className="w-2/3 flex flex-col">
                 <div className="flex-shrink-0 pb-2 mb-4">
                    <h3 className="text-lg font-semibold">{selectedProject ? selectedProject.name : "No Project Selected"}</h3>
                 </div>
                 <div className="bg-gray-800 p-4 rounded-lg mb-4">
                    <h4 className="font-bold mb-2">Actions</h4>
                    <button onClick={handleBuild} disabled={!selectedProject} className="p-2 bg-green-600 hover:bg-green-500 rounded text-white disabled:bg-gray-600">Run Python Build Script</button>
                 </div>
                 <div className="flex-grow bg-black rounded-lg p-3 font-mono text-xs text-green-300 flex flex-col">
                    <h4 className="text-sm font-semibold mb-2 p-2 border-b border-gray-700 text-white">Output Log</h4>
                    <div className="flex-grow overflow-y-auto">
                        {log.map((line, i) => <p key={i} className="whitespace-pre-wrap">{line}</p>)}
                    </div>
                 </div>
            </div>
        </div>
    );
};
