/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { NativeAppComponentProps, LinterIssue } from '../../types';

const mockIssues: Omit<LinterIssue, 'id'>[] = [
    { file: 'FlightDynamicsLab.tsx', line: 125, severity: 'Warning', message: '`useCallback` has an unnecessary dependency.' },
    { file: 'geminiService.ts', line: 210, severity: 'Error', message: 'Type `any` is not recommended.' },
    { file: 'App.tsx', line: 88, severity: 'Info', message: 'Consider refactoring for better readability.' },
];

export const UniversalLinter: React.FC<Partial<NativeAppComponentProps>> = () => {
    const [issues, setIssues] = useState<LinterIssue[]>([]);

    useEffect(() => {
        const interval = setInterval(() => {
            const newIssue = mockIssues[Math.floor(Math.random() * mockIssues.length)];
            setIssues(prev => [{ ...newIssue, id: `issue_${Date.now()}` }, ...prev].slice(0, 50));
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    const getSeverityColor = (severity: LinterIssue['severity']) => ({
        'Error': 'bg-red-500',
        'Warning': 'bg-yellow-500',
        'Info': 'bg-blue-500',
    }[severity]);

    return (
        <div className="h-full bg-gray-800 text-gray-300 font-mono text-xs p-4 flex flex-col">
            <h2 className="text-lg text-gray-400 mb-4 border-b border-gray-600 pb-2">Universal Linter - System Scan</h2>
            <div className="flex-grow overflow-y-auto pr-2">
                {issues.map(issue => (
                    <div key={issue.id} className="flex gap-3 mb-2 animate-fade-in">
                        <span className={`w-2 h-4 rounded ${getSeverityColor(issue.severity)}`}></span>
                        <span className="text-gray-500 w-32 flex-shrink-0">{issue.file}:{issue.line}</span>
                        <span className="flex-grow">{issue.message}</span>
                    </div>
                ))}
            </div>
        </div>
    );
};
