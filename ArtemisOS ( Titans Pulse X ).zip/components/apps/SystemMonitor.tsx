/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { NativeAppComponentProps, Process } from '../../types';
import { systemBus } from '../../services/systemBus';

declare const Chart: any;

const createChart = (ctx: CanvasRenderingContext2D, label: string, color: string) => {
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: Array(30).fill(''),
            datasets: [{
                label,
                data: Array(30).fill(0),
                borderColor: color,
                borderWidth: 2,
                pointRadius: 0,
                tension: 0.4,
                fill: true,
                backgroundColor: `${color}1A`,
            }],
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { x: { display: false }, y: { display: true, beginAtZero: true, max: 100, ticks: { color: '#9ca3af' } } },
        },
    });
};

export const SystemMonitor: React.FC<Partial<NativeAppComponentProps>> = ({ runningApps = {}, appDefinitions = [] }) => {
    const cpuChartRef = useRef<HTMLCanvasElement>(null);
    const memChartRef = useRef<HTMLCanvasElement>(null);
    const netChartRef = useRef<HTMLCanvasElement>(null);
    const charts = useRef<any>({});
    const [processes, setProcesses] = useState<Process[]>([]);

    useEffect(() => {
        if (typeof Chart === 'undefined') return;

        if (cpuChartRef.current) charts.current.cpu = createChart(cpuChartRef.current.getContext('2d')!, 'CPU Usage', '#38bdf8');
        if (memChartRef.current) charts.current.mem = createChart(memChartRef.current.getContext('2d')!, 'Memory Usage', '#a78bfa');
        if (netChartRef.current) charts.current.net = createChart(netChartRef.current.getContext('2d')!, 'Network I/O', '#34d399');

        const interval = setInterval(() => {
            const runningAppIds = Object.keys(runningApps);
            const newProcesses = runningAppIds.map(appId => {
                const def = appDefinitions.find(d => d.id === appId);
                const existing = processes.find(p => p.id === appId);
                const cpu = existing ? Math.max(0.1, existing.cpu + (Math.random() - 0.5) * 2) : Math.random() * 5 + 1;
                const memory = existing ? Math.max(20, existing.memory + (Math.random() - 0.5) * 10) : Math.random() * 80 + 40;
                return {
                    id: appId,
                    name: def?.name || 'Unknown Process',
                    icon: def?.icon || '❓',
                    cpu: parseFloat(cpu.toFixed(1)),
                    memory: parseFloat(memory.toFixed(1)),
                };
            });
            setProcesses(newProcesses);

            const totalCpu = newProcesses.reduce((sum, p) => sum + p.cpu, 0);
            const totalMem = newProcesses.reduce((sum, p) => sum + p.memory, 0) / 4096 * 100; // Assume 4GB total
            const netUsage = Math.random() * 30 + 5;

            Object.values(charts.current).forEach((chart: any) => {
                const data = chart.data.datasets[0].data;
                if (chart.data.datasets[0].label.startsWith('CPU')) data.push(totalCpu);
                else if (chart.data.datasets[0].label.startsWith('Memory')) data.push(totalMem);
                else data.push(netUsage);
                data.shift();
                chart.update('none');
            });
        }, 1500);

        return () => {
            clearInterval(interval);
            Object.values(charts.current).forEach((chart: any) => chart.destroy());
        };
    }, [runningApps, appDefinitions]); // Rerun effect if the core app list changes

    const handleEndTask = (appId: string) => {
        systemBus.emit('execute_command', { command: 'close_app', appId });
    };

    return (
        <div className="h-full bg-gray-900 text-gray-300 font-sans p-4 flex flex-col gap-4">
            <div className="flex-shrink-0">
                <h2 className="text-xl text-cyan-300 font-bold">📊 System Monitor</h2>
            </div>
            <div className="flex-shrink-0 grid grid-cols-1 md:grid-cols-3 gap-4 h-32">
                <div className="bg-gray-800/50 p-2 rounded-lg"><canvas ref={cpuChartRef}></canvas></div>
                <div className="bg-gray-800/50 p-2 rounded-lg"><canvas ref={memChartRef}></canvas></div>
                <div className="bg-gray-800/50 p-2 rounded-lg"><canvas ref={netChartRef}></canvas></div>
            </div>
            <div className="flex-grow flex flex-col bg-gray-800/50 rounded-lg overflow-hidden">
                <h3 className="p-2 font-bold text-gray-400">Processes ({processes.length})</h3>
                <div className="flex-grow overflow-y-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="bg-gray-700/50 text-xs text-gray-400 uppercase">
                            <tr>
                                <th className="px-4 py-2">Process Name</th>
                                <th className="px-4 py-2 text-right">CPU %</th>
                                <th className="px-4 py-2 text-right">Memory (MB)</th>
                                <th className="px-4 py-2 text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-700/50">
                            {processes.map((proc) => (
                                <tr key={proc.id} className="hover:bg-gray-700/30">
                                    <td className="px-4 py-2 font-medium flex items-center gap-2">
                                        <span className="text-lg">{proc.icon}</span>
                                        <span>{proc.name}</span>
                                    </td>
                                    <td className="px-4 py-2 text-right font-mono">{proc.cpu}</td>
                                    <td className="px-4 py-2 text-right font-mono">{proc.memory}</td>
                                    <td className="px-4 py-2 text-center">
                                        <button onClick={() => handleEndTask(proc.id)} className="text-xs bg-red-600 hover:bg-red-700 text-white px-2 py-1 rounded">End Task</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};
