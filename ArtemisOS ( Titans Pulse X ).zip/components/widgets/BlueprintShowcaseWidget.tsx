/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import {systemBus} from '../../services/systemBus';
import {playSound, SoundType} from '../../services/audioService';
import {Blueprint} from '../../types';

interface BlueprintShowcaseWidgetProps {
  blueprint: Blueprint | null;
}

export const BlueprintShowcaseWidget: React.FC<BlueprintShowcaseWidgetProps> = ({
  blueprint,
}) => {
  const handleSimulate = () => {
    playSound(SoundType.CLICK);
    // This is a placeholder command. A real implementation would need to
    // pass the blueprint data to the Flight Dynamics Lab.
    systemBus.emit('execute_command', {
      command: 'open_app',
      appId: 'flight_dynamics_lab_app',
    });
  };

  return (
    <div className="widget">
      <h3 className="widget-title">Blueprint Showcase</h3>
      <div className="widget-content">
        {blueprint ? (
          <div className="flex flex-col h-full">
            <div className="flex-grow">
              <p className="text-xs text-gray-400">Latest Discovery:</p>
              <p className="font-semibold text-fuchsia-400">
                {blueprint.technologyName}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                ID: {blueprint.blueprintId}
              </p>
            </div>
            <button className="widget-button" onClick={handleSimulate}>
              Simulate in Lab
            </button>
          </div>
        ) : (
          <p className="text-sm text-gray-500 text-center py-4">
            Awaiting discovery from Evolutionary Vault...
          </p>
        )}
      </div>
    </div>
  );
};