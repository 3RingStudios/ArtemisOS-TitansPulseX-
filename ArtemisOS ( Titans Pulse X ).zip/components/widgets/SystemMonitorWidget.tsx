/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useEffect, useRef, useState} from 'react';

// Declare Chart.js type for global scope
declare const Chart: any;

export const SystemMonitorWidget: React.FC = () => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<any>(null); // To hold the chart instance
  const [cpuUsage, setCpuUsage] = useState(0);

  useEffect(() => {
    if (!chartRef.current) return;

    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;

    chartInstance.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels: Array(20).fill(''),
        datasets: [
          {
            label: 'Core Usage',
            data: Array(20).fill(0),
            borderColor: '#38bdf8', // light-blue-400
            backgroundColor: 'rgba(56, 189, 248, 0.1)',
            borderWidth: 2,
            pointRadius: 0,
            tension: 0.4,
            fill: true,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          },
          tooltip: {
            enabled: false,
          },
        },
        scales: {
          x: {
            display: false,
          },
          y: {
            display: false,
            beginAtZero: true,
            max: 100,
          },
        },
      },
    });

    const interval = setInterval(() => {
      const newUsage = Math.random() * 40 + 5; // Simulate 5-45% usage
      setCpuUsage(newUsage);

      if (chartInstance.current) {
        const data = chartInstance.current.data.datasets[0].data;
        data.push(newUsage);
        data.shift();
        chartInstance.current.update('none');
      }
    }, 2000);

    return () => {
      clearInterval(interval);
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, []);

  return (
    <div className="widget">
      <h3 className="widget-title">System Monitor</h3>
      <div className="widget-content">
        <div className="h-20 w-full mb-2">
          <canvas ref={chartRef}></canvas>
        </div>
        <div className="text-center font-mono text-lg">
          <span className="text-cyan-300">{cpuUsage.toFixed(1)}%</span>
          <span className="text-sm text-gray-400"> Core Usage</span>
        </div>
      </div>
    </div>
  );
};