/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useEffect, useRef, useState} from 'react';

// Declare Chart.js type for global scope
declare const Chart: any;

export const TinySystemMonitor: React.FC = () => {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<any>(null); // To hold the chart instance
  const [cpuUsage, setCpuUsage] = useState(0);

  useEffect(() => {
    // A one-time check to see if Chart.js is available on the window.
    if (typeof Chart === 'undefined') {
        console.error("Chart.js is not loaded. TinySystemMonitor cannot render.");
        return;
    }
      
    if (!chartRef.current) return;

    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;

    chartInstance.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels: Array(15).fill(''),
        datasets: [
          {
            label: 'Core Usage',
            data: Array(15).fill(0),
            borderColor: '#38bdf8', // light-blue-400
            borderWidth: 1.5,
            pointRadius: 0,
            tension: 0.4,
            fill: false,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: {
            duration: 500,
        },
        plugins: {
          legend: {
            display: false,
          },
          tooltip: {
            enabled: false,
          },
        },
        scales: {
          x: {
            display: false,
          },
          y: {
            display: false,
            beginAtZero: true,
            max: 100,
          },
        },
      },
    });

    const interval = setInterval(() => {
      // More realistic simulation: base usage with spikes
      const baseUsage = 15;
      const spike = Math.random() > 0.9 ? Math.random() * 50 : 0;
      const noise = Math.random() * 10;
      const newUsage = baseUsage + spike + noise;
        
      setCpuUsage(newUsage);

      if (chartInstance.current) {
        const data = chartInstance.current.data.datasets[0].data;
        data.push(newUsage);
        data.shift();
        chartInstance.current.update('none');
      }
    }, 1500);

    return () => {
      clearInterval(interval);
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, []);

  return (
    <div className="flex items-center gap-2 bg-black/20 px-2 py-0.5 rounded-md">
      <div className="h-6 w-16">
          <canvas ref={chartRef}></canvas>
      </div>
      <div className="font-mono text-xs text-cyan-300 w-12 text-right">
        {cpuUsage.toFixed(1)}%
      </div>
    </div>
  );
};