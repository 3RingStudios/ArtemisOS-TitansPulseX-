/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import React, {useState, useEffect, useCallback, useMemo, useRef} from 'react';
import { systemBus } from '../services/systemBus';
import {Advancement, AppDefinition} from '../types';

// Interfaces for the new state from user's HTML
interface ApiKeyInfo {
  name: string;
  key: string;
  created: string;
  expiry: string;
  permissions: string[];
  active: boolean;
  port: number | null;
}

interface LlmConfig {
  provider: 'openai' | 'anthropic' | 'local' | 'other';
  endpoint: string;
  promptTemplate?: string;
  apiKey?: string;
}

interface StorageConfig {
  type: 'json' | 'sqlite' | 'postgresql' | 'mongodb';
  path?: string;
  connectionString?: string;
}

// Props from App.tsx
interface ParametersPanelProps {
  currentLength: number;
  onUpdateHistoryLength: (length: number) => void;
  isStatefulnessEnabled: boolean;
  onSetStatefulness: (enabled: boolean) => void;
  onExportState: () => void;
  onImportState: (fileContent: string) => void;
  advancements: Advancement[];
  appDefinitions: AppDefinition[];
  currentWallpaper: string;
}

type Tab =
  | 'keys'
  | 'network'
  | 'llm'
  | 'data'
  | 'personalization'
  | 'advancements'
  | 'apps'
  | 'system';

const TabButton: React.FC<{
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({label, isActive, onClick}) => (
  <button
    onClick={onClick}
    className={`px-4 py-2 text-sm font-medium transition-colors rounded-t-lg ${
      isActive
        ? 'bg-gray-100 text-blue-600 border-b-2 border-blue-600'
        : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
    }`}
    role="tab"
    aria-selected={isActive}>
    {label}
  </button>
);

const Card: React.FC<{title: string; children: React.ReactNode}> = ({
  title,
  children,
}) => (
  <div className="bg-white rounded-lg shadow-md p-6 mb-6">
    <h3 className="text-lg font-bold text-gray-800 mb-4">{title}</h3>
    {children}
  </div>
);

const Alert: React.FC<{
  message: string;
  type: 'success' | 'error' | 'info';
}> = ({message, type}) => {
  const colors = {
    success: 'bg-green-100 text-green-800 border-green-200',
    error: 'bg-red-100 text-red-800 border-red-200',
    info: 'bg-blue-100 text-blue-800 border-blue-200',
  };
  if (!message) return null;
  return (
    <div
      className={`p-4 my-4 border-l-4 rounded-r-md ${colors[type]}`}
      dangerouslySetInnerHTML={{__html: message}}></div>
  );
};

const generateRandomString = (length: number) => {
  const chars =
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

// --- Tab Components ---

const KeyManagementTab: React.FC = () => {
  const [apiKeys, setApiKeys] = useState<Record<string, ApiKeyInfo>>(() =>
    JSON.parse(localStorage.getItem('artemisOS_apiKeys') || '{}'),
  );
  const [selectedKey, setSelectedKey] = useState<string | null>(null);
  const [keyName, setKeyName] = useState('');
  const [expiryDays, setExpiryDays] = useState(30);
  const [permissions, setPermissions] = useState({
    read: true,
    write: false,
    delete: false,
    admin: false,
    llm_access: true,
    data_management: false,
  });
  const [alert, setAlert] = useState<{message: string; type: 'success' | 'error'}>({message: '', type: 'success'});

  useEffect(() => {
    localStorage.setItem('artemisOS_apiKeys', JSON.stringify(apiKeys));
  }, [apiKeys]);

  const handleGenerateKey = () => {
    const newKey = `sk-local-${generateRandomString(32)}`;
    const newKeyInfo: ApiKeyInfo = {
      key: newKey,
      name: keyName || `Key-${generateRandomString(6)}`,
      created: new Date().toISOString(),
      expiry: new Date(Date.now() + expiryDays * 24 * 60 * 60 * 1000).toISOString(),
      permissions: Object.entries(permissions).filter(([, val]) => val).map(([key]) => key),
      active: true,
      port: null,
    };

    setApiKeys(prev => ({...prev, [newKey]: newKeyInfo}));
    setAlert({message: `<b>API Key Generated:</b> <code>${newKey}</code><br/>Copy this key now, it won't be shown again.`, type: 'success'});
    setKeyName('');
  };

  const handleKeyAction = (action: 'revoke' | 'renew' | 'delete') => {
    if (!selectedKey) return;
    const keyInfo = apiKeys[selectedKey];
    if (!keyInfo) return;

    if (action === 'delete') {
      const confirmed = window.confirm(`Are you sure you want to delete the key "${keyInfo.name}"? This cannot be undone.`);
      if (confirmed) {
        const newKeys = {...apiKeys};
        delete newKeys[selectedKey];
        setApiKeys(newKeys);
        setSelectedKey(null);
        setAlert({message: `Key "${keyInfo.name}" deleted.`, type: 'success'});
      }
    } else {
        const updatedKeyInfo = {...keyInfo};
        if (action === 'revoke') {
            updatedKeyInfo.active = false;
        } else if (action === 'renew') {
            updatedKeyInfo.expiry = new Date(Date.now() + expiryDays * 24 * 60 * 60 * 1000).toISOString();
            updatedKeyInfo.active = true;
        }
        setApiKeys(prev => ({...prev, [selectedKey]: updatedKeyInfo}));
        setAlert({message: `Key "${keyInfo.name}" ${action}ed.`, type: 'success'});
    }
  };

  return (
    <div>
      <Card title="Generate New API Key">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                 <label className="llm-label">Key Name</label>
                 <input type="text" value={keyName} onChange={e => setKeyName(e.target.value)} className="llm-input" placeholder="e.g., My Test Key"/>
            </div>
            <div>
                 <label className="llm-label">Expiry (days)</label>
                 <input type="number" value={expiryDays} onChange={e => setExpiryDays(Number(e.target.value))} className="llm-input" />
            </div>
             <div className="md:col-span-2">
                 <label className="llm-label">Permissions</label>
                 <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-2 text-sm">
                    {Object.entries(permissions).map(([key, value]) => (
                        <label key={key} className="flex items-center gap-2">
                            <input type="checkbox" checked={value} onChange={e => setPermissions(p => ({...p, [key]: e.target.checked}))} />
                            <span>{key.replace('_', ' ')}</span>
                        </label>
                    ))}
                 </div>
            </div>
        </div>
        <button onClick={handleGenerateKey} className="llm-button mt-4">Generate Key</button>
        <Alert message={alert.message} type={alert.type} />
      </Card>
       <Card title="Manage Existing Keys">
            <div className="overflow-x-auto">
                <table className="w-full text-sm">
                    <thead>
                        <tr className="border-b">
                            <th className="p-2 text-left">Name</th>
                            <th className="p-2 text-left">Key</th>
                            <th className="p-2 text-left">Expiry</th>
                            <th className="p-2 text-left">Status</th>
                            <th className="p-2 text-left">Port</th>
                        </tr>
                    </thead>
                    <tbody>
                        {Object.values(apiKeys).map((info) => (
                             <tr key={info.key} onClick={() => setSelectedKey(info.key)} className={`border-b cursor-pointer hover:bg-gray-100 ${selectedKey === info.key ? 'bg-blue-100' : ''}`}>
                                <td className="p-2">{info.name}</td>
                                <td className="p-2 font-mono">{info.key.substring(0, 11)}...</td>
                                <td className="p-2">{new Date(info.expiry).toLocaleDateString()}</td>
                                <td className="p-2"><span className={`px-2 py-1 text-xs rounded-full ${info.active && new Date(info.expiry) > new Date() ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800'}`}>{info.active && new Date(info.expiry) > new Date() ? 'Active' : 'Inactive'}</span></td>
                                <td className="p-2">{info.port || 'N/A'}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {selectedKey && (
                <div className="mt-4 pt-4 border-t">
                    <h4 className="font-bold">Actions for "{apiKeys[selectedKey]?.name}"</h4>
                    <div className="flex gap-4 mt-2">
                        <button onClick={() => handleKeyAction('revoke')} className="llm-button bg-yellow-500 hover:bg-yellow-600">Revoke</button>
                        <button onClick={() => handleKeyAction('renew')} className="llm-button bg-blue-500 hover:bg-blue-600">Renew</button>
                        <button onClick={() => handleKeyAction('delete')} className="llm-button bg-red-500 hover:bg-red-600">Delete</button>
                    </div>
                </div>
            )}
       </Card>
    </div>
  );
};

const NetworkConfigTab: React.FC = () => {
    // This is a placeholder as direct port scanning is not possible from browser JS.
    // In a real native app (like with Tauri), this could be a call to the backend.
    const [scanResult, setScanResult] = useState('');
    const handleScan = () => {
        setScanResult("Port scanning is a native-only feature. Simulating: Found available ports 8080, 8081, 9000.");
    };

    return (
        <div>
            <Card title="Port Scanning & Assignment">
                <p className="text-sm text-gray-500 mb-4">In a native build of ArtemisOS, this panel would allow scanning for open network ports and assigning them to specific API keys for local services. This functionality is simulated in the web version.</p>
                <button onClick={handleScan} className="llm-button">Scan for Available Ports</button>
                {scanResult && <Alert message={scanResult} type="info" />}
            </Card>
        </div>
    );
};

const LLMIntegrationTab: React.FC<{currentLength: number; onUpdateHistoryLength: (length: number) => void;}> = ({ currentLength, onUpdateHistoryLength }) => {
    const [config, setConfig] = useState<LlmConfig>(() => JSON.parse(localStorage.getItem('artemisOS_llmConfig') || '{"provider":"local","endpoint":"http://localhost:5000"}'));
    const [alert, setAlert] = useState<{message: string; type: 'success' | 'error'}>({message: '', type: 'success'});

    useEffect(() => {
        localStorage.setItem('artemisOS_llmConfig', JSON.stringify(config));
    }, [config]);

    const handleSave = () => {
        // The config is already saved on change by useEffect. This button is for user feedback.
        setAlert({message: "LLM Configuration Saved!", type: 'success'});
    };

    return (
        <div>
            <Card title="LLM Configuration">
                <div className="space-y-4">
                    <div>
                        <label className="llm-label">LLM Provider</label>
                        <select value={config.provider} onChange={e => setConfig(c => ({...c, provider: e.target.value as LlmConfig['provider']}))} className="llm-input">
                            <option value="local">Local LLM</option>
                            <option value="openai">OpenAI</option>
                            <option value="anthropic">Anthropic</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                     {config.provider === 'local' && (
                        <div>
                            <label className="llm-label">Local LLM Endpoint</label>
                            <input type="text" value={config.endpoint} onChange={e => setConfig(c => ({...c, endpoint: e.target.value}))} className="llm-input" />
                        </div>
                    )}
                     {(config.provider === 'openai' || config.provider === 'anthropic' || config.provider === 'other') && (
                        <>
                           <div>
                                <label className="llm-label">Endpoint URL</label>
                                <input type="text" value={config.endpoint} onChange={e => setConfig(c => ({...c, endpoint: e.target.value}))} className="llm-input" />
                            </div>
                            <div>
                                <label className="llm-label">API Key</label>
                                <input type="password" value={config.apiKey || ''} onChange={e => setConfig(c => ({...c, apiKey: e.target.value}))} className="llm-input" />
                            </div>
                        </>
                    )}
                    <div>
                        <label className="llm-label">AI Context History Length: {currentLength}</label>
                        <input type="range" min="1" max="20" value={currentLength} onChange={(e) => onUpdateHistoryLength(Number(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" />
                    </div>
                    <button onClick={handleSave} className="llm-button">Save Configuration</button>
                    <Alert message={alert.message} type={alert.type} />
                </div>
            </Card>
        </div>
    );
};

const DataManagementTab: React.FC<{
  isStatefulnessEnabled: boolean;
  onSetStatefulness: (enabled: boolean) => void;
  onExportState: () => void;
  onImportState: (fileContent: string) => void;
}> = (props) => {
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleImportClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const content = e.target?.result as string;
                props.onImportState(content);
            };
            reader.onerror = () => {
                alert('Failed to read file.');
            };
            reader.readAsText(file);
        }
    };

    return (
        <div>
            <Card title="OS State Persistence">
                 <div className="flex items-center justify-between">
                  <div>
                    <label htmlFor="statefulness" className="text-sm font-medium text-gray-700">Enable Auto-Save to Browser</label>
                    <p className="text-xs text-gray-500">Automatically save and recall OS state using IndexedDB.</p>
                  </div>
                  <div className="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in">
                    <input type="checkbox" name="statefulness" id="statefulness" checked={props.isStatefulnessEnabled} onChange={(e) => props.onSetStatefulness(e.target.checked)} className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer"/>
                    <label htmlFor="statefulness" className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer"></label>
                  </div>
                </div>
            </Card>
            <Card title="Manual State Control">
                <p className="text-sm text-gray-500 mb-4">Export the current OS state to a file, or import a state file to restore a previous session.</p>
                 <div className="flex gap-4">
                    <button onClick={props.onExportState} className="llm-button flex-1">Export State to File</button>
                    <button onClick={handleImportClick} className="llm-button flex-1">Import State from File</button>
                    <input type="file" ref={fileInputRef} accept=".json" style={{ display: 'none' }} onChange={handleFileChange} />
                </div>
            </Card>
        </div>
    );
};

const PersonalizationTab: React.FC<{currentWallpaper: string}> = ({currentWallpaper}) => {
    const [newUrl, setNewUrl] = useState('');
    const defaultWallpaper = 'https://www.transparenttextures.com/patterns/cubes.png';
    
    const handleApply = () => {
        if (newUrl.trim()) {
            systemBus.emit('set_wallpaper', newUrl.trim());
        }
    };

    const handleReset = () => {
        systemBus.emit('set_wallpaper', defaultWallpaper);
    };

    return (
        <div>
            <Card title="Desktop Wallpaper">
                <p className="text-sm text-gray-500 mb-4">Change the desktop background. You can also drag and drop an image file directly onto the desktop.</p>
                <div>
                    <label className="llm-label">Image URL</label>
                    <input 
                        type="text" 
                        value={newUrl}
                        onChange={e => setNewUrl(e.target.value)}
                        className="llm-input" 
                        placeholder="Paste image URL here..."
                    />
                </div>
                <div className="flex gap-4 mt-4">
                    <button onClick={handleApply} className="llm-button flex-1">Apply Wallpaper</button>
                    <button onClick={handleReset} className="llm-button flex-1 bg-gray-600 hover:bg-gray-700">Reset to Default</button>
                </div>
            </Card>
             <Card title="Current Wallpaper Preview">
                 <div className="w-full h-48 bg-gray-200 rounded-md bg-cover bg-center" style={{backgroundImage: `url('${currentWallpaper}')`}}></div>
             </Card>
        </div>
    )
};


const AdvancementsTab: React.FC<{advancements: Advancement[]}> = ({ advancements }) => (
    <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2">
        {advancements.length > 0 ? (
          advancements.slice().reverse().map((adv) => (
              <div key={adv.id} className="p-3 bg-green-50 rounded-lg border border-green-200">
                <p className="font-semibold text-green-800">{adv.message}</p>
                <p className="text-xs text-gray-500 mt-1">{new Date(adv.timestamp).toLocaleString()}</p>
              </div>
            ))
        ) : (
          <p className="text-gray-500 text-center py-8">No advancements achieved yet.</p>
        )}
      </div>
);

const ApplicationsTab: React.FC<{appDefinitions: AppDefinition[]}> = ({ appDefinitions }) => (
    <div className="space-y-2 max-h-[500px] overflow-y-auto pr-2">
        <p className="text-sm text-gray-600 mb-3">A total of {appDefinitions.length} applications are installed in the system.</p>
         {appDefinitions.map((app) => (
          <div key={app.id} className="p-3 bg-gray-50 rounded-lg border border-gray-200 flex items-center gap-4">
             <span className="text-2xl">{app.icon}</span>
             <div>
                <p className="font-semibold">{app.name}</p>
                <p className="text-xs text-gray-500">{app.category}</p>
             </div>
          </div>
        ))}
    </div>
);

const SystemInfoTab: React.FC = () => {
    const [info, setInfo] = useState({ browser: '', os: '', screen: '', time: '' });
    useEffect(() => {
        const updateInfo = () => {
            setInfo({
                browser: navigator.userAgent,
                os: navigator.platform,
                screen: `${window.screen.width}x${window.screen.height}`,
                time: new Date().toLocaleString(),
            });
        };
        updateInfo();
        const timer = setInterval(updateInfo, 1000);
        return () => clearInterval(timer);
    }, []);

    return (
        <Card title="System Information">
            <div className="font-mono text-xs space-y-2 text-gray-700">
                <p><strong>Browser:</strong> {info.browser}</p>
                <p><strong>OS:</strong> {info.os}</p>
                <p><strong>Screen:</strong> {info.screen}</p>
                <p><strong>Time:</strong> {info.time}</p>
            </div>
        </Card>
    );
};


export const ParametersPanel: React.FC<ParametersPanelProps> = (props) => {
  const [activeTab, setActiveTab] = useState<Tab>('keys');

  const renderContent = () => {
    switch (activeTab) {
      case 'keys': return <KeyManagementTab />;
      case 'network': return <NetworkConfigTab />;
      case 'llm': return <LLMIntegrationTab currentLength={props.currentLength} onUpdateHistoryLength={props.onUpdateHistoryLength} />;
      case 'data': return <DataManagementTab isStatefulnessEnabled={props.isStatefulnessEnabled} onSetStatefulness={props.onSetStatefulness} onExportState={props.onExportState} onImportState={props.onImportState} />;
      case 'personalization': return <PersonalizationTab currentWallpaper={props.currentWallpaper} />;
      case 'advancements': return <AdvancementsTab advancements={props.advancements} />;
      case 'apps': return <ApplicationsTab appDefinitions={props.appDefinitions} />;
      case 'system': return <SystemInfoTab />;
      default: return null;
    }
  };

  return (
    <div className="p-4 bg-gray-50 h-full flex flex-col">
      <div className="border-b border-gray-200 mb-4">
        <nav className="-mb-px flex space-x-1 overflow-x-auto" aria-label="Tabs">
          <TabButton label="🔑 Keys" isActive={activeTab === 'keys'} onClick={() => setActiveTab('keys')} />
          <TabButton label="🌐 Network" isActive={activeTab === 'network'} onClick={() => setActiveTab('network')} />
          <TabButton label="🤖 LLM" isActive={activeTab === 'llm'} onClick={() => setActiveTab('llm')} />
          <TabButton label="💾 Data" isActive={activeTab === 'data'} onClick={() => setActiveTab('data')} />
          <TabButton label="🎨 Personalization" isActive={activeTab === 'personalization'} onClick={() => setActiveTab('personalization')} />
          <TabButton label="🏆 Advancements" isActive={activeTab === 'advancements'} onClick={() => setActiveTab('advancements')}/>
          <TabButton label="📱 Apps" isActive={activeTab === 'apps'} onClick={() => setActiveTab('apps')} />
           <TabButton label="ℹ️ System" isActive={activeTab === 'system'} onClick={() => setActiveTab('system')} />
        </nav>
      </div>
      <div className="flex-grow overflow-y-auto p-2">{renderContent()}</div>
    </div>
  );
};