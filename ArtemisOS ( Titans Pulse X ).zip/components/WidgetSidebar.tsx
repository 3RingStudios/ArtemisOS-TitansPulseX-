/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import {Blueprint} from '../types';
import {BlueprintShowcaseWidget} from './widgets/BlueprintShowcaseWidget';

interface WidgetSidebarProps {
  latestBlueprint: Blueprint | null;
}

export const WidgetSidebar: React.FC<WidgetSidebarProps> = ({
  latestBlueprint,
}) => {
  return (
    <div className="widget-sidebar-container">
      <BlueprintShowcaseWidget blueprint={latestBlueprint} />
    </div>
  );
};
