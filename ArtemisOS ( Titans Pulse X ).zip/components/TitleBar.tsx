/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useEffect, useState} from 'react';
import {playSound, SoundType} from '../services/audioService';

interface TitleBarProps {
  onToggleNotifications: () => void;
  onToggleParameters: () => void;
}

export const TitleBar: React.FC<TitleBarProps> = ({
  onToggleNotifications,
  onToggleParameters,
}) => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleNotificationsClick = () => {
    playSound(SoundType.TRANSITION, 0.5);
    onToggleNotifications();
  };

  const handleParametersClick = () => {
    onToggleParameters();
  };

  return (
    <div className="absolute top-0 left-0 right-0 h-8 bg-black/30 backdrop-blur-md text-white flex items-center justify-between px-4 z-[200] select-none shadow-lg">
      <div className="flex items-center gap-4">
        <div className="font-bold text-sm">🔮 Titan's Pulse X</div>
      </div>
      <div className="flex items-center gap-4 text-sm">
        <button
          onClick={handleNotificationsClick}
          className="hover:bg-white/20 rounded px-2 py-0.5 transition-colors"
          aria-label="Toggle Notifications">
          🔔
        </button>
        <button
          onClick={handleParametersClick}
          className="hover:bg-white/20 rounded px-2 py-0.5 transition-colors"
          aria-label="Toggle System Parameters">
          ⚙️
        </button>
        <span>
          {time.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}
        </span>
      </div>
    </div>
  );
};