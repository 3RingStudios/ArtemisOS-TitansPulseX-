/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useMemo, useState, useRef, useEffect, useCallback} from 'react';
import {AppDefinition} from '../types';
import './RadialMenu.css';

interface RadialMenuProps {
  isOpen: boolean;
  apps: AppDefinition[];
  pinnedAppIds: string[];
  onAppOpen: (appId: string) => void;
  onExecuteAction: (actionId: string, value?: string) => void;
  onClose: () => void;
}

const RADIUS_INNER = 884; // Doubled from 442
const RADIUS_OUTER = 1572; // Doubled from 786
const MENU_SIZE = 5032; // Doubled from 2516
const TASKBAR_HEIGHT = 48;
const ITEM_SIZE = 400; // Corresponds to .radial-menu-item width/height

const getInitialPosition = () => {
    const savedPosition = localStorage.getItem('artemisOS_radialMenuPosition');
    if (savedPosition) {
        try {
            return JSON.parse(savedPosition);
        } catch (e) {
            console.error("Failed to parse saved menu position", e);
        }
    }
    // Default: position the center of the menu such that the bottom-most item
    // is just above the taskbar.
    const yCenter = window.innerHeight - TASKBAR_HEIGHT - (ITEM_SIZE / 2) - 20; // 20px margin
    return {
        x: window.innerWidth / 2 - MENU_SIZE / 2,
        y: yCenter - (MENU_SIZE / 2),
    };
};


export const RadialMenu: React.FC<RadialMenuProps> = ({ isOpen, apps, pinnedAppIds, onAppOpen, onClose }) => {
  const [hoveredApp, setHoveredApp] = useState<AppDefinition | null>(null);
  const [outerRingRotation, setOuterRingRotation] = useState(0);
  const menuRef = useRef<HTMLDivElement>(null);
  const rotationDragStartRef = useRef<{ x: number, y: number, rotation: number } | null>(null);
  const positionDragStartRef = useRef<{ offsetX: number, offsetY: number } | null>(null);

  // Use state for position, initialized from localStorage or default
  const [position, setPosition] = useState(getInitialPosition);
  const positionRef = useRef(position);
  positionRef.current = position; // Keep ref updated on every render to get latest value in event listeners

  const { pinnedApps, otherApps } = useMemo(() => {
    const pinned = pinnedAppIds
      .map(id => apps.find(app => app.id === id))
      .filter((app): app is AppDefinition => !!app);
    const other = apps.filter(app => !pinnedAppIds.includes(app.id));
    return { pinnedApps: pinned, otherApps: other };
  }, [apps, pinnedAppIds]);

  // --- Handlers for ROTATING the outer ring ---
  const handleRotationMouseDown = (e: React.MouseEvent) => {
    if (!menuRef.current) return;
    const rect = menuRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const startAngle = Math.atan2(e.clientY - centerY, e.clientX - centerX) * (180 / Math.PI);
    
    rotationDragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      rotation: outerRingRotation - startAngle,
    };
    window.addEventListener('mousemove', handleRotationMouseMove);
    window.addEventListener('mouseup', handleRotationMouseUp);
  };

  const handleRotationMouseMove = useCallback((e: MouseEvent) => {
    if (!rotationDragStartRef.current || !menuRef.current) return;
    const rect = menuRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const moveAngle = Math.atan2(e.clientY - centerY, e.clientX - centerX) * (180 / Math.PI);
    setOuterRingRotation(rotationDragStartRef.current.rotation + moveAngle);
  }, []);

  const handleRotationMouseUp = useCallback(() => {
    rotationDragStartRef.current = null;
    window.removeEventListener('mousemove', handleRotationMouseMove);
    window.removeEventListener('mouseup', handleRotationMouseUp);
  }, [handleRotationMouseMove]);

  // --- Handlers for DRAGGING the whole menu ---
  const handleMenuDragStart = (e: React.MouseEvent) => {
      e.stopPropagation(); // Prevent rotation from starting
      if (!menuRef.current) return;
      positionDragStartRef.current = {
        offsetX: e.clientX - position.x,
        offsetY: e.clientY - position.y,
      };
      window.addEventListener('mousemove', handleMenuDragMove);
      window.addEventListener('mouseup', handleMenuDragEnd);
  };
  
  const handleMenuDragMove = useCallback((e: MouseEvent) => {
    if (!positionDragStartRef.current) return;
    setPosition({
      x: e.clientX - positionDragStartRef.current.offsetX,
      y: e.clientY - positionDragStartRef.current.offsetY,
    });
  }, []);

  const handleMenuDragEnd = useCallback(() => {
    localStorage.setItem('artemisOS_radialMenuPosition', JSON.stringify(positionRef.current));
    positionDragStartRef.current = null;
    window.removeEventListener('mousemove', handleMenuDragMove);
    window.removeEventListener('mouseup', handleMenuDragEnd);
  }, [handleMenuDragMove]);

  
  useEffect(() => {
      const handleWheel = (e: WheelEvent) => {
          if (isOpen && menuRef.current?.contains(e.target as Node)) {
              e.preventDefault();
              setOuterRingRotation(prev => prev + e.deltaY * 0.1);
          }
      };
      
      window.addEventListener('wheel', handleWheel, { passive: false });
      return () => window.removeEventListener('wheel', handleWheel);
  }, [isOpen]);

  return (
    <div className="radial-menu-overlay" style={{ pointerEvents: isOpen ? 'auto' : 'none' }} onClick={onClose}>
      <div
        ref={menuRef}
        className={`radial-menu-container ${isOpen ? 'open' : ''}`}
        style={{
            top: `${position.y}px`,
            left: `${position.x}px`,
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div 
            className="radial-menu-center-orb"
            onMouseDown={handleMenuDragStart}
        >
          {hoveredApp?.name || "ArtemisOS"}
        </div>
        
        {/* Inner Ring - Pinned Apps */}
        <div className="radial-menu-ring inner-ring">
          {pinnedApps.map((app, i) => {
            const angle = (i / pinnedApps.length) * 360 - 90;
            const transformVal = `rotate(${angle}deg) translateX(${RADIUS_INNER}px) rotate(${-angle}deg)`;
            return (
              <div
                key={app.id}
                className="radial-menu-item"
                style={{ transform: transformVal, ['--transform-val' as any]: transformVal }}
                onClick={() => onAppOpen(app.id)}
                onMouseEnter={() => setHoveredApp(app)}
                onMouseLeave={() => setHoveredApp(null)}
              >
                {app.icon}
              </div>
            );
          })}
        </div>

        {/* Outer Ring - All other apps */}
        <div
          className="radial-menu-ring outer-ring"
          style={{ transform: `rotate(${outerRingRotation}deg)` }}
          onMouseDown={handleRotationMouseDown}
        >
          {otherApps.map((app, i) => {
            const angle = (i / otherApps.length) * 360 - 90;
            // This transform positions the item and keeps it upright relative to the screen
            const transformVal = `rotate(${angle}deg) translateX(${RADIUS_OUTER}px) rotate(-${angle}deg) rotate(-${outerRingRotation}deg)`;
            return (
              <div
                key={app.id}
                className="radial-menu-item"
                style={{ transform: transformVal, ['--transform-val' as any]: transformVal }}
                onClick={() => onAppOpen(app.id)}
                onMouseEnter={() => setHoveredApp(app)}
                onMouseLeave={() => setHoveredApp(null)}
              >
                {app.icon}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
