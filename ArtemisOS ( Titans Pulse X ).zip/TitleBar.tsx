/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useEffect, useState} from 'react';
import {playSound, SoundType} from './services/audioService';
import { TinySystemMonitor } from './components/widgets/TinySystemMonitor';

interface TitleBarProps {
  onToggleNotifications: () => void;
  onToggleParameters: () => void;
  isLiveMode: boolean;
  onToggleLiveMode: () => void;
}

export const TitleBar: React.FC<TitleBarProps> = ({
  onToggleNotifications,
  onToggleParameters,
  isLiveMode,
  onToggleLiveMode,
}) => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleNotificationsClick = () => {
    playSound(SoundType.TRANSITION, 0.5);
    onToggleNotifications();
  };

  const handleParametersClick = () => {
    onToggleParameters();
  };

  const handleLiveModeClick = () => {
    playSound(SoundType.TRANSITION, 0.8);
    onToggleLiveMode();
  };

  return (
    <div className="os-title-bar absolute top-0 left-0 right-0 h-10 flex items-center justify-between px-4 z-[200] select-none">
      <div className="flex items-center gap-4">
        <div className="os-title-bar-title text-sm">🔮 Titan's Pulse X</div>
        <TinySystemMonitor />
        {isLiveMode && (
          <div className="os-live-indicator flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-bold animate-pulse">
            <span>🔴</span>
            <span>LIVE</span>
          </div>
        )}
      </div>
      <div className="flex items-center gap-4 text-sm">
        <button
          onClick={handleLiveModeClick}
          className="os-title-bar-button px-2 py-0.5 text-xs font-semibold"
          aria-label="Toggle Live Mode">
          Go Live
        </button>
        <button
          onClick={handleNotificationsClick}
          className="os-title-bar-button px-2 py-0.5"
          aria-label="Toggle Notifications">
          🔔
        </button>
        <button
          onClick={handleParametersClick}
          className="os-title-bar-button px-2 py-0.5"
          aria-label="Toggle System Parameters">
          ⚙️
        </button>
        <span>
          {time.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}
        </span>
      </div>
    </div>
  );
};