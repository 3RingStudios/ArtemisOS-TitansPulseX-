/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import React, {useEffect, useRef} from 'react';
import {InteractionData} from './types';

interface GeneratedContentProps {
  htmlContent: string;
  onInteract: (data: InteractionData) => void;
  appContext: string | null;
  isLoading: boolean; // Added isLoading prop
}

export const GeneratedContent: React.FC<GeneratedContentProps> = ({
  htmlContent,
  onInteract,
  appContext,
  isLoading,
}) => {
  const contentRef = useRef<HTMLDivElement>(null);
  // Use a ref to track which content's scripts have been executed.
  const scriptsExecutedRef = useRef<string | null>(null);

  useEffect(() => {
    const container = contentRef.current;
    if (!container) return;

    const handleClick = (event: MouseEvent) => {
      let targetElement = event.target as HTMLElement;

      while (
        targetElement &&
        targetElement !== container &&
        !targetElement.dataset.interactionId
      ) {
        targetElement = targetElement.parentElement as HTMLElement;
      }

      if (targetElement && targetElement.dataset.interactionId) {
        event.preventDefault();

        let interactionValue: string | undefined =
          targetElement.dataset.interactionValue;

        if (targetElement.dataset.valueFrom) {
          const inputElement = document.getElementById(
            targetElement.dataset.valueFrom,
          ) as HTMLInputElement | HTMLTextAreaElement;
          if (inputElement) {
            interactionValue = inputElement.value;
          }
        }

        const interactionData: InteractionData = {
          id: targetElement.dataset.interactionId,
          type: targetElement.dataset.interactionType || 'generic_click',
          value: interactionValue,
          elementType: targetElement.tagName.toLowerCase(),
          elementText: (
            targetElement.textContent ||
            (targetElement as HTMLInputElement).value ||
            ''
          )
            .trim()
            .substring(0, 75),
          appContext: appContext,
        };
        onInteract(interactionData);
      }
    };

    container.addEventListener('click', handleClick);

    if (isLoading) {
      // While loading, ensure we reset the ref. This makes sure that when loading completes,
      // the scripts in the final content will be processed.
      scriptsExecutedRef.current = null;
    } else {
      // Process scripts only when loading is complete and the content is new.
      if (htmlContent !== scriptsExecutedRef.current) {
        const scripts = Array.from(container.getElementsByTagName('script'));

        scripts.forEach((script) => {
          // The node replacement trick for running scripts can throw uncatchable
          // SyntaxErrors if the script content is malformed. Using `new Function()`
          // allows us to wrap the execution in a try-catch block.
          try {
            if (script.innerHTML) {
              const scriptFunction = new Function(script.innerHTML);
              scriptFunction.call(window); // Execute in global context
            }
          } catch (e) {
            console.error(
              'Error parsing or executing script. A syntax error likely exists in the LLM-generated code.',
              {
                scriptContent:
                  script.innerHTML.substring(0, 500) +
                  (script.innerHTML.length > 500 ? '...' : ''),
                error: e,
              },
            );
            // Optionally disable the broken script to prevent it from causing other issues.
            script.type = 'text/plain';
          }
        });

        // Mark this content's scripts as having been processed.
        scriptsExecutedRef.current = htmlContent;
      }
    }

    return () => {
      container.removeEventListener('click', handleClick);
    };
  }, [htmlContent, onInteract, appContext, isLoading]);

  return (
    <div
      ref={contentRef}
      className="w-full h-full overflow-y-auto"
      dangerouslySetInnerHTML={{__html: htmlContent}}
    />
  );
};