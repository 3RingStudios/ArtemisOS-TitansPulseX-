/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

self.onmessage = function(e) {
  const { task, dataSize } = e.data;
  
  if (task === 'start') {
    self.postMessage({ type: 'log', message: `Worker received task. Processing ${dataSize} records...` });
    
    let progress = 0;
    // How much progress each "record" makes toward 100%
    const interval = 100 / dataSize; 

    for (let i = 0; i < dataSize; i++) {
      // Simulate heavy work with a busy-wait loop.
      // This will properly lock up the worker thread without using timers.
      const start = Date.now();
      while (Date.now() - start < 0.5) { /* busy wait for 0.5ms */ }
      
      progress += interval;
      
      // Report progress back to the main thread periodically to avoid flooding it.
      // Report roughly 20 times during the process.
      if (i % Math.floor(dataSize / 20) === 0 || i === dataSize - 1) {
          self.postMessage({ type: 'progress', progress: Math.min(100, progress) });
      }
    }
    
    self.postMessage({ type: 'log', message: 'Processing complete.' });
    self.postMessage({ type: 'done' });
  }
};