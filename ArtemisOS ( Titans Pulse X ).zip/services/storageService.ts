/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */

import { AppState } from '../types';

const dbName = "ArtemisOS-StateDB";
const storeName = "OsStateStore";
const stateKey = "mainState";
const dbVersion = 1;

const openDB = (): Promise<IDBDatabase> => {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(dbName, dbVersion);
        request.onupgradeneeded = () => {
            const db = request.result;
            if (!db.objectStoreNames.contains(storeName)) {
                 db.createObjectStore(storeName);
            }
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
};

export const saveOsState = async (state: AppState): Promise<void> => {
    try {
        const db = await openDB();
        const tx = db.transaction(storeName, 'readwrite');
        const store = tx.objectStore(storeName);
        store.put(state, stateKey);
        await new Promise(resolve => tx.oncomplete = resolve);
    } catch (error) {
        console.error("Failed to save OS state to IndexedDB:", error);
    }
};

export const loadOsState = async (): Promise<AppState | null> => {
    try {
        const db = await openDB();
        const tx = db.transaction(storeName, 'readonly');
        const store = tx.objectStore(storeName);
        const request = store.get(stateKey);
        
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result || null);
            request.onerror = () => {
                console.error("Failed to load OS state from IndexedDB:", request.error);
                reject(request.error);
            };
        });
    } catch (error) {
        console.error("Failed to open IndexedDB for loading state:", error);
        return null;
    }
};