/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */

export enum SoundType {
  OPEN = 'open',
  CLOSE = 'close',
  CLICK = 'click',
  TRANSITION = 'transition',
}

const soundFiles: Record<SoundType, string> = {
  [SoundType.OPEN]: '/sounds/open.mp3',
  [SoundType.CLOSE]: '/sounds/close.mp3',
  [SoundType.CLICK]: '/sounds/click.mp3',
  [SoundType.TRANSITION]: '/sounds/transition.mp3',
};

/**
 * Plays a sound effect from the /public/sounds directory.
 * @param sound The type of sound to play.
 * @param volume The volume to play the sound at (0.0 to 1.0).
 */
export function playSound(sound: SoundType, volume = 0.7) {
  try {
    const soundPath = soundFiles[sound];
    if (!soundPath) {
      console.warn(`Sound type "${sound}" not found.`);
      return;
    }
    // Create a new Audio object for each playback to allow for overlapping sounds.
    const audio = new Audio(soundPath);
    audio.volume = volume;
    audio.play().catch((error) => {
      // This can happen if the user hasn't interacted with the page yet.
      console.warn(`Could not play sound "${sound}":`, error.message);
    });
  } catch (error) {
    console.error('Error playing sound:', error);
  }
}
