/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */

// Declare TensorFlow.js and MobileNet as they are loaded from CDN script tags
declare const tf: any;
declare const mobilenet: any;

let model: any | null = null;
let isLoading = false;

/**
 * Loads the MobileNet model. Will only execute once.
 */
export async function loadModel(): Promise<void> {
  if (model || isLoading) return;

  if (typeof tf === 'undefined' || typeof mobilenet === 'undefined') {
    console.error('TensorFlow.js or MobileNet not loaded. Ensure scripts are in index.html.');
    throw new Error('Local AI libraries not found.');
  }

  isLoading = true;
  try {
    console.log('Loading local AI model...');
    // Force WASM backend for better performance and to demonstrate the concept.
    await tf.setBackend('wasm');
    await tf.ready();
    model = await mobilenet.load();
    console.log('Local AI model loaded successfully.');
  } catch (error) {
    console.error('Failed to load local AI model:', error);
    // Fallback to WebGL if Wasm fails
    try {
        await tf.setBackend('webgl');
        await tf.ready();
        model = await mobilenet.load();
        console.log('Local AI model loaded successfully with WebGL backend.');
    } catch (webglError) {
         console.error('Failed to load local AI model with WebGL backend:', webglError);
         throw new Error('Could not initialize any local AI backend.');
    }
  } finally {
      isLoading = false;
  }
}

/**
 * Classifies an image using the locally loaded MobileNet model.
 * @param imageElement The image, video, or canvas element to classify.
 * @returns A string describing the top prediction.
 */
export async function classifyImage(imageElement: HTMLImageElement | HTMLVideoElement | HTMLCanvasElement): Promise<string> {
  if (!model) {
    await loadModel();
  }
  if (!model) {
      throw new Error("Local AI model is not available.");
  }

  const predictions = await model.classify(imageElement);
  if (predictions && predictions.length > 0) {
    const topPrediction = predictions[0];
    return `${topPrediction.className} (confidence: ${(topPrediction.probability * 100).toFixed(1)}%)`;
  }
  return 'Could not classify image locally.';
}