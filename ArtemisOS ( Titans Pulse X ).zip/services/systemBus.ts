/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */

type Listener = (data?: any) => void;

class SystemBus {
  private events: Record<string, Listener[]> = {};

  on(eventName: string, listener: Listener): () => void {
    if (!this.events[eventName]) {
      this.events[eventName] = [];
    }
    this.events[eventName].push(listener);

    // Return a function to unsubscribe
    return () => this.off(eventName, listener);
  }

  emit(eventName: string, data?: any) {
    if (this.events[eventName]) {
      this.events[eventName].forEach((listener) => listener(data));
    }
  }

  off(eventName: string, listener: Listener) {
    if (!this.events[eventName]) return;
    this.events[eventName] = this.events[eventName].filter(
      (l) => l !== listener,
    );
  }
}

// Export a singleton instance
export const systemBus = new SystemBus();
