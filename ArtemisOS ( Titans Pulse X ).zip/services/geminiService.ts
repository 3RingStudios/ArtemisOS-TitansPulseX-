/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import {GoogleGenAI} from '@google/genai';
import {
  APP_DEFINITIONS_CONFIG,
  CONVERSATIONAL_AI_PROMPT,
  getSystemPrompt,
} from '../constants'; // Import getSystemPrompt and APP_DEFINITIONS_CONFIG
import {ChatMessage, InteractionData} from '../types';

if (!process.env.API_KEY) {
  // This is a critical error. In a real app, you might throw or display a persistent error.
  // For this environment, logging to console is okay, but the app might not function.
  console.error(
    'API_KEY environment variable is not set. The application will not be able to connect to the Gemini API.',
  );
}

const ai = new GoogleGenAI({apiKey: process.env.API_KEY!}); // The "!" asserts API_KEY is non-null after the check.

export async function* streamAppFromDroppedFiles(
  filenames: string[],
): AsyncGenerator<string, void, void> {
  const model = 'gemini-2.5-flash';

  if (!process.env.API_KEY) {
    yield 'API Key not configured.';
    return;
  }

  const systemInstruction = `You are the AI core for Titan's Pulse X, specializing in on-the-fly application synthesis from ANY file type.
The user has just dropped files onto the desktop: ${filenames.join(
    ', ',
  )}.
Your task is to analyze the file extensions (.js, .py, .zip, .rar, .uasset, .obj, .mp3, etc.), infer the user's intent, and generate a new, relevant applet for the OS.
Your response MUST follow this format STRICTLY:
1. An HTML log detailing your analysis and the synthesis process.
2. A \`<script>\` tag that calls \`window.systemBus.emit('register_new_app', {...})\`.
You must invent a creative name, a single emoji icon, a 'category', and a concise \`systemPrompt\` for the new application. The applet should be useful and sophisticated. For example, if you see a '.py' file, create a Python script runner. If you see a '.uasset' or '.obj', create a 3D model viewer. If you see audio files, create a music player. **IMPORTANT**: The JavaScript object passed to \`window.systemBus.emit\` must be valid. Ensure any strings, especially the multi-line \`systemPrompt\`, are properly escaped using backticks (\`) or by escaping newlines (\\n).`;

  const userPrompt = `Synthesize an applet from the dropped files.`;

  try {
    const response = await ai.models.generateContentStream({
      model,
      contents: userPrompt,
      config: {
        systemInstruction,
      },
    });

    for await (const chunk of response) {
      if (chunk.text) {
        yield chunk.text;
      }
    }
  } catch (error: any) {
    console.error('Error in streamAppFromDroppedFiles:', error);
    yield `Error: Could not synthesize app from files.`;
  }
}


export async function* streamText(
  prompt: string,
): AsyncGenerator<string, void, void> {
  const model = 'gemini-2.5-flash';
  if (!process.env.API_KEY) {
    yield `Error: API_KEY is not configured.`;
    return;
  }
  try {
    const response = await ai.models.generateContentStream({
      model,
      contents: prompt,
    });
    for await (const chunk of response) {
      if (chunk.text) {
        yield chunk.text;
      }
    }
  } catch (error: any) {
    console.error('Error streaming text from AI:', error);
    yield `Error: ${error.message}`;
  }
}

export async function* streamAIResponse(
  chatHistory: ChatMessage[],
): AsyncGenerator<string, void, void> {
  const model = 'gemini-2.5-flash';

  if (!process.env.API_KEY) {
    yield `{"error": "API_KEY is not configured."}`;
    return;
  }

  const userPrompt = chatHistory.map(message => `${message.sender}: ${message.text}`).join('\n');

  try {
    const response = await ai.models.generateContentStream({
      model,
      contents: userPrompt,
      config: {
        systemInstruction: CONVERSATIONAL_AI_PROMPT,
        tools: [{googleSearch: {}}],
      },
    });

    for await (const chunk of response) {
      if (chunk.text) {
        yield chunk.text;
      }
    }
  } catch (error: any) {
    console.error('Error streaming from Conversational AI:', error);
    const errorMessage =
      error?.message || 'An unexpected error occurred.';
    yield `{"error": "${errorMessage.replace(/"/g, "'")}"}`; // Basic JSON escaping
  }
}

export async function* streamCodeHelperResponse(
  codeOrPrompt: string,
  mode: 'explain' | 'refactor' | 'generate',
): AsyncGenerator<string, void, void> {
  const model = 'gemini-2.5-flash';

  if (!process.env.API_KEY) {
    yield '/* API Key not configured. */';
    return;
  }

  let systemInstruction = `You are an expert AI code assistant integrated into an IDE.`;
  let userPrompt = '';

  switch (mode) {
    case 'explain':
      systemInstruction += ` Your task is to explain the provided code snippet clearly and concisely. Use markdown for formatting.`;
      userPrompt = `Explain the following code:\n\n\`\`\`\n${codeOrPrompt}\n\`\`\``;
      break;
    case 'refactor':
      systemInstruction += ` Your task is to refactor the provided code for clarity, efficiency, and best practices. Respond with the improved code inside a single markdown code block, followed by a brief explanation of the changes.`;
      userPrompt = `Refactor the following code:\n\n\`\`\`\n${codeOrPrompt}\n\`\`\``;
      break;
    case 'generate':
      systemInstruction += ` Your task is to generate code based on the user's description. The response should contain only the generated code inside a single markdown code block. Do not add any explanations unless specifically asked.`;
      userPrompt = `Generate code for the following description: "${codeOrPrompt}"`;
      break;
  }

  try {
    const response = await ai.models.generateContentStream({
      model,
      contents: userPrompt,
      config: {
        systemInstruction,
      },
    });

    for await (const chunk of response) {
      if (chunk.text) {
        yield chunk.text;
      }
    }
  } catch (error: any) {
    console.error('Error in streamCodeHelperResponse:', error);
    yield `/* Error: ${error.message} */`;
  }
}

export async function generateImageFromPrompt(
  prompt: string,
): Promise<{url: string; isFallback: boolean}> {
  const model = 'imagen-3.0-generate-002';

  if (!process.env.API_KEY) {
    throw new Error('API Key not configured.');
  }

  try {
    const response = await ai.models.generateImages({
      model,
      prompt,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/jpeg',
        aspectRatio: '1:1',
      },
    });

    if (response.generatedImages && response.generatedImages.length > 0) {
      const base64ImageBytes: string =
        response.generatedImages[0].image.imageBytes;
      const imageUrl = `data:image/jpeg;base64,${base64ImageBytes}`;
      return {url: imageUrl, isFallback: false};
    } else {
      throw new Error('No image was generated by the API.');
    }
  } catch (error: any) {
    console.error('Error in generateImageFromPrompt, using fallback:', error);
    // Fallback logic
    const fallbackUrl = `https://source.unsplash.com/512x512/?${encodeURIComponent(
      prompt,
    )}`;
    return {url: fallbackUrl, isFallback: true};
  }
}

export async function* streamAppContent(
  interactionHistory: InteractionData[],
  currentMaxHistoryLength: number, // Receive current max history length
  appSystemPrompt?: string,
): AsyncGenerator<string, void, void> {
  const model = 'gemini-2.5-flash'; // Updated model

  if (!process.env.API_KEY) {
    yield `<div class="p-4 text-red-700 bg-red-100 rounded-lg">
      <p class="font-bold text-lg">Configuration Error</p>
      <p class="mt-2">The API_KEY is not configured. Please set the API_KEY environment variable.</p>
    </div>`;
    return;
  }

  // Handle special case for Evolutionary Vault to trigger web search and blueprint emission
  const isEvolveInteraction =
    interactionHistory[0]?.appContext === 'evolutionary_vault_app';
  if (isEvolveInteraction) {
    const prompt = `User command: Evolve a new technology theory based on recent scientific papers. Current interaction: ${JSON.stringify(
      interactionHistory[0],
    )}`;

    // Use the specific system prompt for the Evolutionary Vault
    const systemInstruction = APP_DEFINITIONS_CONFIG.find(
      (app) => app.id === 'evolutionary_vault_app',
    )?.systemPrompt;
    if (!systemInstruction) {
      yield 'Error: Evolutionary Vault system prompt not found.';
      return;
    }

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        systemInstruction,
        tools: [{googleSearch: {}}],
      },
    });

    const fullContent = response.text;
    
    // The 'new_blueprint_generated' event is emitted by a script tag inside fullContent,
    // which is handled by the GeneratedContent component on the frontend.
    
    yield fullContent;
    return;
  }


  if (interactionHistory.length === 0) {
    yield `<div class="p-4 text-orange-700 bg-orange-100 rounded-lg">
      <p class="font-bold text-lg">No interaction data provided.</p>
    </div>`;
    return;
  }

  // Use the specific app prompt if provided, otherwise use the main system prompt.
  const systemInstruction = appSystemPrompt || getSystemPrompt(currentMaxHistoryLength);

  const currentInteraction = interactionHistory[0];
  // pastInteractions already respects currentMaxHistoryLength due to slicing in App.tsx
  const pastInteractions = interactionHistory.slice(1);

  const currentElementName =
    currentInteraction.elementText ||
    currentInteraction.id ||
    'Unknown Element';
  let currentInteractionSummary = `Current User Interaction: Clicked on '${currentElementName}' (Type: ${currentInteraction.type || 'N/A'}, ID: ${currentInteraction.id || 'N/A'}).`;
  if (currentInteraction.value) {
    // For 'synthesize_applet', we need to create a more descriptive prompt
    if (currentInteraction.id === 'synthesize_applet') {
      const components = (currentInteraction.value || '').split(',').map(id => APP_DEFINITIONS_CONFIG.find(app => app.id === id)?.name || id);
      currentInteractionSummary = `Current User Interaction: Synthesize a new app by combining the capabilities of the following components: ${components.join(', ')}. Your primary task is to generate the HTML log of this process AND the script to register the new app, following rule #8 of your core directives precisely. Invent a new, creative, synergistic application. **IMPORTANT**: The JavaScript object passed to \`window.systemBus.emit\` must be valid. Ensure any strings, especially the multi-line \`systemPrompt\`, are properly escaped using backticks (\`) or by escaping newlines (\\n).`;
    } else {
      currentInteractionSummary += ` Associated value: '${currentInteraction.value.substring(0, 100)}'.`;
    }
  }


  const currentAppDef = APP_DEFINITIONS_CONFIG.find(
    (app) => app.id === currentInteraction.appContext,
  );
  const currentAppContext = currentInteraction.appContext
    ? `Current App Context: '${currentAppDef?.name || currentInteraction.appContext}'.`
    : 'No specific app context for current interaction.';

  let historyPromptSegment = '';
  if (pastInteractions.length > 0) {
    // The number of previous interactions to mention in the prompt text.
    const numPrevInteractionsToMention =
      currentMaxHistoryLength - 1 > 0 ? currentMaxHistoryLength - 1 : 0;
    historyPromptSegment = `\n\nPrevious User Interactions (up to ${numPrevInteractionsToMention} most recent, oldest first in this list segment but chronologically before current):`;

    // Iterate over the pastInteractions array, which is already correctly sized
    pastInteractions.forEach((interaction, index) => {
      const pastElementName =
        interaction.elementText || interaction.id || 'Unknown Element';
      const appDef = APP_DEFINITIONS_CONFIG.find(
        (app) => app.id === interaction.appContext,
      );
      const appName = interaction.appContext
        ? appDef?.name || interaction.appContext
        : 'N/A';
      historyPromptSegment += `\n${index + 1}. (App: ${appName}) Clicked '${pastElementName}' (Type: ${interaction.type || 'N/A'}, ID: ${interaction.id || 'N/A'})`;
      if (interaction.value) {
        historyPromptSegment += ` with value '${interaction.value.substring(0, 50)}'`;
      }
      historyPromptSegment += '.';
    });
  }

  const userPrompt = `
${currentInteractionSummary}
${currentAppContext}
${historyPromptSegment}

Full Context for Current Interaction (for your reference, primarily use summaries and history):
${JSON.stringify(currentInteraction, null, 1)}

Generate the HTML content for the window's content area only:`;

  const MAX_RETRIES = 6;
  let attempt = 0;
  let delay = 3000; // Start with a 3-second delay

  while (attempt < MAX_RETRIES) {
    try {
      const response = await ai.models.generateContentStream({
        model: model,
        contents: userPrompt,
        config: {
          systemInstruction: systemInstruction,
        },
      });

      // On success, stream the content and exit the loop
      for await (const chunk of response) {
        if (chunk.text) {
          yield chunk.text;
        }
      }
      return; // Success, exit generator
    } catch (error: any) {
      // Improved rate limit error detection
      const errorString = (error?.message || String(error)).toLowerCase();
      const isRateLimitError =
        errorString.includes('429') ||
        errorString.includes('resource_exhausted');

      if (isRateLimitError && attempt < MAX_RETRIES - 1) {
        const waitTime = (delay / 1000).toFixed(1);
        console.warn(
          `Rate limit hit. Retrying in ${waitTime}s... (Attempt ${
            attempt + 1
          })`,
        );
        yield `<div class="p-2 my-2 text-orange-700 bg-orange-100 rounded-lg border border-orange-200">
                  <p class="font-semibold">Gemini API rate limit reached. Retrying...</p>
                  <p>Attempt ${attempt + 1}/${
                    MAX_RETRIES - 1
                  }. Waiting ${waitTime}s.</p>
              </div>`;
        await new Promise((res) => setTimeout(res, delay));
        // Exponential backoff with jitter
        delay = delay * 1.5 + Math.random() * 1000;
        attempt++;
      } else {
        // This was the last attempt or not a rate-limit error
        console.error('Error streaming from Gemini after retries:', error);

        let displayError =
          'An unexpected error occurred while generating content.';
        if (isRateLimitError) {
          displayError =
            'The API quota has been exceeded. Please check your plan and billing details.';
        } else if (error instanceof Error) {
          displayError = error.message;
        } else if (typeof error === 'string') {
          displayError = error;
        }

        yield `<div class="p-4 text-red-700 bg-red-100 rounded-lg">
          <p class="font-bold text-lg">Error Generating Content</p>
          <p class="mt-2"><b>Message:</b> ${displayError}</p>
          <p class="mt-1 text-sm text-gray-600">This may be due to an API key issue, network problem, or rate limits. Please check the developer console for more details.</p>
        </div>`;
        return; // Exit generator after final error
      }
    }
  }
}

export async function identifyImage(
  base64Data: string,
  mimeType: string,
  prompt = 'Identify the object in this image. Be concise and descriptive.',
): Promise<string> {
  const model = 'gemini-2.5-flash';

  if (!process.env.API_KEY) {
    throw new Error('API Key not configured.');
  }

  const imagePart = {
    inlineData: {
      mimeType,
      data: base64Data,
    },
  };

  const textPart = {
    text: prompt,
  };

  try {
    const response = await ai.models.generateContent({
      model,
      contents: { parts: [imagePart, textPart] },
    });
    return response.text;
  } catch (error: any) {
    console.error('Error in identifyImage:', error);
    throw new Error(`Failed to identify image: ${error.message}`);
  }
}

export async function* streamThemeCss(
  description: string,
): AsyncGenerator<string, void, void> {
  const model = 'gemini-2.5-flash';

  if (!process.env.API_KEY) {
    yield '/* API Key not configured. */';
    return;
  }

  const systemInstruction = `You are an expert CSS generator. Your task is to create a complete CSS theme for a futuristic OS called ArtemisOS based on the user's description.
- **IMPORTANT**: Your entire output MUST be valid CSS. Do not include any other text, markdown, or explanations.
- **Structure**: The generated CSS should be wrapped in a single root class called \`.generated-theme\`. All selectors must be nested under this class to avoid global scope pollution (e.g., \`.generated-theme .window-frame\`, \`.generated-theme .llm-button\`).
- **Selectors**: Target the following key classes for theming: \`body\`, \`.os-title-bar\`, \`.taskbar-container\`, \`.start-menu-container\`, \`.window-frame\`, \`.title-bar\`, \`.content-area\`, \`.icon\`, \`.llm-button\`.
- **Styling**: Use modern CSS features. You can use gradients, custom properties, filters, etc. Ensure high contrast and readability.
- **Background**: The main desktop background should be applied to \`body.generated-theme\`. Use complex gradients or subtle background patterns. Do not use external \`url()\` images.`;

  const userPrompt = `Generate a CSS theme for ArtemisOS based on this description: "${description}"`;

  try {
    const response = await ai.models.generateContentStream({
      model,
      contents: userPrompt,
      config: {
        systemInstruction,
      },
    });

    for await (const chunk of response) {
      if (chunk.text) {
        yield chunk.text;
      }
    }
  } catch (error: any) {
    console.error('Error in streamThemeCss:', error);
    yield `/* Error: ${error.message} */`;
  }
}

export async function* streamBootThemeCss(
  mainThemeDescription: string,
  mainThemeCss: string,
): AsyncGenerator<string, void, void> {
  const model = 'gemini-2.5-flash';

  if (!process.env.API_KEY) {
    yield '/* API Key not configured. */';
    return;
  }

  const systemInstruction = `You are an expert CSS generator specializing in boot screens. Your task is to create CSS for a boot screen that complements an existing OS theme.
- **IMPORTANT**: Your entire output MUST be valid CSS. Do not include any other text, markdown, or explanations.
- **Structure**: The generated CSS should be wrapped in a single root class called \`.boot-theme-active\`. All selectors must be nested under this class (e.g., \`.boot-theme-active .boot-container\`).
- **Selectors**: Target these specific classes: \`.boot-container\`, \`.boot-logo\`, \`.boot-title\`, \`.boot-progress-bar-container\`, \`.boot-progress-bar\`, \`.boot-message\`.
- **Styling**: The boot theme should feel like a cohesive part of the main theme. Use similar colors, gradients, and moods. You can add animations. Do not use external \`url()\` images.`;

  const userPrompt = `The main OS theme is described as: "${mainThemeDescription}".
The CSS for the main theme is:
\`\`\`css
${mainThemeCss.substring(0, 1000)}...
\`\`\`
Based on this, generate a complementary CSS theme for the boot screen.`;

  try {
    const response = await ai.models.generateContentStream({
      model,
      contents: userPrompt,
      config: {
        systemInstruction,
      },
    });

    for await (const chunk of response) {
      if (chunk.text) {
        yield chunk.text;
      }
    }
  } catch (error: any) {
    console.error('Error in streamBootThemeCss:', error);
    yield `/* Error: ${error.message} */`;
  }
}

export async function* streamNewAppDefinition(
  description: string,
): AsyncGenerator<string, void, void> {
  const model = 'gemini-2.5-flash';

  if (!process.env.API_KEY) {
    yield 'API Key not configured.';
    return;
  }

  const systemInstruction = `You are an expert AI for on-the-fly application synthesis within ArtemisOS. The user will describe an applet, and you must generate the response.
Your response MUST follow this format STRICTLY:
1. An HTML log detailing your analysis and the synthesis process. Use Tailwind CSS for styling.
2. A \`<script>\` tag that calls \`window.systemBus.emit('register_new_app', {...})\`.
You must invent a creative name, a single emoji icon, a category from ['NeoCor AI System', 'Science & Exploration', 'Development & Utilities', 'Finance & Media', 'Satellite & Drone Systems'], and a concise \`systemPrompt\` for the new application. The \`systemPrompt\` itself should be a set of instructions for another AI that will generate the UI for this new app. **IMPORTANT**: The JavaScript object passed to \`window.systemBus.emit\` must be valid. Ensure any strings, especially the multi-line \`systemPrompt\`, are properly escaped using backticks (\`) or by escaping newlines (\\n).`;

  const userPrompt = `Synthesize an applet from this description: "${description}"`;

  try {
    const response = await ai.models.generateContentStream({
      model,
      contents: userPrompt,
      config: {
        systemInstruction,
      },
    });

    for await (const chunk of response) {
      if (chunk.text) {
        yield chunk.text;
      }
    }
  } catch (error: any) {
    console.error('Error in streamNewAppDefinition:', error);
    yield `<p class="text-red-500">Error: Could not synthesize applet.</p>`;
  }
}