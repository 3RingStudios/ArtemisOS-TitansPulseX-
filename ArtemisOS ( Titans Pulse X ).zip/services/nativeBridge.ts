/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
/**
 * A bridge for interacting with native capabilities.
 * This service encapsulates File System Access APIs, preparing for a
 * seamless transition to a native wrapper like Tauri where
 * these functions are replaced by calls to the native backend.
 */
import { FileSystemItem } from '../types';

// --- Environment Check ---
const isTauri = typeof window !== 'undefined' && !!(window as any).__TAURI__;

// --- Browser Fallback/Mock Implementations ---
const browserMock = (functionName: string, ...args: any[]) => {
    const message = `Tauri API not found. Mocking '${functionName}' with args: ${JSON.stringify(args)}`;
    console.warn(message);
    alert(message + "\n\nFunctionality is limited in browser mode. Run the native .exe for full features.");
}

const browserLinkFolder = async (): Promise<string> => {
    browserMock('linkFolder');
    return "/mock/user/documents";
};

const browserGetDirectoryContents = async (path: string): Promise<FileSystemItem[]> => {
    browserMock('getDirectoryContents', path);
    return [
        { name: 'mock-directory', kind: 'directory', path: `${path}/mock-directory` },
        { name: 'mock-file.txt', kind: 'file', path: `${path}/mock-file.txt` },
        { name: 'script.js', kind: 'file', path: `${path}/script.js` },
        { name: 'document.md', kind: 'file', path: `${path}/document.md` },
    ];
};

const browserCreateNewFolder = async (basePath: string, name: string): Promise<void> => {
    browserMock('createNewFolder', basePath, name);
};

const browserSaveFile = async (dirPath: string, fileName: string, content: string): Promise<void> => {
    browserMock('saveFile', dirPath, fileName, content.substring(0, 50) + '...');
};

const browserOpenFile = async (): Promise<{ path: string; name: string; content: string; }> => {
    browserMock('openFile');
    return { path: '/mock/user/documents/mock-file.txt', name: 'mock-file.txt', content: '// Mock file content\nHello from the browser!' };
};

const browserReadFileContent = async (path: string): Promise<string> => {
    browserMock('readFileContent', path);
    return `// Mock content for ${path}\nTimestamp: ${new Date().toISOString()}`;
};

const browserSaveFileByPath = async (path: string, content: string): Promise<void> => {
    browserMock('saveFileByPath', path, content.substring(0, 50) + '...');
};

const browserSaveFileAs = async (content: string): Promise<{ path: string; name: string; }> => {
    browserMock('saveFileAs', content.substring(0, 50) + '...');
    return { path: '/mock/user/documents/new-mock-file.txt', name: 'new-mock-file.txt' };
};


// --- Exported API Functions ---

export const linkFolder = async (): Promise<string> => {
  if (!isTauri) return browserLinkFolder();
  const { open } = await import('@tauri-apps/api/dialog');
  const selectedPath = await open({ directory: true, multiple: false });
  if (typeof selectedPath === 'string') {
    return selectedPath;
  }
  throw new Error('Folder selection cancelled or failed.');
};

export const getDirectoryContents = async (path: string): Promise<FileSystemItem[]> => {
    if (!isTauri) return browserGetDirectoryContents(path);
    const { readDir } = await import('@tauri-apps/api/fs');
    const { basename } = await import('@tauri-apps/api/path');

    const entries = await readDir(path, { recursive: false });
    const processedEntries = await Promise.all(entries.map(async (entry) => ({
        name: await basename(entry.path), // Use basename to get the name
        kind: entry.children ? 'directory' : 'file',
        path: entry.path,
    })));
    return processedEntries;
};

export const createNewFolder = async (basePath: string, name: string): Promise<void> => {
    if (!isTauri) return browserCreateNewFolder(basePath, name);
    const { join } = await import('@tauri-apps/api/path');
    const { createDir } = await import('@tauri-apps/api/fs');
    const newPath = await join(basePath, name);
    await createDir(newPath, { recursive: true });
};

export const saveFile = async (dirPath: string, fileName: string, content: string): Promise<void> => {
    if (!isTauri) return browserSaveFile(dirPath, fileName, content);
    const { join } = await import('@tauri-apps/api/path');
    const { writeTextFile } = await import('@tauri-apps/api/fs');
    const filePath = await join(dirPath, fileName);
    await writeTextFile(filePath, content);
};

export const openFile = async (): Promise<{ path: string; name: string; content: string; }> => {
  if (!isTauri) return browserOpenFile();
  const { open } = await import('@tauri-apps/api/dialog');
  const { readTextFile } = await import('@tauri-apps/api/fs');
  const { basename } = await import('@tauri-apps/api/path');

  const selectedPath = await open({
    multiple: false,
    filters: [{
        name: 'Text-based Files',
        extensions: ['txt', 'md', 'log', 'js', 'ts', 'json', 'css', 'html', 'xml', 'svg', 'py']
    }]
  });
  if (typeof selectedPath === 'string') {
    const content = await readTextFile(selectedPath);
    const name = await basename(selectedPath);
    return { path: selectedPath, name, content };
  }
  throw new Error('File selection cancelled or failed.');
};

export const readFileContent = async (path: string): Promise<string> => {
    if (!isTauri) return browserReadFileContent(path);
    const { readTextFile } = await import('@tauri-apps/api/fs');
    return await readTextFile(path);
};

export const saveFileByPath = async (path: string, content: string): Promise<void> => {
    if (!isTauri) return browserSaveFileByPath(path, content);
    const { writeTextFile } = await import('@tauri-apps/api/fs');
    await writeTextFile(path, content);
};

export const saveFileAs = async (content: string): Promise<{ path: string; name: string; }> => {
  if (!isTauri) return browserSaveFileAs(content);
  const { save } = await import('@tauri-apps/api/dialog');
  const { writeTextFile } = await import('@tauri-apps/api/fs');
  const { basename } = await import('@tauri-apps/api/path');

  const newPath = await save({
    filters: [{
      name: 'Text-based Files',
      extensions: ['txt', 'md', 'log', 'js', 'ts', 'json', 'css', 'html', 'py']
    }]
  });

  if (newPath) {
    await writeTextFile(newPath, content);
    const name = await basename(newPath);
    return { path: newPath, name };
  }
  throw new Error('Save As operation cancelled or failed.');
};
