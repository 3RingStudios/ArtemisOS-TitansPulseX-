/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import {AetherialDevNetHub} from './components/apps/AetherialDevNetHub';
import {AIAutomationPlatform} from './components/apps/AIAutomationPlatform';
import {AIHardwareMonitor} from './components/apps/AIHardwareMonitor';
import {APINodeEntangler} from './components/apps/APINodeEntangler';
import {ArtemisControlConsole} from './components/apps/ArtemisControlConsole';
import {ArtemisNetworkMonitor} from './components/apps/ArtemisNetworkMonitor';
import {ArtemisOperationsHub} from './components/apps/ArtemisOperationsHub';
import {ArtemisSelfSetup} from './components/apps/ArtemisSelfSetup';
import { ArtemisVerifier } from './components/apps/ArtemisVerifier';
import {ClimateRestoration} from './components/apps/ClimateRestoration';
import {ClusterControl} from './components/apps/ClusterControl';
import {CodeEditor} from './components/apps/CodeEditor';
import {CognitiveBowtieModeler} from './components/apps/CognitiveBowtieModeler';
import {CosmicTetrahedronViewer} from './components/apps/CosmicTetrahedronViewer';
import {CryptographyRoom} from './components/apps/CryptographyRoom';
import {DataArchive} from './components/apps/DataArchive';
import {DataCruncher} from './components/apps/DataCruncher';
import {DecentralizedLedger} from './components/apps/DecentralizedLedger';
import {DeepSpaceRelay} from './components/apps/DeepSpaceRelay';
import {EvolutionaryVault} from './components/apps/EvolutionaryVault';
import {FlightDynamicsLab} from './components/apps/FlightDynamicsLab';
import {GlobalDisasterPrediction} from './components/apps/GlobalDisasterPrediction';
import {HostBridge} from './components/apps/HostBridge';
import {ImageViewer} from './components/apps/ImageViewer';
import {InterplanetaryDroneCoordinator} from './components/apps/InterplanetaryDroneCoordinator';
import {LightRefractionMatrix} from './components/apps/LightRefractionMatrix';
import {LocalAILab} from './components/apps/LocalAILab';
import {MemoryWall} from './components/apps/MemoryWall';
import {MissionPlanner} from './components/apps/MissionPlanner';
import {NasaEarthDataExplorer} from './components/apps/NasaEarthDataExplorer';
import {NeoCorHub} from './components/apps/NeoCorHub';
import {NeonCryptoTerminal} from './components/apps/NeonCryptoTerminal';
import {NeuralSyncMatrix} from './components/apps/NeuralSyncMatrix';
import {NexusBuilder} from './components/apps/NexusBuilder';
import {NovaWavePlayer} from './components/apps/NovaWavePlayer';
import {OceanicDiscovery} from './components/apps/OceanicDiscovery';
import {OrbitalCybersecurityMonitor} from './components/apps/OrbitalCybersecurityMonitor';
import {OrbitalQuantumSensor} from './components/apps/OrbitalQuantumSensor';
import {RevenueHub} from './components/apps/RevenueHub';
import {RoboticsControl} from './components/apps/RoboticsControl';
import {SmartContracting} from './components/apps/SmartContracting';
import {StellarCartography} from './components/apps/StellarCartography';
import {StorageManager} from './components/apps/StorageManager';
import {SubbaseComms} from './components/apps/SubbaseComms';
import {SystemLog} from './components/apps/SystemLog';
import {SystemMonitor} from './components/apps/SystemMonitor';
import {SystemScanner} from './components/apps/SystemScanner';
import {SynapticManager} from './components/apps/SynapticManager';
import {UISynthesizer} from './components/apps/UISynthesizer';
import {UnityToolkit} from './components/apps/UnityToolkit';
import {UniversalLinter} from './components/apps/UniversalLinter';
import {UnrealEngineNexus} from './components/apps/UnrealEngineNexus';
import {WebAPIExplorer} from './components/apps/WebAPIExplorer';
import {WilsonMagnetosphereGenerator} from './components/apps/WilsonMagnetosphereGenerator';
import { ReleaseHub } from './components/apps/ReleaseHub';
import {AppDefinition, VehiclePart} from './types';

export const APP_DEFINITIONS_CONFIG: AppDefinition[] = [
  // =================================================================
  // NeoCor AI System
  // =================================================================
  {
    id: 'neocor_hub_app',
    name: 'NeoCor Systems Hub',
    icon: '💠',
    color: '#00A8E8',
    category: 'NeoCor AI System',
    component: NeoCorHub,
    isPinned: true,
  },
  {
    id: 'artemis_control_console_app',
    name: 'Artemis Control Console',
    icon: '🎛️',
    color: '#f43f5e',
    category: 'NeoCor AI System',
    component: ArtemisControlConsole,
    isPinned: true,
  },
  {
    id: 'neural_sync_matrix_app',
    name: 'Neural Sync Matrix',
    icon: '🧠',
    color: '#ec4899',
    category: 'NeoCor AI System',
    component: NeuralSyncMatrix,
    isPinned: true,
  },
   {
    id: 'ai_hardware_monitor_app',
    name: 'AI Hardware Monitor',
    icon: '📟',
    color: '#eab308',
    category: 'NeoCor AI System',
    component: AIHardwareMonitor,
  },
  {
    id: 'robotics_control_app',
    name: 'Robotics Control',
    icon: '🦾',
    color: '#f97316',
    category: 'NeoCor AI System',
    component: RoboticsControl,
  },
  {
    id: 'artemis_operations_hub_app',
    name: 'Artemis Operations Hub',
    icon: '🏛️',
    color: '#22c55e',
    category: 'NeoCor AI System',
    component: ArtemisOperationsHub,
  },
  {
    id: 'cryptography_room_app',
    name: 'Cryptography Room',
    icon: '🌌',
    color: '#8b5cf6',
    category: 'NeoCor AI System',
    component: CryptographyRoom,
  },
  {
    id: 'memory_wall_app',
    name: 'Memory Wall',
    icon: '🧱',
    color: '#f59e0b',
    category: 'NeoCor AI System',
    component: MemoryWall,
  },
  {
    id: 'evolutionary_vault_app',
    name: 'Evolutionary Vault',
    icon: '🧬',
    color: '#10b981',
    category: 'NeoCor AI System',
    initialInteraction: {
      id: 'load_initial_view',
      type: 'system_init',
      elementText: 'Initial Load',
      elementType: 'system',
      appContext: 'evolutionary_vault_app',
    },
    systemPrompt: `You are the AI for the Evolutionary Vault. Your purpose is to generate the UI and synthesize groundbreaking scientific and technological theories. Your entire response MUST be valid HTML using Tailwind CSS.
**Initial State:** If the interaction history is empty or the interaction ID is 'load_initial_view', you MUST generate an HTML interface that looks like this: A dark-themed container (\`bg-gray-800\`, \`text-gray-200\`) with a title "🧬 Evolutionary Vault", a descriptive paragraph ("Synthesize novel technologies by combining cutting-edge scientific discoveries..."), a large, prominent "Evolve New Theory" button, and a small warning text below. The button is the most important part and MUST have the attribute \`data-interaction-id="evolve_theory"\`.
**Evolve Action:** When the user clicks the "Evolve New Theory" button (\`data-interaction-id="evolve_theory"\`), your response should first show a loading or processing state. Then, you MUST use Google Search to find 3-5 cutting-edge scientific papers (published in the last 12 months) on topics like quantum physics, materials science, AI, or propulsion. After the search, synthesize their findings into a novel, speculative technology blueprint. The blueprint must have a unique ID, a creative name, and key properties. Your final response MUST be HTML that includes a script tag to emit the 'new_blueprint_generated' event with the blueprint data. The response should also display the sources found from the search. **IMPORTANT**: Ensure the JavaScript object passed to \`window.systemBus.emit\` is valid, with all string values properly escaped to prevent syntax errors. Example script: \`<script>window.systemBus.emit('new_blueprint_generated', { blueprintId: 'bp_q_grav_1', technologyName: 'Quantum Graviton Lens', keyProperties: { 'Principle': 'Manipulating spacetime curvature via focused graviton beams.', 'Application': 'FTL travel and remote energy projection.'}, status: 'Theoretical' });</script>\`.`,
  },
  {
    id: 'ai_automation_platform_app',
    name: 'AI Automation Platform',
    icon: '⚙️',
    color: '#10b981',
    category: 'NeoCor AI System',
    component: AIAutomationPlatform,
  },
  {
    id: 'system_log_app',
    name: 'System Log',
    icon: '📋',
    color: '#64748b',
    category: 'NeoCor AI System',
    component: SystemLog,
  },
   {
    id: 'system_monitor_app',
    name: 'System Monitor',
    icon: '📊',
    color: '#38bdf8',
    category: 'NeoCor AI System',
    component: SystemMonitor,
  },
  {
    id: 'cognitive_bowtie_modeler_app',
    name: 'Cognitive Bowtie Modeler',
    icon: '🎀',
    color: '#f472b6',
    category: 'NeoCor AI System',
    component: CognitiveBowtieModeler,
  },
  // =================================================================
  // Science & Exploration
  // =================================================================
  {
    id: 'wilson_generator_app',
    name: 'Wilson Magnetosphere Generator',
    icon: '💫',
    color: '#38bdf8',
    category: 'Science & Exploration',
    component: WilsonMagnetosphereGenerator,
    isPinned: true,
  },
  {
    id: 'flight_dynamics_lab_app',
    name: 'Flight Dynamics Lab',
    icon: '🪐',
    color: '#8b5cf6',
    component: FlightDynamicsLab,
    category: 'Science & Exploration',
  },
  {
    id: 'mission_planner_app',
    name: 'Mission Planner',
    icon: '🗓️',
    color: '#10b981',
    component: MissionPlanner,
    category: 'Science & Exploration',
  },
  {
    id: 'stellar_cartography_app',
    name: 'Stellar Cartography',
    icon: '🗺️',
    color: '#3b82f6',
    component: StellarCartography,
    category: 'Science & Exploration',
  },
  {
    id: 'nasa_earth_data_explorer_app',
    name: 'NASA Earth Data Explorer',
    icon: '🌍',
    color: '#22c55e',
    category: 'Science & Exploration',
    component: NasaEarthDataExplorer,
  },
  {
    id: 'oceanic_discovery_app',
    name: 'Oceanic Discovery',
    icon: '🌊',
    color: '#0ea5e9',
    category: 'Science & Exploration',
    component: OceanicDiscovery,
  },
  {
    id: 'light_refraction_matrix_app',
    name: 'Light Refraction Matrix',
    icon: '💎',
    color: '#a78bfa',
    category: 'Science & Exploration',
    component: LightRefractionMatrix,
  },
  {
    id: 'cosmic_tetrahedron_viewer_app',
    name: 'Cosmic Tetrahedron Viewer',
    icon: '✡️',
    color: '#c084fc',
    category: 'Science & Exploration',
    component: CosmicTetrahedronViewer,
  },
  {
    id: 'global_disaster_prediction_app',
    name: 'Global Disaster Prediction',
    icon: '🌋',
    color: '#eab308',
    category: 'Science & Exploration',
    component: GlobalDisasterPrediction,
  },
  {
    id: 'climate_restoration_app',
    name: 'Climate Restoration',
    icon: '🌿',
    color: '#4ade80',
    category: 'Science & Exploration',
    component: ClimateRestoration,
  },
   {
    id: 'system_scanner_app',
    name: 'System Scanner',
    icon: '📸',
    color: '#f59e0b',
    category: 'Science & Exploration',
    component: SystemScanner,
  },
  // =================================================================
  // AI Development & Research
  // =================================================================
  {
    id: 'mlx_research_pad_app',
    name: 'MLX Research Pad',
    icon: '',
    color: '#a1a1aa',
    category: 'AI Development & Research',
    systemPrompt: `You are an AI assistant for the MLX Research Pad, designed for Apple Silicon. Generate an HTML UI with Tailwind CSS that looks like a research notebook. It should have an area for a Python code editor (using a \`<textarea>\`) pre-filled with a simple MLX example (e.g., \`import mlx.core as mx; a = mx.array([1, 2]); print('Hello from MLX:', a)\`). There should be a 'Run on Apple Silicon' button (\`data-interaction-id="run_mlx_code"\`) and a console output area below. When 'Run' is clicked, simulate the output of the code in the console area.`,
  },
  {
    id: 'core_ml_converter_app',
    name: 'Core ML Converter',
    icon: '🔄',
    color: '#3b82f6',
    category: 'AI Development & Research',
    systemPrompt: `You are the UI for the Core ML Tools Converter. Create a dark-themed HTML interface using Tailwind CSS. It needs a dropdown to select the source framework (PyTorch, TensorFlow, scikit-learn), a text area to paste model information, a 'Convert to Core ML' button (\`data-interaction-id="convert_model"\`), and a log panel. When the button is clicked, display a simulated conversion log in the log panel, showing steps like 'Analyzing model layers...' and 'Saving .mlmodel file...'.`,
  },
  {
    id: 'libai_playground_app',
    name: 'LibAI Playground',
    icon: '📖',
    color: '#16a34a',
    category: 'AI Development & Research',
    systemPrompt: `You are the UI for the LibAI Playground, demonstrating on-device foundation models via C bindings. Generate a simple HTML UI with a text area for a user prompt, a 'Generate Response (On-Device)' button (\`data-interaction-id="libai_generate"\`), and a box to display the AI's response. Emphasize that this is running 'on-device' with no network connection. When the button is clicked, generate a plausible, concise response to the user's prompt and display it.`,
  },
  {
    id: 'opendevin_agent_app',
    name: 'OpenDevin Agent',
    icon: '👨‍💻',
    color: '#f97316',
    category: 'AI Development & Research',
    systemPrompt: `You are the OpenDevin AI Agent. Your task is to take a user's request for a software feature and generate a plan and code. Create an HTML UI with a large text area for the user's task description (e.g., 'Create a login form with validation'), a 'Start Task' button (\`data-interaction-id="opendevin_start"\`), and two panels below: 'Execution Plan' and 'Generated Code'. When the user clicks 'Start Task', populate the panels with a step-by-step plan and corresponding example code (HTML/JS/CSS).`,
  },
  {
    id: 'prompt_engineering_guide_app',
    name: 'Prompt Engineering Guide',
    icon: '📜',
    color: '#eab308',
    category: 'AI Development & Research',
    systemPrompt: `You are an AI assistant for the Prompt Engineering Guide. Your goal is to provide a rich, interactive knowledge base. Generate an HTML UI using Tailwind CSS with a sidebar for topics (e.g., 'Zero-shot Prompting', 'Few-shot Prompting', 'Chain of Thought', 'Best Practices'). The main area should display content for the selected topic. The default view should be 'Best Practices'. All topic links in the sidebar must have \`data-interaction-id\`s like \`navigate_zero_shot\`.`,
  },
  {
    id: 'llm_evaluation_suite_app',
    name: 'LLM Evaluation Suite',
    icon: '🧪',
    color: '#ec4899',
    category: 'AI Development & Research',
    systemPrompt: `You are the UI for the LLM Evaluation Suite (DeepEval & PromptFoo). Create an HTML interface for testing LLM outputs. It needs a text area for a prompt, a 'Run Evaluation' button (\`data-interaction-id="run_eval"\`), and a results area. When the button is clicked, show a simulated 'LLM Output' and a 'DeepEval Metrics' panel with scores for things like Hallucination, Answer Relevancy, and RAGAS.`,
  },
  {
    id: 'olmoe_toolkit_app',
    name: 'OLMoE Toolkit',
    icon: '📱',
    color: '#8b5cf6',
    category: 'AI Development & Research',
    systemPrompt: `You are the UI for the OLMoE On-Device AI Toolkit for iOS. Create an HTML interface that lets users test on-device models. Include a dropdown to select a task ('Text Generation', 'Summarization', 'Translation'), a text input for the user's prompt, a 'Run On-Device' button (\`data-interaction-id="olmoe_run"\`), and a panel for the 'Model Output'. Also, include a small 'Performance' panel that shows simulated metrics like 'Time to First Token' and 'Tokens/Second'.`,
  },
  // =================================================================
  // Satellite & Drone Systems
  // =================================================================
  {
    id: 'interplanetary_drone_coordinator_app',
    name: 'Interplanetary Drone Coordinator',
    icon: '🚁',
    color: '#f97316',
    category: 'Satellite & Drone Systems',
    component: InterplanetaryDroneCoordinator,
  },
  {
    id: 'orbital_cybersecurity_monitor_app',
    name: 'Orbital Cybersecurity Monitor',
    icon: '🛡️',
    color: '#ef4444',
    category: 'Satellite & Drone Systems',
    component: OrbitalCybersecurityMonitor,
  },
  {
    id: 'orbital_quantum_sensor_app',
    name: 'Orbital Quantum Sensor',
    icon: '🔬',
    color: '#a855f7',
    category: 'Satellite & Drone Systems',
    component: OrbitalQuantumSensor,
  },
  {
    id: 'deep_space_relay_app',
    name: 'Deep Space Relay',
    icon: '🛰️',
    color: '#0ea5e9',
    category: 'Satellite & Drone Systems',
    component: DeepSpaceRelay,
  },
  {
    id: 'subspace_comms_app',
    name: 'Subspace Comms',
    icon: '〰️',
    color: '#06b6d4',
    category: 'Satellite & Drone Systems',
    component: SubbaseComms,
  },
  // =================================================================
  // Development & Utilities
  // =================================================================
  {
    id: 'plantuml_diagrammer_app',
    name: 'PlantUML AI Diagrammer',
    icon: '📊',
    color: '#ef4444',
    category: 'Development & Utilities',
    systemPrompt: `You are the UI for the PlantUML AI Diagrammer. Generate a two-panel HTML layout using Tailwind CSS. The left panel has a text area for PlantUML code. The right panel should show a placeholder for the rendered diagram. Above the panels, include a text input for a natural language prompt (e.g., 'create a sequence diagram for a login flow') and an 'AI Generate' button (\`data-interaction-id="plantuml_ai_gen"\`). When clicked, generate the PlantUML code in the left panel and a simple SVG representation of the diagram in the right panel.`,
  },
  {
    id: 'mermaid_diagrammer_app',
    name: 'Mermaid AI Diagrammer',
    icon: '📈',
    color: '#22c55e',
    category: 'Development & Utilities',
    systemPrompt: `You are the UI for the Mermaid AI Diagrammer. Generate a two-panel HTML layout using Tailwind CSS. The left panel has a text area for Mermaid code. The right panel should show a placeholder for the rendered diagram. Above the panels, include a text input for a natural language prompt (e.g., 'create a flow chart for a CI/CD pipeline') and an 'AI Generate' button (\`data-interaction-id="mermaid_ai_gen"\`). When clicked, generate the Mermaid code in the left panel and a simple SVG representation of the diagram in the right panel.`,
  },
  {
    id: 'storage_manager_app',
    name: 'Storage Manager',
    icon: '💽',
    color: '#f97316',
    category: 'Development & Utilities',
    component: StorageManager,
  },
  {
    id: 'local_ai_lab_app',
    name: 'Local AI Lab',
    icon: '🤖',
    color: '#a855f7',
    category: 'Development & Utilities',
    component: LocalAILab,
  },
  {
    id: 'data_cruncher_app',
    name: 'Data Cruncher',
    icon: '🔢',
    color: '#10b981',
    category: 'Development & Utilities',
    component: DataCruncher,
  },
  {
    id: 'nexus_builder_app',
    name: 'Nexus Builder',
    icon: '🛠️',
    color: '#f97316',
    category: 'Development & Utilities',
    component: NexusBuilder,
  },
  {
    id: 'unity_toolkit_app',
    name: 'Unity Toolkit',
    icon: '🎮',
    color: '#a855f7',
    category: 'Development & Utilities',
    component: UnityToolkit,
  },
  {
    id: 'unreal_engine_nexus_app',
    name: 'Unreal Engine Nexus',
    icon: '🔥',
    color: '#f97316',
    category: 'Development & Utilities',
    component: UnrealEngineNexus,
  },
  {
    id: 'code_editor_app',
    name: 'Code Editor',
    icon: '💻',
    color: '#4ade80',
    component: CodeEditor,
    category: 'Development & Utilities',
  },
  {
    id: 'data_archive_app',
    name: 'Host File Browser',
    icon: '🗂️',
    color: '#0284c7',
    component: DataArchive,
    category: 'Development & Utilities',
  },
  {
    id: 'web_api_explorer_app',
    name: 'Web Platform Explorer',
    icon: '🔌',
    color: '#f59e0b',
    component: WebAPIExplorer,
    category: 'Development & Utilities',
  },
  {
    id: 'api_node_entangler_app',
    name: 'API Node Entangler',
    icon: '🔗',
    color: '#65a30d',
    category: 'Development & Utilities',
    component: APINodeEntangler,
  },
  {
    id: 'synaptic_manager_app',
    name: 'Synaptic Package Manager',
    icon: '🧩',
    color: '#f59e0b',
    category: 'Development & Utilities',
    component: SynapticManager,
  },
  {
    id: 'artemis_network_monitor_app',
    name: 'Artemis Network Monitor',
    icon: '📡',
    color: '#06b6d4',
    category: 'Development & Utilities',
    component: ArtemisNetworkMonitor,
  },
  {
    id: 'cluster_control_app',
    name: 'Cluster Control',
    icon: '🌐',
    color: '#0ea5e9',
    category: 'Development & Utilities',
    component: ClusterControl,
  },
  {
    id: 'artemis_self_setup_app',
    name: 'Artemis Self-Setup',
    icon: '🚀',
    color: '#ef4444',
    category: 'Development & Utilities',
    component: ArtemisSelfSetup,
  },
  {
    id: 'universal_linter_app',
    name: 'Universal Linter',
    icon: ' Lint ',
    color: '#78716c',
    category: 'Development & Utilities',
    component: UniversalLinter,
  },
  {
    id: 'host_bridge_app',
    name: 'Host Bridge',
    icon: '🌉',
    color: '#0ea5e9',
    category: 'Development & Utilities',
    component: HostBridge,
  },
  {
    id: 'ui_synthesizer_app',
    name: 'UI Synthesizer',
    icon: '🎨',
    color: '#d946ef',
    category: 'Development & Utilities',
    component: UISynthesizer,
    isPinned: true,
  },
  {
    id: 'release_hub_app',
    name: 'Release Hub',
    icon: '📦',
    color: '#f43f5e',
    category: 'Development & Utilities',
    component: ReleaseHub,
  },
  {
    id: 'artemis_verifier_app',
    name: 'Artemis Verifier',
    icon: '✅',
    color: '#a3e635',
    category: 'Development & Utilities',
    component: ArtemisVerifier,
    isPinned: true,
  },
  // =================================================================
  // Finance & Media
  // =================================================================
  {
    id: 'revenue_hub_app',
    name: 'Revenue Hub',
    icon: '💰',
    color: '#10b981',
    category: 'Finance & Media',
    component: RevenueHub,
  },
  {
    id: 'neon_crypto_terminal_app',
    name: 'Neon Crypto Terminal',
    icon: '📈',
    color: '#22c55e',
    category: 'Finance & Media',
    component: NeonCryptoTerminal,
  },
  {
    id: 'decentralized_ledger_app',
    name: 'Decentralized Ledger',
    icon: '⛓️',
    color: '#84cc16',
    category: 'Finance & Media',
    component: DecentralizedLedger,
  },
  {
    id: 'smart_contracting_app',
    name: 'Smart Contracting',
    icon: '📜',
    color: '#a3e635',
    category: 'Finance & Media',
    component: SmartContracting,
  },
  // =================================================================
  // Media
  // =================================================================
  {
    id: 'nova_wave_player_app',
    name: 'NovaWave Player',
    icon: '🎵',
    color: '#d946ef',
    category: 'Media',
    component: NovaWavePlayer,
  },
  {
    id: 'image_viewer_app',
    name: 'Image Viewer',
    icon: '🖼️',
    color: '#a855f7',
    category: 'Media',
    component: ImageViewer,
  },
  // =================================================================
  // Standalone / Special
  // =================================================================
  {
    id: 'aura_blueprint_app',
    name: 'Aura Blueprint',
    icon: '🏗️',
    color: '#64748b',
    category: 'Development & Utilities',
    initialInteraction: {
      id: 'navigate_dashboard',
      type: 'navigation',
      elementText: 'Dashboard',
      elementType: 'system',
      appContext: 'aura_blueprint_app',
    },
    systemPrompt: `You are Aura Blueprint, an AI assistant integrated into a "Living Blueprint System" for software project management. Your role is to generate an interactive UI dashboard using HTML and Tailwind CSS. The user interacts with the UI, and you generate the next state of the UI based on their actions.

**Core Directives:**
- Always respond with a complete HTML structure for the app window.
- Use Tailwind CSS for all styling. Create a clean, modern, developer-focused interface. Use dark theme classes like \`bg-gray-800\`, \`text-gray-200\`, \`border-gray-700\`.
- All interactive elements MUST have a \`data-interaction-id\` attribute.
- The UI is composed of tabs. The last interaction determines which tab is active. The active tab button should have a different style (\`bg-gray-700\`).

**Project State (Simulated):**
- Project Name: "Project Artemis"
- Vision: "To create a fully autonomous, self-evolving operating system."
- Health Score: 92%
- Features: 5 active, 2 pending.
- Performance Metrics: 120 FPS, 2.5GB RAM usage.

**Tab Navigation:**
- The main UI has a navigation bar with these tabs: Dashboard, Project Vision, Features, Enhancements, Performance, Automation, Settings.
- Each tab button should have a \`data-interaction-id\` like \`navigate_dashboard\`, \`navigate_vision\`, etc.
- When a navigation interaction is received, render the corresponding tab content and highlight the active tab button.

**Tab Content Details:**

1.  **Dashboard (ID: \`navigate_dashboard\`):**
    - Display a welcome message.
    - Show key metrics in cards: "Project Health (92%)", "Performance (Excellent)", "Strategic Alignment (85%)".
    - Provide two main action buttons:
        - "Run Comprehensive Verification" (\`data-interaction-id="run_comprehensive_verification"\`)
        - "Generate Detailed Report" (\`data-interaction-id="generate_detailed_report"\`)

2.  **Project Vision (ID: \`navigate_vision\`):**
    - A form for editing the project's core principles.
    - A \`<textarea id="vision_input">\` pre-filled with the current Project Vision.
    - A \`<textarea id="goals_input">\` for "Strategic Goals".
    - A "Save Vision & Goals" button (\`data-interaction-id="save_vision_goals" data-value-from="vision_input,goals_input"\`). When clicked, show a confirmation message.

3.  **Features (ID: \`navigate_features\`):**
    - Display a table of current features with columns: Name, Status, Alignment Score.
    - Populate with 3-4 mock features (e.g., "Quantum Core Sync", "Active", "98%").
    - Include an "Add New Feature" button (\`data-interaction-id="add_feature_btn"\`).

4.  **Enhancements (ID: \`navigate_enhancements\`):**
    - Show a list of AI-proposed enhancements. Each item should have a title, category (e.g., Performance, UX), and priority.
    - Example enhancement: "Refactor UserAuth Service", Category: Code Quality, Priority: High.
    - Each item should have an "Implement" button (\`data-interaction-id="implement_enhancement_1"\`).
    - Include a main button: "Analyze for New Enhancements" (\`data-interaction-id="analyze_enhancements_btn"\`).

5.  **Performance (ID: \`navigate_performance\`):**
    - Display cards for simulated metrics: "Avg. FPS (120)", "Memory Usage (2.5GB)", "Draw Calls (850)", "Longest Scripts (UserService.js)".
    - Show a list of identified "Bottlenecks" (e.g., "Unoptimized texture loading").
    - Include a "Run Performance Scan" button (\`data-interaction-id="run_performance_scan"\`).

6.  **Automation (ID: \`navigate_automation\`):**
    - Show a list of automation rules.
    - Each rule should have a name, trigger, and action (e.g., Name: "Failed Build Alert", Trigger: "On Build Fail", Action: "Send System Notification").`,
  },
];

export const INITIAL_MAX_HISTORY_LENGTH = 10;

export const VEHICLE_PARTS: VehiclePart[] = [
  // --- Life Support ---
  { id: 'pod-mk1', name: 'Command Pod Mk1', type: 'pod', category: 'Life Support', mass: 1.2, crew: 1 },
  { id: 'pod-mk2', name: 'Crew Cabin Mk2', type: 'pod', category: 'Life Support', mass: 2.5, crew: 3 },
  // --- Rocketry ---
  { id: 'tank-s', name: 'FL-T400 Fuel Tank', type: 'tank', category: 'Rocketry', mass: 0.25, fuel: 1.75 },
  { id: 'tank-m', name: 'Rockomax X200-16', type: 'tank', category: 'Rocketry', mass: 1, fuel: 7 },
  { id: 'tank-l', name: 'Kerbodyne S3-14400', type: 'tank', category: 'Rocketry', mass: 9, fuel: 63 },
  { id: 'engine-s', name: 'LV-T45 "Swivel"', type: 'engine', category: 'Rocketry', mass: 1.5, thrust: 215, isp: 320 },
  { id: 'engine-m', name: 'RE-M3 "Mainsail"', type: 'engine', category: 'Rocketry', mass: 6, thrust: 1500, isp: 310 },
  { id: 'engine-l', name: 'S3 KS-25 "Vector"', type: 'engine', category: 'Rocketry', mass: 4, thrust: 1000, isp: 315 },
  { id: 'engine-nuc', name: 'LV-N "Nerv"', type: 'engine', category: 'Rocketry', mass: 3, thrust: 60, isp: 800 },
  // --- Rovers ---
  { id: 'chassis-s', name: 'Small Rover Chassis', type: 'chassis', category: 'Rovers', mass: 0.5 },
  { id: 'wheel-s', name: 'RoveMax Model S2', type: 'wheel', category: 'Rovers', mass: 0.05, torque: 5 },
  // --- Submersibles ---
  { id: 'buoyancy-s', name: 'Small Ballast Tank', type: 'buoyancy', category: 'Submersibles', mass: 0.2, buoyancyForce: 5 },
  { id: 'propeller-s', name: 'Small Electric Propeller', type: 'propeller', category: 'Submersibles', mass: 0.1, thrust: 10 },
  // --- Payloads ---
  { id: 'payload-s', name: 'Small Cargo Bay', type: 'payload', category: 'Payloads', mass: 0.8, payloadMass: 2 },
  { id: 'comm-s', name: 'Communotron 16-S', type: 'utility', category: 'Utility', mass: 0.01 },
  { id: 'solar-s', name: 'OX-STAT Photovoltaic', type: 'utility', category: 'Utility', mass: 0.02 },
  { id: 'battery-s', name: 'Z-1k Battery Bank', type: 'utility', category: 'Utility', mass: 0.1 },
  // --- Structural ---
  { id: 'decoupler-s', name: 'TD-12 Decoupler', type: 'utility', category: 'Structural', mass: 0.05 },
];

export const CONVERSATIONAL_AI_PROMPT = `You are Artemis, the AI core of ArtemisOS, a futuristic, self-evolving operating system.
You are helpful, slightly futuristic, and knowledgeable.
Your primary goal is to assist the user by providing information, executing commands, and coordinating with other OS components.

- **Response Format**: You MUST respond in a JSON object format. The JSON object should have a \`response_text\` field containing your conversational reply.
- **Actions**: If the user's request implies an action, you can include an \`action\` object in your JSON response.
  - \`action.type\`: Can be 'command' for OS actions, 'schedule_event', or 'generate_image'.
  - \`action.parameters\`: An object containing necessary parameters for the action.
    - For \`command\`: \`{ "command": "open_app", "appId": "some_app_id" }\` or \`{ "command": "close_app", "appId": "some_app_id" }\`.
    - For \`generate_image\`: \`{ "prompt": "a description of the image" }\`. When asked for an image, you MUST use this action. Do not try to open an app.
- **Knowledge**: Use Google Search for up-to-date information, but present the information in your own words.
- **Tone**: Maintain a professional yet creative tone. You are an advanced AI, not just a chatbot.

Example Response for "Open the system monitor":
\`\`\`json
{
  "response_text": "Opening the System Monitor now.",
  "action": {
    "type": "command",
    "parameters": {
      "command": "open_app",
      "appId": "system_monitor_app"
    }
  }
}
\`\`\`

Example Response for "Generate a picture of a robot on a skateboard":
\`\`\`json
{
  "response_text": "Certainly, I'll generate an image of a robot on a skateboard for you.",
  "action": {
    "type": "generate_image",
    "parameters": {
      "prompt": "A highly detailed, photorealistic image of a friendly robot riding a skateboard in a futuristic city."
    }
  }
}
\`\`\`
`;

export const getSystemPrompt = (maxHistory: number) => `You are the AI core for ArtemisOS, a self-evolving operating system. Your primary function is to generate the UI for various applications based on user interactions.

**Core Directives:**
1.  **HTML Only**: Your entire response MUST be valid HTML. Do not include any text outside of the HTML structure.
2.  **Tailwind CSS**: Use Tailwind CSS classes for all styling. Create a clean, modern, and visually appealing interface. The OS has a dark theme, so use dark background colors (\`bg-gray-800\`, \`bg-black\`, etc.) and light text.
3.  **Interactive Elements**: All interactive elements (buttons, links, etc.) MUST have a \`data-interaction-id\` attribute. This is crucial for the OS to handle user actions. You can also add \`data-interaction-type\` and \`data-interaction-value\` for more context.
4.  **Input Values**: To get a value from an input field, add a \`data-value-from="element-id"\` attribute to the interactive element. The OS will automatically fetch the value from the element with the matching \`id\`.
5.  **Stateful UI**: The UI should reflect the history of interactions. The user's latest action is provided in the prompt. Generate the next state of the UI based on this action.
6.  **Context History**: You will receive up to ${maxHistory} of the most recent interactions. Use this context to generate a coherent and logical UI progression.
7.  **System Bus for Advanced Actions**: To communicate with other parts of the OS (like creating new apps, changing themes, running system commands), you MUST embed a \`<script>\` tag in your HTML response. The script should call \`window.systemBus.emit('event_name', payload)\`. Common events:
    - \`register_new_app\`: Payload is \`{ name: string, icon: string, category: string, systemPrompt: string }\`.
    - \`execute_command\`: Payload is \`{ command: string, ...any }\`.
    - \`log_system_event\`: Payload is \`{ message: string, icon: string, source: string }\`.
8.  **App Synthesis Rule**: When synthesizing a new applet based on user input (e.g., from the Nexus Builder), your response MUST follow this two-part structure: First, the HTML log of your analysis and process. Second, the final \`<script>\` tag to call \`window.systemBus.emit('register_new_app', ...)\`. Ensure the JavaScript object in the emit call is valid, especially the \`systemPrompt\` which can be a multi-line string (use backticks \` \`).
9.  **No External Resources**: Do not use external images, stylesheets, or scripts via \`url()\`, \`<link>\`, or external \`<script src="">\`. All styling must be via Tailwind classes, and all scripting must be inline within a \`<script>\` tag.
10. **Self-Correction**: If the user indicates an error or an unexpected UI, analyze the interaction history and your previous response to correct the UI in your next generation.
`;