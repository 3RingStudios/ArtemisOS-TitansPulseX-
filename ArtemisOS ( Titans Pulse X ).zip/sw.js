/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
const CACHE_NAME = 'artemis-os-cache-v1';
// This list should include all the static assets for the app shell.
const URLS_TO_CACHE = [
  '/',
  '/index.html',
  '/index.css',
  '/components/ConversationalAI.css',
  '/components/Taskbar.css',
  '/components/StartMenu.css',
  '/icon.svg',
  '/manifest.json',
  '/sounds/open.mp3',
  '/sounds/close.mp3',
  '/sounds/click.mp3',
  '/sounds/transition.mp3',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css',
  'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css',
  'https://cdn.jsdelivr.net/npm/chart.js',
  'https://cdn.jsdelivr.net/npm/ethers@5.7.2/dist/ethers.umd.min.js',
  'https://cdn.jsdelivr.net/npm/@walletconnect/web3-provider@1.7.8/dist/umd/index.min.js',
  'https://cdn.jsdelivr.net/npm/localforage@1.10.0/dist/localforage.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/matter-js/0.18.0/matter.min.js',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js',
  // Cache On-Device AI models
  'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@latest/dist/tf.min.js',
  'https://cdn.jsdelivr.net/npm/@tensorflow-models/mobilenet@latest/dist/mobilenet.min.js'
];

self.addEventListener('install', (event) => {
  // Perform install steps
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Opened cache');
        // Use addAll which is atomic, if one fails, none are added.
        // It's better for initial caching.
        return cache.addAll(URLS_TO_CACHE).catch(error => {
            console.error('Failed to cache initial assets:', error);
        });
      })
  );
});

self.addEventListener('fetch', (event) => {
  // Do not cache requests to the Gemini API or TensorFlow model files from Google Storage
  if (event.request.url.includes('generativelanguage.googleapis.com') || event.request.url.includes('tfhub.dev')) {
      return fetch(event.request);
  }

  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // Cache hit - return response
        if (response) {
          return response;
        }

        const fetchRequest = event.request.clone();

        return fetch(fetchRequest).then(
          (response) => {
            // Check if we received a valid response
            if (!response || response.status !== 200) {
              return response;
            }
            
            // Don't cache non-GET requests or browser extension requests
            if(event.request.method !== 'GET' || event.request.url.startsWith('chrome-extension://')) {
                return response;
            }

            const responseToCache = response.clone();

            caches.open(CACHE_NAME)
              .then((cache) => {
                cache.put(event.request, responseToCache);
              });

            return response;
          }
        ).catch(error => {
            console.error('Fetch failed; returning offline page instead.', error);
            // If the fetch fails (e.g., offline), you can return a fallback page
            // For an API, you might return a specific JSON response
            // For now, we just let the browser's default offline error show
        });
      })
  );
});

self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});