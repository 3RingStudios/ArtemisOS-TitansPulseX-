/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import React, { useState } from 'react';

interface WindowProps {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
  onMinimize: () => void;
  onMaximize: () => void;
  isMaximized?: boolean;
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
  isDraggable: boolean;
  isResizable: boolean;
  onPositionChange: (x: number, y: number) => void;
  onSizeChange: (width: number, height: number) => void;
  onFocus: () => void;
  isActive: boolean;
}

const TitleBarButton: React.FC<{
  onClick: (e: React.MouseEvent) => void;
  children: React.ReactNode;
  ariaLabel: string;
  className?: string;
}> = ({onClick, children, ariaLabel, className}) => (
  <button
    onClick={onClick}
    className={`w-7 h-6 rounded-sm flex items-center justify-center text-white font-bold text-xs transition-colors ${className}`}
    aria-label={ariaLabel}>
    {children}
  </button>
);

export const Window: React.FC<WindowProps> = ({
  title,
  children,
  onClose,
  onMinimize,
  onMaximize,
  isMaximized,
  x,
  y,
  width,
  height,
  zIndex,
  isDraggable,
  isResizable,
  onPositionChange,
  onSizeChange,
  onFocus,
  isActive,
}) => {
  const [isInteracting, setIsInteracting] = useState(false);
  const dragRef = React.useRef({x: 0, y: 0});
  const resizeRef = React.useRef({
    width: 0, height: 0, 
    startX: 0, startY: 0, 
    initialX: 0, initialY: 0
  });

  const draggable = isDraggable && !isMaximized;
  const resizable = isResizable && !isMaximized;

  const handleMouseDown = (e: React.MouseEvent) => {
    e.stopPropagation();
    onFocus();
  };

  const handleDragStart = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!draggable) return;
    onFocus();
    setIsInteracting(true);
    dragRef.current = {
      x: e.clientX - x,
      y: e.clientY - y,
    };
    document.addEventListener('mousemove', handleDragMove);
    document.addEventListener('mouseup', handleDragEnd);
  };

  const handleDragMove = (e: MouseEvent) => {
    const taskbarHeight = 48; // OS Taskbar height
    const windowTitleBarHeight = 36; // Approximate height of the window's own title bar

    let newX = e.clientX - dragRef.current.x;
    let newY = e.clientY - dragRef.current.y;

    // Clamp Y position
    newY = Math.max(0, newY);
    // Prevent window's title bar from going below the taskbar
    newY = Math.min(newY, window.innerHeight - taskbarHeight - windowTitleBarHeight);

    // Clamp X position to keep some part of the window visible
    // Allow some leeway to "hide" a window off the side
    const safetyMargin = 100; // pixels to keep on screen
    newX = Math.max(newX, -width + safetyMargin);
    newX = Math.min(newX, window.innerWidth - safetyMargin);
    
    onPositionChange(newX, newY);
  };

  const handleDragEnd = () => {
    setIsInteracting(false);
    document.removeEventListener('mousemove', handleDragMove);
    document.removeEventListener('mouseup', handleDragEnd);
  };

  const handleResizeStart = (
    e: React.MouseEvent<HTMLDivElement>,
    direction: string,
  ) => {
    if (!resizable) return;
    e.stopPropagation();
    onFocus();
    setIsInteracting(true);
    resizeRef.current = {
      width,
      height,
      startX: e.clientX,
      startY: e.clientY,
      initialX: x,
      initialY: y
    };

    const handleResizeMove = (moveEvent: MouseEvent) => {
      const dx = moveEvent.clientX - resizeRef.current.startX;
      const dy = moveEvent.clientY - resizeRef.current.startY;

      let newWidth = resizeRef.current.width;
      let newHeight = resizeRef.current.height;
      let newX = resizeRef.current.initialX;
      let newY = resizeRef.current.initialY;
      
      if (direction.includes('e')) newWidth += dx;
      if (direction.includes('s')) newHeight += dy;
      if (direction.includes('w')) {
        newWidth -= dx;
        newX += dx;
      }
      if (direction.includes('n')) {
        newHeight -= dy;
        newY += dy;
      }

      const clampedWidth = Math.max(300, newWidth);
      const clampedHeight = Math.max(200, newHeight);

      if (clampedWidth !== newWidth && direction.includes('w')) {
        newX = resizeRef.current.initialX + (resizeRef.current.width - clampedWidth);
      }
      if (clampedHeight !== newHeight && direction.includes('n')) {
        newY = resizeRef.current.initialY + (resizeRef.current.height - clampedHeight);
      }

      onPositionChange(newX, newY);
      onSizeChange(clampedWidth, clampedHeight);
    };

    const handleResizeEnd = () => {
      setIsInteracting(false);
      document.removeEventListener('mousemove', handleResizeMove);
      document.removeEventListener('mouseup', handleResizeEnd);
    };

    document.addEventListener('mousemove', handleResizeMove);
    document.addEventListener('mouseup', handleResizeEnd);
  };

  const windowClasses = `window-frame absolute flex flex-col font-sans ${!isInteracting ? 'transition-all duration-200' : ''} pointer-events-auto ${isMaximized ? 'rounded-none' : 'rounded-xl'}`;

  return (
    <div
      className={windowClasses}
      style={{
        transform: `translate(${x}px, ${y}px)`,
        width: `${width}px`,
        height: `${height}px`,
        zIndex,
      }}
      onMouseDown={handleMouseDown}
      onContextMenu={(e) => e.stopPropagation()}
    >
      {/* Resizers */}
      {resizable && (
        <>
          <div className="absolute -left-1 -top-1 w-3 h-3 cursor-nwse-resize z-10" onMouseDown={(e) => handleResizeStart(e, 'nw')} />
          <div className="absolute -right-1 -top-1 w-3 h-3 cursor-nesw-resize z-10" onMouseDown={(e) => handleResizeStart(e, 'ne')} />
          <div className="absolute -left-1 -bottom-1 w-3 h-3 cursor-nesw-resize z-10" onMouseDown={(e) => handleResizeStart(e, 'sw')} />
          <div className="absolute -right-1 -bottom-1 w-3 h-3 cursor-nwse-resize z-10" onMouseDown={(e) => handleResizeStart(e, 'se')} />
          <div className="absolute left-1 right-1 -top-1 h-2 cursor-ns-resize" onMouseDown={(e) => handleResizeStart(e, 'n')} />
          <div className="absolute left-1 right-1 -bottom-1 h-2 cursor-ns-resize" onMouseDown={(e) => handleResizeStart(e, 's')} />
          <div className="absolute -left-1 top-1 bottom-1 w-2 cursor-ew-resize" onMouseDown={(e) => handleResizeStart(e, 'w')} />
          <div className="absolute -right-1 top-1 bottom-1 w-2 cursor-ew-resize" onMouseDown={(e) => handleResizeStart(e, 'e')} />
        </>
      )}

      {/* Title Bar */}
      <div
        className={`title-bar text-white py-2 px-3 flex justify-between items-center select-none flex-shrink-0 transition-colors ${isMaximized ? 'rounded-t-none' : 'rounded-t-xl'}`}
        style={{cursor: draggable ? 'move' : 'default'}}
        onMouseDown={handleDragStart}
        onDoubleClick={onMaximize}
        >
        <span className="title-bar-text font-semibold text-sm truncate">
          {title}
        </span>
        <div className="flex items-center gap-2">
           <TitleBarButton
            onClick={(e) => { e.stopPropagation(); onMinimize(); }}
            ariaLabel="Minimize"
            className="hover:bg-white/20"
          >
            _
          </TitleBarButton>
          <TitleBarButton
            onClick={(e) => { e.stopPropagation(); onMaximize(); }}
            ariaLabel="Maximize"
            className="hover:bg-white/20"
          >
            {isMaximized ? '⧉' : '☐'}
          </TitleBarButton>
          <TitleBarButton
            onClick={(e) => { e.stopPropagation(); onClose(); }}
            ariaLabel="Close"
            className="hover:bg-red-500"
          >
            ✕
          </TitleBarButton>
        </div>
      </div>

      {/* Content */}
      <div className="content-area flex-grow overflow-y-auto overflow-x-hidden">
        {children}
      </div>
    </div>
  );
};