/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import React, {useCallback, useEffect, useState} from 'react';
import {BootScreen} from './components/BootScreen';
import {AICompanion} from './components/ConversationalAI';
import {GeneratedContent} from './components/GeneratedContent';
import {Icon} from './components/Icon';
import {NotificationSidebar} from './components/NotificationSidebar';
import {ParametersPanel} from './components/ParametersPanel';
import {RadialMenu} from './components/RadialMenu';
import {Taskbar} from './components/Taskbar';
import { Window as AppWindow } from './components/Window';
import {
  APP_DEFINITIONS_CONFIG,
  INITIAL_MAX_HISTORY_LENGTH,
} from './constants';
import {playSound, SoundType} from './services/audioService';
import {
  generateImageFromPrompt,
  streamAIResponse,
  streamAppContent,
  streamAppFromDroppedFiles,
} from './services/geminiService';
import {systemBus} from './services/systemBus';
import {
  Advancement,
  AppDefinition,
  AppInstance,
  AppState,
  AppUsageStats,
  Blueprint,
  ChatMessage,
  InteractionData,
  LogEntry,
  Notification,
} from './types';
import { loadOsState, saveOsState } from './services/storageService';
import { UpdateScreen } from './components/UpdateScreen';

const DesktopView: React.FC<{
  apps: AppDefinition[];
  onAppOpen: (appId: string) => void;
}> = ({apps, onAppOpen}) => (
  <div className="flex flex-wrap content-start p-4">
    {apps.map((app) => (
      <Icon key={app.id} app={app} onInteract={() => onAppOpen(app.id)} />
    ))}
  </div>
);

const App: React.FC = () => {
  const [isBooting, setIsBooting] = useState<boolean>(true);
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [appDefinitions, setAppDefinitions] = useState<AppDefinition[]>(
    APP_DEFINITIONS_CONFIG,
  );
  const [runningApps, setRunningApps] = useState<Record<string, AppInstance>>(
    {},
  );
  const [closedAppCache, setClosedAppCache] = useState<Record<string, InteractionData[]>>({});
  const [activeAppId, setActiveAppId] = useState<string | null>(null);
  const [appUsage, setAppUsage] = useState<AppUsageStats>({});
  const [advancements, setAdvancements] = useState<Advancement[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [systemLog, setSystemLog] = useState<LogEntry[]>([]);
  const [evolutionPoints, setEvolutionPoints] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isParametersOpen, setIsParametersOpen] = useState<boolean>(false);
  const [isParametersMaximized, setIsParametersMaximized] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] =
    useState<boolean>(false);
  const [isStartMenuOpen, setIsStartMenuOpen] = useState<boolean>(false);
  const [isAICompanionOpen, setIsAICompanionOpen] = useState(false);
  const [currentMaxHistoryLength, setCurrentMaxHistoryLength] =
    useState<number>(INITIAL_MAX_HISTORY_LENGTH);
  const [isStatefulnessEnabled, setIsStatefulnessEnabled] =
    useState<boolean>(true);
  const [topZIndex, setTopZIndex] = useState(10);
  const [quantumAnimationsEnabled, setQuantumAnimationsEnabled] =
    useState(true);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [latestBlueprint, setLatestBlueprint] = useState<Blueprint | null>(
    null,
  );
  const [isDragging, setIsDragging] = useState(false);
  const [isLiveMode, setIsLiveMode] = useState(false);
  const [pinnedApps, setPinnedApps] = useState<string[]>(
    APP_DEFINITIONS_CONFIG.filter((app) => app.isPinned).map((app) => app.id),
  );
  const [customThemeCss, setCustomThemeCss] = useState<string | null>(null);
  const [bootThemeCss, setBootThemeCss] = useState<string | null>(null);
  const [wallpaperUrl, setWallpaperUrl] = useState('');

  const logSystemEvent = useCallback((message: string, icon: string, source: string = 'System') => {
    const newLog: LogEntry = {
      id: `log_${Date.now()}`,
      timestamp: Date.now(),
      source,
      message,
      icon,
    };
    setSystemLog((prev) => [newLog, ...prev]);
  }, []);

  const addNotification = useCallback(
    (message: string, icon: string) => {
      const newNotification: Notification = {
        id: `notif_${Date.now()}`,
        timestamp: Date.now(),
        message,
        icon,
      };
      setNotifications((prev) => [newNotification, ...prev]);
      playSound(SoundType.TRANSITION, 0.4);
      if (!isNotificationsOpen) {
        setIsNotificationsOpen(true);
      }
      logSystemEvent(message, icon, 'Notification');
    },
    [isNotificationsOpen, logSystemEvent],
  );

  const addAdvancement = useCallback(
    (message: string) => {
      const newAdvancement: Advancement = {
        id: `adv_${Date.now()}`,
        timestamp: Date.now(),
        message,
      };
      setAdvancements((prev) => {
        const updatedAdvancements = [...prev, newAdvancement];
        localStorage.setItem(
          'artemisOS_advancements',
          JSON.stringify(updatedAdvancements),
        );
        return updatedAdvancements;
      });
      addNotification(message, '🏆');
    },
    [addNotification],
  );

  const addEvolutionPoints = useCallback(
    (points: number) => {
      setEvolutionPoints((prevPoints) => {
        const newTotal = prevPoints + points;
        const milestones = [
          {ep: 10, msg: 'System Core Initialized: Basic functions are online.'},
          {ep: 25, msg: 'Neural Net Synchronized: AI capabilities enhanced.'},
          {
            ep: 50,
            msg: 'Evolution Engine Calibrated: Self-modification unlocked.',
          },
          {
            ep: 100,
            msg: 'Chrono Weaver Activated: System can now perceive its own history.',
          },
          {
            ep: 150,
            msg: 'App Synthesis Unlocked: The OS can now create its own tools.',
          },
        ];

        for (const milestone of milestones) {
          if (prevPoints < milestone.ep && newTotal >= milestone.ep) {
            addAdvancement(milestone.msg);
          }
        }
        return newTotal;
      });
    },
    [addAdvancement],
  );

  const streamAndCacheContent = useCallback(
    async (
      appId: string,
      historyForLlm: InteractionData[],
      appSystemPrompt?: string,
    ) => {
      setIsLoading(true);
      setError(null);
      setRunningApps((prev) => ({
        ...prev,
        [appId]: {...prev[appId], content: ''},
      }));

      let accumulatedContent = '';
      try {
        const stream = streamAppContent(
          historyForLlm,
          currentMaxHistoryLength,
          appSystemPrompt,
        );
        for await (const chunk of stream) {
          accumulatedContent += chunk;
          setRunningApps((prev) => {
            if (!prev[appId]) return prev;
            return {
              ...prev,
              [appId]: {...prev[appId], content: prev[appId].content + chunk},
            };
          });
        }
      } catch (e: any) {
        setError('Failed to stream content from the API.');
        console.error(e);
        accumulatedContent = `<div class="p-4 text-red-600 bg-red-100 rounded-md">Error loading content.</div>`;
        setRunningApps((prev) => ({
          ...prev,
          [appId]: {...prev[appId], content: accumulatedContent},
        }));
      } finally {
        setIsLoading(false);
      }
    },
    [currentMaxHistoryLength],
  );

  const handleInteraction = useCallback(
    async (interactionData: InteractionData) => {
      const targetAppId = interactionData.appContext;
      const targetApp = targetAppId ? runningApps[targetAppId] : null;
      if (!targetApp || isLoading) return;

      playSound(SoundType.CLICK);
      const appDef = appDefinitions.find((def) => def.id === targetApp.id);

      const newHistory: InteractionData[] = [
        interactionData,
        ...targetApp.history.slice(0, currentMaxHistoryLength - 1),
      ];
      setRunningApps((prev) => ({
        ...prev,
        [targetApp.id]: {
          ...targetApp,
          history: newHistory,
          content: '',
        },
      }));
      streamAndCacheContent(
        targetApp.id,
        newHistory,
        appDef?.systemPrompt,
      );
    },
    [
      runningApps,
      streamAndCacheContent,
      currentMaxHistoryLength,
      isLoading,
      appDefinitions,
    ],
  );

  const handleToggleParametersPanel = useCallback(() => {
    playSound(SoundType.TRANSITION);
    const willBeOpen = !isParametersOpen;
    setIsParametersOpen(willBeOpen);
    if (isNotificationsOpen) setIsNotificationsOpen(false);
    if (isStartMenuOpen) setIsStartMenuOpen(false);

    if (willBeOpen) {
      // Bring params to front
      const newZIndex = topZIndex + 1;
      setTopZIndex(newZIndex);
      setActiveAppId('system_parameters'); // Use a special ID
    } else if (activeAppId === 'system_parameters') {
      setActiveAppId(null);
    }
  }, [
    isParametersOpen,
    isNotificationsOpen,
    topZIndex,
    activeAppId,
    isStartMenuOpen,
  ]);

  const bringToFront = (appId: string) => {
    if (runningApps[appId]?.zIndex === topZIndex && activeAppId === appId)
      return;
    const newZIndex = topZIndex + 1;
    setTopZIndex(newZIndex);
    setRunningApps((prev) => ({
      ...prev,
      [appId]: {...prev[appId], zIndex: newZIndex},
    }));
    setActiveAppId(appId);
  };

  const handleAppOpen = useCallback(
    (appId: string, payload?: any) => {
      addEvolutionPoints(2);
      const appDef = appDefinitions.find((app) => app.id === appId);
      if (!appDef) {
        addNotification(`Error: App "${appId}" not found.`, '❌');
        return;
      }

      setAppUsage((prev) => ({
        ...prev,
        [appId]: {openCount: (prev[appId]?.openCount || 0) + 1},
      }));

      if (runningApps[appId]) {
        // App is already running, bring it to front and update payload
        setRunningApps((prev) => ({
          ...prev,
          [appId]: { ...prev[appId], isMinimized: false, payload: payload || prev[appId].payload },
        }));
        bringToFront(appId);
      } else {
        const newZIndex = topZIndex + 1;
        setTopZIndex(newZIndex);
        
        const defaultWidth = appDef.isCli ? 600 : 800;
        const defaultHeight = appDef.isCli ? 400 : 600;

        // Check cache for persistent state before using initial state
        const cachedHistory = closedAppCache[appId];

        const initialHistory = cachedHistory || (appDef.initialInteraction
          ? [appDef.initialInteraction]
          : [
              {
                id: `init_${appId}`,
                type: 'system_init',
                elementText: 'Initial App Load',
                elementType: 'system',
                appContext: appId,
              },
            ]);

        const newApp: AppInstance = {
          id: appId,
          content: '',
          history: initialHistory,
          path: [appId],
          isMinimized: false,
          x: (window.innerWidth / 2) - (defaultWidth / 2),
          y: (window.innerHeight / 2) - (defaultHeight / 2) - 24, // Adjust for taskbar
          width: defaultWidth,
          height: defaultHeight,
          zIndex: newZIndex,
          payload,
          isMaximized: false,
        };
        setRunningApps((prev) => ({...prev, [appId]: newApp}));
        setActiveAppId(appId);
        if (!appDef.component) {
          streamAndCacheContent(appId, newApp.history, appDef.systemPrompt);
        }
      }

      if (isParametersOpen) setIsParametersOpen(false);
      if (isNotificationsOpen) setIsNotificationsOpen(false);
      if (isStartMenuOpen) setIsStartMenuOpen(false);
    },
    [
      addEvolutionPoints,
      appDefinitions,
      runningApps,
      topZIndex,
      isParametersOpen,
      isNotificationsOpen,
      isStartMenuOpen,
      addNotification,
      streamAndCacheContent,
      closedAppCache,
    ],
  );
  
  const handleDrop = useCallback(
    async (event: React.DragEvent<HTMLDivElement>) => {
      event.preventDefault();
      setIsDragging(false);
      playSound(SoundType.TRANSITION);

      const files = event.dataTransfer.files;
      if (files.length === 0) return;

      // Handle wallpaper drop
      if (files.length === 1 && files[0].type.startsWith('image/')) {
        const file = files[0];
        const reader = new FileReader();
        reader.onload = (e) => {
            const dataUrl = e.target?.result as string;
            if (dataUrl.length > 5 * 1024 * 1024) {
                addNotification('Image too large for wallpaper. Please use a smaller file.', '🖼️');
                return;
            }
            addNotification('Desktop wallpaper updated via drop (feature in development).', '🖼️');
            logSystemEvent(`Wallpaper dropped, but animated theme is active.`, '🖼️', 'System');
        };
        reader.onerror = () => {
             addNotification('Failed to read image file.', '❌');
        };
        reader.readAsDataURL(file);
        return; 
      }
      
      const fileList = Array.from(files).map((f) => f.name);
      addNotification(`Analyzing ${files.length} dropped items...`, '🔍');
      logSystemEvent(`Analyzing dropped files: ${fileList.join(', ')}`, '📥', 'File System');


      try {
        let fullContent = '';
        const stream = streamAppFromDroppedFiles(fileList);
        for await (const chunk of stream) {
          fullContent += chunk;
        }

        const tempDiv = document.createElement('div');
        tempDiv.style.display = 'none';
        tempDiv.innerHTML = fullContent;
        document.body.appendChild(tempDiv);
        document.body.removeChild(tempDiv);
      } catch (e) {
        console.error('Failed to process dropped files:', e);
        addNotification('Failed to synthesize app from files.', '❌');
      }
    },
    [addNotification, logSystemEvent],
  );

  const handleAIResponse = useCallback(
    async (history: ChatMessage[]) => {
      let accumulatedJson = '';
      const thinkingMessageId = `ai-thinking-${Date.now()}`;
      
      const thinkingMessage: ChatMessage = {
          id: thinkingMessageId,
          sender: 'ai',
          text: '',
          isThinking: true,
      };

      setChatHistory([...history, thinkingMessage]);

      try {
        const stream = streamAIResponse(history);
        for await (const chunk of stream) {
          accumulatedJson += chunk;
          
           setChatHistory([
            ...history,
            { ...thinkingMessage, text: accumulatedJson.replace(/```json/g, '').replace(/```/g, '') },
          ]);
        }
        
        let parsedResponse;
        try {
            const cleanedJson = accumulatedJson.replace(/```json/g, '').replace(/```/g, '').trim();
            parsedResponse = JSON.parse(cleanedJson);
        } catch (e) {
            console.error('Failed to parse AI JSON response, treating as plain text.', e);
            parsedResponse = { response_text: accumulatedJson };
        }

        const finalText = parsedResponse.response_text || '...';
        const finalMessage: ChatMessage = { id: `ai-response-${Date.now()}`, sender: 'ai', text: finalText };
        const action = parsedResponse.action;

        setChatHistory([...history, finalMessage]);

        if (action && action.type === 'generate_image' && action.parameters?.prompt) {
            const imageMessageId = `ai-image-${Date.now()}`;
            const imageLoadingMessage: ChatMessage = { ...finalMessage, id: imageMessageId, isGeneratingImage: true };
            setChatHistory([...history, imageLoadingMessage]);

            try {
                const { url: imageUrl, isFallback } = await generateImageFromPrompt(action.parameters.prompt);
                
                if (isFallback) {
                    addNotification('Image generation failed. Using a fallback from Unsplash.', '🎨');
                    logSystemEvent(`Gemini image generation failed for prompt: "${action.parameters.prompt}". Using fallback.`, '⚠️', 'AI Companion');
                }
                
                const imageSuccessMessage: ChatMessage = { ...imageLoadingMessage, imageUrl, isGeneratingImage: false };
                setChatHistory([...history, imageSuccessMessage]);
                 systemBus.emit('execute_command', { 
                    command: 'open_app',
                    appId: 'image_viewer_app',
                    payload: { imageUrl, prompt: `${action.parameters.prompt}${isFallback ? ' (Fallback Image)' : ''}` }
                });
            } catch (imgError) {
                console.error("Image generation failed critically", imgError);
                const imageErrorMessage: ChatMessage = { ...imageLoadingMessage, text: `${finalText}\n\n[Image generation failed critically. Check API Key.]`, isGeneratingImage: false };
                setChatHistory([...history, imageErrorMessage]);
            }
        } else if (action && (action.type === 'command' || action.type === 'schedule_event')) {
            systemBus.emit('execute_command', action.parameters);
            if (isAICompanionOpen) setIsAICompanionOpen(false);
        }

      } catch (e) {
        console.error('Error handling AI response:', e);
        setChatHistory([
          ...history,
          {
            id: 'ai-error',
            sender: 'ai',
            text: 'I seem to be having trouble connecting. Please check the console.',
          },
        ]);
      }
    },
    [isAICompanionOpen, addNotification, logSystemEvent],
  );

  const handleUserChatMessage = useCallback((prompt: string) => {
      if (!prompt.trim()) return;

      const userMessage: ChatMessage = {
        id: `user_${Date.now()}`,
        sender: 'user',
        text: prompt,
      };
      const newHistory = [...chatHistory, userMessage];
      setChatHistory(newHistory);
      handleAIResponse(newHistory);
  }, [chatHistory, handleAIResponse]);

  useEffect(() => {
    (window as any).systemBus = systemBus;

    const handleRegisterApp = (newAppProps: {
      name: string;
      icon: string;
      category: AppDefinition['category'];
      systemPrompt: string;
    }) => {
      const newApp: AppDefinition = {
        id: `app_synthesized_${Date.now()}`,
        color: `#${Math.floor(Math.random() * 16777215).toString(16)}`,
        ...newAppProps,
      };
      setAppDefinitions((prev) => [...prev, newApp]);
      addAdvancement(`System Evolved: New app synthesized - ${newApp.name}.`);
      logSystemEvent(`New App Synthesized: ${newApp.name}`, '⚛️', 'AI Core');
    };

    const handleExecuteCommand = (data: {command: string; payload?: any; [key: string]: any;}) => {
      switch (data.command) {
        case 'open_app':
          if (data.appId) handleAppOpen(data.appId, data.payload);
          break;
        case 'close_app':
            if (data.appId) handleCloseApp(data.appId);
            break;
        case 'open_system_log':
          handleAppOpen('system_log_app');
          break;
        case 'run_diagnostics':
          if (!isParametersOpen) handleToggleParametersPanel();
          break;
        case 'evolve_theory':
          const vaultAppId = 'evolutionary_vault_app';
          if (!runningApps[vaultAppId]) handleAppOpen(vaultAppId);
          handleInteraction({
            id: 'evolve_theory_button_press',
            type: 'ai_command',
            elementText: 'Evolve Theory',
            elementType: 'system',
            appContext: vaultAppId,
          });
          break;
        case 'scan_host_system':
          addNotification(`Accessing host path: ${data.path || 'system'}...`, '🖥️');
          logSystemEvent(`Scanning host path: ${data.path || 'system'}`, '🖥️', 'AI Companion');
          setTimeout(() => addNotification(`Scan complete. Found 3 potential libraries.`, '✅'), 2000);
          break;
        case 'export_to_host':
          addNotification(`Exporting "${data.filename}" to host desktop.`, '📤');
          logSystemEvent(`Exporting ${data.filename} to host.`, '📤', 'AI Companion');
          break;
        case 'integrate_library':
          addAdvancement(`System Evolution: Integrating ${data.libraryName || 'new library'} from external source.`);
          logSystemEvent(`Integrating external library: ${data.libraryName}`, '🔗', 'AI Core');
          break;
        case 'deploy_contract':
           addNotification(`Deploying smart contract...`, '📜');
           logSystemEvent(`Deploying A-Ethereum contract. Details: ${JSON.stringify(data.details)}`, '📜', 'Grok-Liaison');
           break;
        case 'query_treasury':
            addNotification(`Querying treasury status...`, '💰');
            logSystemEvent(`Treasury status queried by executive command.`, '💰', 'Grok-Liaison');
            break;
        default:
          addNotification(`Unknown command: ${data.command}`, '❓');
          break;
      }
    };

    const handleBlueprintGenerated = (blueprint: Blueprint) => {
      setLatestBlueprint(blueprint);
      addNotification(`New Blueprint Archived: ${blueprint.technologyName}`, '📄');
      logSystemEvent(`Blueprint Archived: ${blueprint.technologyName}`, '📄', 'Evolutionary Vault');
    };
    
    const handleLogEvent = (data: {message: string; icon: string; source: string;}) => {
      if(data.message && data.icon && data.source) {
          logSystemEvent(data.message, data.icon, data.source);
      }
    };

    const handleSendAIChatMessage = (prompt: string) => {
        handleUserChatMessage(prompt);
        if (!isAICompanionOpen) {
            setIsAICompanionOpen(true);
        }
    };

    const unsubAnim = systemBus.on('toggle_quantum_animations', (isEnabled) => {
      setQuantumAnimationsEnabled(isEnabled);
    });
    const unsubRegister = systemBus.on('register_new_app', handleRegisterApp);
    const unsubCommand = systemBus.on('execute_command', handleExecuteCommand);
    const unsubBlueprint = systemBus.on(
      'new_blueprint_generated',
      handleBlueprintGenerated,
    );
    const unsubLog = systemBus.on('log_system_event', handleLogEvent);
    const unsubTheme = systemBus.on('apply_theme', (css: string | null) => {
        setCustomThemeCss(css);
        if (css) {
            localStorage.setItem('artemisOS_mainThemeCss', css);
        } else {
            localStorage.removeItem('artemisOS_mainThemeCss');
        }
    });
    const unsubBootTheme = systemBus.on('apply_boot_theme', (css: string | null) => {
        setBootThemeCss(css);
        if (css) {
            localStorage.setItem('artemisOS_bootThemeCss', css);
        } else {
            localStorage.removeItem('artemisOS_bootThemeCss');
        }
        logSystemEvent('Custom boot screen theme applied.', '🎨', 'UI Synthesizer');
    });
    const unsubWallpaper = systemBus.on('set_wallpaper', (url: string) => {
        logSystemEvent(`Wallpaper set to URL (feature deprecated): ${url}`, '💾', 'System');
    });
    const unsubUpdate = systemBus.on('initiate_system_update', () => {
      logSystemEvent('System update initiated from Release Hub.', '📦', 'Release Hub');
      setIsUpdating(true);
    });
    const unsubSendChatMessage = systemBus.on('send_ai_chat_message', handleSendAIChatMessage);

    return () => {
      unsubAnim();
      unsubRegister();
      unsubCommand();
      unsubBlueprint();
      unsubLog();
      unsubTheme();
      unsubBootTheme();
      unsubWallpaper();
      unsubUpdate();
      unsubSendChatMessage();
    };
  }, [
    addNotification,
    handleAppOpen,
    isParametersOpen,
    runningApps,
    handleToggleParametersPanel,
    handleInteraction,
    addAdvancement,
    logSystemEvent,
    handleUserChatMessage,
    isAICompanionOpen,
  ]);
  
  useEffect(() => {
    const styleId = 'artemis-custom-theme';
    const existingStyle = document.getElementById(styleId);
    if (existingStyle) {
      existingStyle.remove();
    }
    document.body.classList.remove('generated-theme');

    if (customThemeCss) {
      const style = document.createElement('style');
      style.id = styleId;
      style.innerHTML = customThemeCss;
      document.head.appendChild(style);
      document.body.classList.add('generated-theme');
      logSystemEvent('Custom UI theme applied.', '🎨', 'UI Synthesizer');
    }
  }, [customThemeCss, logSystemEvent]);

  const saveState = useCallback(() => {
    if (!isStatefulnessEnabled) return;
    try {
      // Create a serializable version of appDefinitions by removing the component functions.
      const serializableAppDefinitions = appDefinitions.map(appDef => {
        const { component, ...rest } = appDef;
        return rest;
      });

      const stateToSave: AppState = {
        runningApps,
        closedAppCache,
        activeAppId,
        appUsage,
        currentMaxHistoryLength,
        isStatefulnessEnabled,
        topZIndex,
        evolutionPoints,
        appDefinitions: serializableAppDefinitions,
        pinnedApps,
        isLiveMode,
        systemLog,
        customThemeCss,
        bootThemeCss,
      };
      saveOsState(stateToSave);
    } catch (e: any) {
      console.error('Failed to save OS state to IndexedDB:', e);
      setError('Could not save OS state.');
    }
  }, [
    runningApps,
    closedAppCache,
    activeAppId,
    appUsage,
    currentMaxHistoryLength,
    isStatefulnessEnabled,
    topZIndex,
    evolutionPoints,
    appDefinitions,
    pinnedApps,
    isLiveMode,
    systemLog,
    customThemeCss,
    bootThemeCss,
  ]);

  useEffect(() => {
    if (!isBooting) {
      saveState();
    }
  }, [
    runningApps,
    appDefinitions,
    pinnedApps,
    customThemeCss,
    bootThemeCss,
    isLiveMode,
    systemLog,
    evolutionPoints,
    closedAppCache,
    isBooting,
    saveState,
  ]);

  const handleExecuteAction = useCallback(
    (actionId: string, value?: string) => {
      playSound(SoundType.CLICK);
      setIsStartMenuOpen(false); // Close menu after action

      switch (actionId) {
        case 'action_open_parameters':
          handleToggleParametersPanel();
          break;
        case 'action_save_state':
          saveState();
          addNotification('System state manually saved.', '💾');
          logSystemEvent('System state manually saved.', '💾', 'User Action');
          break;
        case 'action_toggle_pin':
          if (value) {
            setPinnedApps((prev) => {
              const newPinned = new Set(prev);
              const appName = appDefinitions.find(app => app.id === value)?.name || 'App';
              if (newPinned.has(value)) {
                newPinned.delete(value);
                addNotification(`${appName} unpinned from Quick Launch.`, '📌');
                logSystemEvent(`${appName} unpinned from Quick Launch.`, '📌', 'User Action');
              } else {
                newPinned.add(value);
                addNotification(`${appName} pinned to Quick Launch.`, '📌');
                logSystemEvent(`${appName} pinned to Quick Launch.`, '📌', 'User Action');
              }
              return Array.from(newPinned);
            });
          }
          break;
        default:
          console.warn(`Unknown start menu action: ${actionId}`);
          addNotification(`Unknown action: ${actionId}`, '❓');
      }
    },
    [handleToggleParametersPanel, saveState, addNotification, logSystemEvent, appDefinitions],
  );

  const recallState = useCallback(async (stateToLoad?: AppState) => {
    try {
      const savedState = stateToLoad || await loadOsState();
      if (savedState) {
        const appsWithoutPayloads = savedState.runningApps || {};
        Object.keys(appsWithoutPayloads).forEach(key => {
          delete appsWithoutPayloads[key].payload;
        });
        setRunningApps(appsWithoutPayloads);
        
        setClosedAppCache(savedState.closedAppCache || {});
        setActiveAppId(savedState.activeAppId || null);
        setAppUsage(savedState.appUsage || {});
        setCurrentMaxHistoryLength(
          savedState.currentMaxHistoryLength ?? INITIAL_MAX_HISTORY_LENGTH,
        );
        setIsStatefulnessEnabled(savedState.isStatefulnessEnabled ?? true);
        setTopZIndex(savedState.topZIndex || 10);
        setEvolutionPoints(savedState.evolutionPoints || 0);

        // Hydrate saved app definitions with their component functions
        if (savedState.appDefinitions) {
            const rehydratedAppDefs = savedState.appDefinitions.map(appDef => {
                const originalApp = APP_DEFINITIONS_CONFIG.find(orig => orig.id === appDef.id);
                return {
                    ...appDef,
                    component: originalApp?.component, // Attach component if it's a native app
                };
            });
            setAppDefinitions(rehydratedAppDefs as AppDefinition[]);
        } else {
             setAppDefinitions(APP_DEFINITIONS_CONFIG);
        }
        
        setPinnedApps(savedState.pinnedApps || APP_DEFINITIONS_CONFIG.filter(app => app.isPinned).map(app => app.id));
        setIsLiveMode(savedState.isLiveMode || false);
        setSystemLog(savedState.systemLog || []);
        setCustomThemeCss(savedState.customThemeCss || null);
        setBootThemeCss(savedState.bootThemeCss || null);
        
        setWallpaperUrl(''); 
        logSystemEvent('OS State Recalled.', '💾', 'System');
      } else if (!stateToLoad) {
         // Fallback to localStorage for themes for graceful migration
        setCustomThemeCss(localStorage.getItem('artemisOS_mainThemeCss') || null);
        setBootThemeCss(localStorage.getItem('artemisOS_bootThemeCss') || null);
        setAppDefinitions(APP_DEFINITIONS_CONFIG);
      }
      
      const savedAdvancements = localStorage.getItem('artemisOS_advancements');
      if (savedAdvancements) {
        setAdvancements(JSON.parse(savedAdvancements));
      }
      playSound(SoundType.TRANSITION);
    } catch (e) {
      console.error('Failed to recall state:', e);
      setError('Could not recall OS state.');
      addNotification('Failed to load state file. It may be corrupted.', '❌');
    }
  }, [logSystemEvent]);

  const handleExportState = useCallback(() => {
      const serializableAppDefinitions = appDefinitions.map(appDef => {
        const { component, ...rest } = appDef;
        return rest;
      });

      const stateToSave: AppState = {
        runningApps, closedAppCache, activeAppId, appUsage, currentMaxHistoryLength,
        isStatefulnessEnabled, topZIndex, evolutionPoints, appDefinitions: serializableAppDefinitions,
        pinnedApps, isLiveMode, systemLog, customThemeCss, bootThemeCss,
      };

      const stateJson = JSON.stringify(stateToSave, null, 2);
      const blob = new Blob([stateJson], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'artemis-state.json';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      addNotification('System state exported to artemis-state.json', '📤');
      logSystemEvent('System state exported to file.', '📤', 'User Action');
  }, [
      appDefinitions, runningApps, closedAppCache, activeAppId, appUsage,
      currentMaxHistoryLength, isStatefulnessEnabled, topZIndex, evolutionPoints,
      pinnedApps, isLiveMode, systemLog, customThemeCss, bootThemeCss, addNotification, logSystemEvent
  ]);

  const handleImportState = useCallback((fileContent: string) => {
    try {
        const newState = JSON.parse(fileContent);
        // Basic validation
        if (newState && typeof newState === 'object' && newState.hasOwnProperty('runningApps')) {
            recallState(newState);
            addNotification('System state imported successfully!', '📥');
        } else {
            throw new Error('Invalid state file format.');
        }
    } catch (e: any) {
        console.error('Failed to import state:', e);
        addNotification(`Error importing state: ${e.message}`, '❌');
    }
  }, [recallState, addNotification]);
  
  const handleToggleLiveMode = useCallback(() => {
      setIsLiveMode(prev => {
          const newMode = !prev;
          logSystemEvent(`Live Mode ${newMode ? 'Engaged' : 'Disengaged'}.`, newMode ? '🔴' : '⚫', 'System Core');
          addNotification(`Live Mode has been ${newMode ? 'Engaged' : 'Disengaged'}.`, '🔴');
          return newMode;
      });
  }, [logSystemEvent, addNotification]);

  useEffect(() => {
    recallState();
    addEvolutionPoints(1);
  }, [recallState, addEvolutionPoints]);

  const handleCloseApp = (appId: string) => {
    playSound(SoundType.CLOSE);
    const appToClose = runningApps[appId];
    if (appToClose) {
        setClosedAppCache(prev => ({ ...prev, [appId]: appToClose.history }));
    }

    setRunningApps((prev) => {
      const newRunning = {...prev};
      delete newRunning[appId];
      return newRunning;
    });

    if (activeAppId === appId) {
      setActiveAppId(null);
    }
  };

  const handleMinimizeApp = (appId: string) => {
    playSound(SoundType.TRANSITION);
    setRunningApps((prev) => ({
      ...prev,
      [appId]: {...prev[appId], isMinimized: true},
    }));
    if (activeAppId === appId) {
      setActiveAppId(null);
    }
  };

  const handleMaximizeApp = (appId: string) => {
    playSound(SoundType.TRANSITION, 0.5);
    setRunningApps(prev => {
        const app = prev[appId];
        if (!app) return prev;

        const taskbarHeight = 48;
        
        if (app.isMaximized) {
            return {
                ...prev,
                [appId]: {
                    ...app,
                    isMaximized: false,
                    x: app.prevX ?? 100,
                    y: app.prevY ?? 100,
                    width: app.prevWidth ?? 800,
                    height: app.prevHeight ?? 600,
                }
            };
        } else {
            return {
                ...prev,
                [appId]: {
                    ...app,
                    isMaximized: true,
                    prevX: app.x,
                    prevY: app.y,
                    prevWidth: app.width,
                    prevHeight: app.height,
                    x: 0,
                    y: 0,
                    width: window.innerWidth,
                    height: window.innerHeight - taskbarHeight,
                }
            };
        }
    });
  };

  const handleMinimizeAllWindows = () => {
    playSound(SoundType.TRANSITION, 0.6);
    setRunningApps((prev) => {
      const minimizedApps: Record<string, AppInstance> = {};
      for (const id in prev) {
        minimizedApps[id] = {...prev[id], isMinimized: true};
      }
      return minimizedApps;
    });
    setActiveAppId(null);
    if (isParametersOpen) setIsParametersOpen(false);
    if (isStartMenuOpen) setIsStartMenuOpen(false);
  };

  const handleToggleNotificationsPanel = () => {
    playSound(SoundType.TRANSITION, 0.5);
    setIsNotificationsOpen(!isNotificationsOpen);
    if (isParametersOpen) setIsParametersOpen(false);
    if (isStartMenuOpen) setIsStartMenuOpen(false);
  };

  const handleWindowUpdate = (
    appId: string,
    updates: Partial<Pick<AppInstance, 'x' | 'y' | 'width' | 'height'>>,
  ) => {
    setRunningApps((prev) => ({
      ...prev,
      [appId]: {...prev[appId], ...updates},
    }));
  };

  const handleDesktopContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsStartMenuOpen(prev => {
      if (!prev) playSound(SoundType.OPEN, 0.6);
      return !prev;
    });
  };

  if (isUpdating) {
    return <UpdateScreen onUpdateComplete={() => {
        setIsUpdating(false);
        // Trigger a reboot sequence
        setIsBooting(true);
    }} />;
  }

  if (isBooting) {
    return <BootScreen onBootComplete={() => setIsBooting(false)} />;
  }

  const runningAppList = Object.values(runningApps);

  return (
    <div 
      className="w-full h-screen flex flex-col overflow-hidden"
    >
      {isAICompanionOpen && (
        <AICompanion
          chatHistory={chatHistory}
          onSendMessage={handleUserChatMessage}
          onClose={() => setIsAICompanionOpen(false)}
        />
      )}
      <RadialMenu
        isOpen={isStartMenuOpen}
        apps={appDefinitions}
        pinnedAppIds={pinnedApps}
        onAppOpen={handleAppOpen}
        onExecuteAction={handleExecuteAction}
        onClose={() => setIsStartMenuOpen(false)}
      />

      <NotificationSidebar
        isOpen={isNotificationsOpen}
        notifications={notifications}
        onClear={() => setNotifications([])}
        onClose={() => setIsNotificationsOpen(false)}
      />

      <div className="flex-grow relative">
        <div
          className={`w-full h-full pointer-events-auto absolute top-0 left-0 ${
            isDragging ? 'desktop-drop-target' : ''
          }`}
          onClick={() => {
            setActiveAppId(null);
            setIsStartMenuOpen(false);
          }}
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => {
            setIsDragging(false);
          }}
          onDrop={handleDrop}
          onContextMenu={handleDesktopContextMenu}
          >
          <DesktopView apps={appDefinitions} onAppOpen={handleAppOpen} />
        </div>

        {isParametersOpen && (
          <AppWindow
            title="System Parameters"
            onClose={handleToggleParametersPanel}
            onMinimize={() => setIsParametersOpen(false)}
            onMaximize={() => setIsParametersMaximized(p => !p)}
            isMaximized={isParametersMaximized}
            x={150}
            y={100}
            width={800}
            height={600}
            zIndex={topZIndex + 1}
            isDraggable={true}
            isResizable={true}
            onPositionChange={() => {}}
            onSizeChange={() => {}}
            onFocus={() => setActiveAppId('system_parameters')}
            isActive={activeAppId === 'system_parameters'}>
            <ParametersPanel
              currentLength={currentMaxHistoryLength}
              onUpdateHistoryLength={setCurrentMaxHistoryLength}
              isStatefulnessEnabled={isStatefulnessEnabled}
              onSetStatefulness={setIsStatefulnessEnabled}
              onExportState={handleExportState}
              onImportState={handleImportState}
              advancements={advancements}
              appDefinitions={appDefinitions}
              currentWallpaper={wallpaperUrl}
            />
          </AppWindow>
        )}

        {Object.values(runningApps).map((app) => {
          const appDef = appDefinitions.find((def) => def.id === app.id);
          if (!appDef || app.isMinimized) return null;

          const AppContent = appDef.component;

          return (
            <AppWindow
              key={app.id}
              title={appDef.name}
              onClose={() => handleCloseApp(app.id)}
              onMinimize={() => handleMinimizeApp(app.id)}
              onMaximize={() => handleMaximizeApp(app.id)}
              isMaximized={app.isMaximized}
              x={app.x}
              y={app.y}
              width={app.width}
              height={app.height}
              zIndex={app.zIndex}
              isDraggable={true}
              isResizable={true}
              onPositionChange={(x, y) => handleWindowUpdate(app.id, {x, y})}
              onSizeChange={(width, height) =>
                handleWindowUpdate(app.id, {width, height})
              }
              onFocus={() => bringToFront(app.id)}
              isActive={activeAppId === app.id}>
              {AppContent ? (
                <AppContent
                  systemLog={systemLog}
                  payload={app.payload}
                  onPayloadConsumed={() => {
                    setRunningApps((prev) => {
                      if (!prev[app.id]) return prev;
                      const updatedApp = {...prev[app.id], payload: undefined};
                      return {...prev, [app.id]: updatedApp};
                    });
                  }}
                  runningApps={runningApps}
                  appDefinitions={appDefinitions}
                />
              ) : (
                <>
                  {isLoading && app.content.length === 0 && (
                    <div className="flex justify-center items-center h-full">
                      <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
                    </div>
                  )}
                  {error && app.id === activeAppId && (
                    <div className="p-4 text-red-600 bg-red-100 rounded-md">
                      {error}
                    </div>
                  )}
                  <GeneratedContent
                    htmlContent={app.content}
                    onInteract={handleInteraction}
                    appContext={app.id}
                    isLoading={isLoading && app.id === activeAppId}
                  />
                </>
              )}
            </AppWindow>
          );
        })}
      </div>

      <Taskbar
        runningApps={runningAppList}
        appDefinitions={appDefinitions}
        onAppSelect={(appId) => handleAppOpen(appId)}
        activeAppId={activeAppId}
        onToggleStartMenu={() => setIsStartMenuOpen(!isStartMenuOpen)}
        onToggleAI={() => setIsAICompanionOpen(!isAICompanionOpen)}
        onShowDesktop={handleMinimizeAllWindows}
        onCloseApp={handleCloseApp}
        onMinimizeApp={handleMinimizeApp}
        onToggleNotifications={handleToggleNotificationsPanel}
        onToggleParameters={handleToggleParametersPanel}
        isLiveMode={isLiveMode}
        onToggleLiveMode={handleToggleLiveMode}
        latestBlueprint={latestBlueprint}
      />
    </div>
  );
};

export default App;