/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */

export interface NativeAppComponentProps {
  systemLog: LogEntry[];
  payload?: any;
  onPayloadConsumed?: () => void;
  currentWallpaper?: string;
  runningApps?: Record<string, AppInstance>;
  appDefinitions?: AppDefinition[];
}

// This allows components to accept the standard props, or no props at all.
// A component can accept all, some (by making them optional), or none.
export type NativeComponent = React.FC<Partial<NativeAppComponentProps>>;

export interface AppDefinition {
  id: string;
  name: string;
  icon: string;
  color: string;
  isCli?: boolean;
  component?: NativeComponent;
  systemPrompt?: string;
  initialInteraction?: InteractionData;
  category: 'NeoCor AI System' | 'Science & Exploration' | 'Development & Utilities' | 'Finance & Media' | 'Satellite & Drone Systems' | 'Media' | 'AI Development & Research';
  isPinned?: boolean;
}

export interface InteractionData {
  id: string;
  type: string;
  value?: string;
  elementType: string;
  elementText: string;
  appContext: string | null;
}

export interface AppInstance {
  id:string; // Corresponds to AppDefinition id
  content: string;
  history: InteractionData[];
  path: string[];
  isMinimized: boolean;
  // New properties for window management
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
  payload?: any;
  isMaximized?: boolean;
  prevX?: number;
  prevY?: number;
  prevWidth?: number;
  prevHeight?: number;
}

export interface AppUsageStats {
  [appId: string]: {
    openCount: number;
  };
}

export interface Advancement {
  id: string;
  timestamp: number;
  message: string;
}

export interface Notification {
  id: string;
  timestamp: number;
  message: string;
  icon: string;
}

export interface LogEntry {
  id: string;
  timestamp: number;
  source: string; // e.g., 'System', 'AI Core', 'Grok-Liaison'
  message: string;
  icon: string;
}

export interface AssembledPart {
  uniqueId: string;
  part: VehiclePart;
  stage: number;
}

export interface StageStats {
  stage: number;
  totalMass: number;
  dryMass: number;
  fuelMass: number;
  thrust: number;
  twr: number;
  burnTime: number;
  deltaV: number;
}


export interface VehiclePart {
  id: string;
  name: string;
  type: 'pod' | 'tank' | 'engine' | 'payload' | 'chassis' | 'wheel' | 'propeller' | 'buoyancy' | 'utility';
  category: 'Rocketry' | 'Rovers' | 'Submersibles' | 'Payloads' | 'Utility' | 'Robotics' | 'Life Support' | 'Science' | 'Structural';
  mass: number; // Dry mass in tons
  fuel?: number; // Fuel mass in tons
  thrust?: number; // in kN
  isp?: number; // Specific impulse in seconds
  fuelType?: 'RP-1/LOX' | 'Methalox' | 'Hypergolic' | 'Electric';
  torque?: number; // for wheels, in kNm
  buoyancyForce?: number; // for buoyancy parts, in kN
  payloadMass?: number; // in tons
  crew?: number;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  isThinking?: boolean;
  imageUrl?: string;
  isGeneratingImage?: boolean;
}

export interface Mission {
    id: string;
    name: string;
    target: string;
    objectives: string;
    brief?: string;
    unrealPackageLog?: string;
}

export interface Blueprint {
  blueprintId: string;
  technologyName: string;
  baseAlloy?: string;
  keyProperties: Record<string, string>;
  status: string;
}

// Types for native file system integration
export interface FileSystemItem {
  name: string;
  kind: 'file' | 'directory';
  path: string;
}

export interface LinkedFolder {
  name: string;
  path: string;
}

// NeoCor and New App Types
export interface NeoCorNode {
  id: string;
  type: 'Host' | 'ARM64' | 'ARCH64' | 'Apple Silicon';
  status: 'Online' | 'Offline' | 'Stressed';
  task: string;
  load: number; // 0-100
}

export interface ClusterNode {
  id: string;
  name: string;
  ip: string;
  arch: 'ARM64' | 'Arch64' | 'x86_64' | 'Apple Silicon';
  status: 'Online' | 'Offline' | 'Stressed';
  task: string;
  signal: number; // LoRaWAN signal strength in dBm
  cpu: number;
  ram: number;
}

export interface DataPacket {
  id: number;
  source: string;
  target: string;
  size: number; // in KB
}

export interface Harmonic {
  id: '364' | '369';
  isActive: boolean;
  power: number; // 0-100
}

export interface HolographicObject {
  id: string;
  type: 'Planet' | 'Star' | 'Galaxy' | 'Anomaly';
  position: { x: number; y: number; z: number };
  rotation: number;
}

export interface NexusBuildConfig {
  id: string;
  name: string;
  target: 'WSL' | 'Kubernetes' | 'Local';
  status: 'Pending' | 'Building' | 'Deployed' | 'Failed';
}

export interface UnityProject {
  id: string;
  name: string;
  path: string;
  lastModified: number;
}

export interface MediaItem {
  id: string;
  title: string;
  artist: string;
  duration: number; // in seconds
  source: string; // URL or path
}

export interface EarthDataSet {
  id: string;
  name: string;
  type: 'Atmospheric' | 'Oceanic' | 'Geological' | 'Cryosphere';
  region: string;
  resolution: string;
  lastUpdated: string;
  description: string;
  imageUrl: string;
}

export interface CryptoAsset {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
}

export interface AutomationJob {
  id: string;
  name: string;
  trigger: string;
  actions: string[];
  status: 'Active' | 'Paused' | 'Completed';
}

export interface MemoryCell {
  id: number;
  isInscribed: boolean;
  dataFragment: string; //
  intensity: number; // 0-1
}

export interface SynapticPackage {
    id: string;
    name: string;
    version: string;
    description: string;
    category: 'AI/ML' | 'Graphics' | 'Networking' | 'System' | 'Development';
    isInstalled: boolean;
}

export type LedgerParty = 'xAI' | 'SpaceX' | 'Three Ring Studios' | 'ArtemisOS' | 'Treasury';

export interface LedgerTransaction {
    id: string;
    timestamp: number;
    from: LedgerParty;
    to: LedgerParty;
    amount: number;
    asset: string;
    memo: string;
}

// Restored / New App Types
export interface UnrealNode {
  id: string;
  lat: number;
  lon: number;
  type: 'User' | 'AI System' | 'Data Center';
}

export interface BowtieDecision {
  id: string;
  path: number[]; // e.g., [3, 2, 1]
  outcome: string;
  isCause: boolean; // cause or effect
}

export interface CosmicSignal {
  id: string;
  source: 'Earth' | 'Mars' | 'Saturn' | 'Sun';
  target: string;
  frequency: number; // in Hz
  strength: number; // in dBm
}

export interface DisasterAlert {
    id: string;
    type: 'Seismic' | 'Atmospheric';
    location: string;
    magnitude: number;
    threat: 'Low' | 'Moderate' | 'Severe';
}

export interface RelayStatus {
    id: string;
    source: string;
    target: string;
    latency: number; // in ms
    throughput: number; // in Gbps
    stability: number; // percentage
}

export interface LinterIssue {
    id: string;
    file: string;
    line: number;
    severity: 'Error' | 'Warning' | 'Info';
    message: string;
}

export interface Process {
  id: string;
  name: string;
  icon: string;
  cpu: number;
  memory: number; // in MB
}

export interface StorageNote {
    id: number;
    text: string;
    createdAt: Date;
}

// A single, comprehensive type for the entire OS state
// to be saved in IndexedDB for robust persistence.
export interface AppState {
  runningApps: Record<string, AppInstance>;
  closedAppCache: Record<string, InteractionData[]>;
  activeAppId: string | null;
  appUsage: AppUsageStats;
  currentMaxHistoryLength: number;
  isStatefulnessEnabled: boolean;
  topZIndex: number;
  evolutionPoints: number;
  appDefinitions: Omit<AppDefinition, 'component'>[];
  pinnedApps: string[];
  isLiveMode: boolean;
  systemLog: LogEntry[];
  customThemeCss: string | null;
  bootThemeCss: string | null;
}

// --- New Types for On-Device AI, Robotics, and Security ---

export interface AIHardwareStats {
  gpu: {
    name: 'NVIDIA RTX 4090' | 'AMD Radeon Pro W7900';
    utilization: number; // 0-100
    vramUsed: number; // in GB
    vramTotal: number; // in GB
    temperature: number; // in Celsius
  };
  models: {
    id: string;
    name: string;
    status: 'Loaded' | 'Idle' | 'Error';
    vram: number; // in GB
  }[];
}

export interface RoboticArmState {
  baseRotation: number; // degrees
  shoulderAngle: number; // degrees
  elbowAngle: number; // degrees
  wristAngle: number; // degrees
  gripper: number; // 0-100
}

export interface AppPermission {
  fileSystem: 'read' | 'read-write' | 'none';
  network: 'lan' | 'full' | 'none';
  sensors: 'read' | 'none';
}

export interface FirewallRule {
  id: string;
  appId: string;
  action: 'allow' | 'block';
  direction: 'in' | 'out';
  target: string; // e.g., 'any', 'lan', IP address
}

// --- New Types for Artemis Operations Hub ---
export interface Contract {
  id: string;
  title: string;
  parties: string[];
  value: number;
  asset: string;
  status: 'Draft' | 'Active' | 'Completed';
}

export interface IntellectualProperty {
  id: string;
  name: string;
  type: 'Vessel Blueprint' | 'Component Schematic';
  tokenId: string;
  owner: string;
}

export interface PayoutMethod {
  id: 'cashapp' | 'paypal' | 'bank';
  name: string;
  identifier: string; // e.g., $cashtag, email, account number
}

export type BuildStatus = 'Idle' | 'Building' | 'Success' | 'Failed';