/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
// This file is now a proxy to the new RadialMenu component
// to maintain existing import paths in App.tsx.
export { RadialMenu as StartMenu } from './components/RadialMenu';
